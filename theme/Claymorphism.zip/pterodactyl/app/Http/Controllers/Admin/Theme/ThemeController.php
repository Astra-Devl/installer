<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class ThemeController extends Controller
{
    private const UPLOAD_URL = '/uploads/theme/';

    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.index', ['theme' => ThemeSettings::get()]);
    }

    /**
     * Updates the header logo, the name shown next to the logo and the background image.
     */
    public function update(Request $request)
    {
        $urlRule = ['nullable', 'string', 'max:255', 'regex:/^(https?:\/\/|\/)[^\s"\'<>()\\\\]*$/i'];

        $data = $request->validate([
            'logo' => $urlRule,
            'logo_file' => ['nullable', 'file', 'mimes:png,jpg,jpeg,gif,webp,ico', 'max:2048'],
            'sitename' => ['nullable', 'string', 'max:40'],
            'backgroundimage' => $urlRule,
        ]);

        $existing = DB::table('theme')->first();
        $logo = trim((string) ($data['logo'] ?? ''));

        if ($request->boolean('reset_logo')) {
            $logo = ThemeSettings::DEFAULT_LOGO;
        }

        if ($request->hasFile('logo_file')) {
            $logo = $this->storeLogo($request);
        }

        if ($logo === '') {
            $logo = $existing->logo ?: ThemeSettings::DEFAULT_LOGO;
        }

        // Remove the previously uploaded file when it is no longer in use.
        if ($existing->logo !== $logo) {
            $this->deleteUploadedLogo((string) $existing->logo);
        }

        DB::table('theme')->where('id', $existing->id)->update([
            'logo' => $logo,
            'longlogo' => $logo,
            'sitename' => trim((string) ($data['sitename'] ?? '')),
            'backgroundimage' => trim((string) ($data['backgroundimage'] ?? '')),
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }

    private function storeLogo(Request $request): string
    {
        $directory = public_path('uploads/theme');
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }

        $file = $request->file('logo_file');
        $name = 'logo-' . Str::lower(Str::random(20)) . '.' . $file->extension();
        $file->move($directory, $name);

        return self::UPLOAD_URL . $name;
    }

    private function deleteUploadedLogo(string $logo): void
    {
        if (!str_starts_with($logo, self::UPLOAD_URL)) {
            return;
        }

        $path = public_path('uploads/theme/' . basename($logo));
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
