<?php

namespace Pterodactyl\Services\Theme;

use Illuminate\Support\Facades\DB;

/**
 * Single source of truth for the Claymorphism theme settings.
 *
 * Every read goes through get(), which never throws: if the `theme` table (or a newly
 * added column) is missing because migrations have not been run yet, the defaults below
 * are used instead, so the login page can never crash with a 500 error.
 */
class ThemeSettings
{
    public const DEFAULT_LOGO = '/favicons/favicon-32x32.png';

    private static ?object $cache = null;

    /**
     * Claymorphism default palette. Base keys = default (light clay) mode,
     * keys prefixed with "l" = mode that is toggled with the moon button (dark clay).
     */
    public static function defaults(): array
    {
        return [
            'logo' => self::DEFAULT_LOGO,
            'longlogo' => self::DEFAULT_LOGO,
            'sitename' => '',
            'backgroundimage' => '',
            'title' => 'Claymorphism Panel',
            'discription' => 'Game server control panel',
            'metacolor' => '#7c6cf2',

            'highlightcolor' => '#2f2b52', 'lightcolor' => '#3d3969', 'color' => '#4b4778',
            'subcolor' => '#6a668f', 'color4' => '#7a769c', 'color5' => '#8d89ad', 'color6' => '#a3a0bf',
            'dark' => '#3a3566', 'primary' => '#7c6cf2', 'primaryhover' => '#6b5ae6',
            'secondary' => '#eeedfb', 'secondaryhover' => '#e0def4', 'background' => '#e3e1f4', 'input' => '#dcdaf0',

            'lhighlightcolor' => '#f3f1ff', 'llightcolor' => '#e2dffa', 'lcolor' => '#cfcbee',
            'lsubcolor' => '#b3afd9', 'lcolor4' => '#a09bcc', 'lcolor5' => '#8e89bd', 'lcolor6' => '#7b76ab',
            'ldark' => '#4a4775', 'lprimary' => '#9a8cff', 'lprimaryhover' => '#b0a5ff',
            'lsecondary' => '#302e4d', 'lsecondaryhover' => '#3a3860', 'lbackground' => '#25233d', 'linput' => '#201e36',

            'dangerbutton' => '#f0657d', 'dangerbuttonhover' => '#e34d67',
            'textbutton' => '#8a85b3', 'textbuttonhover' => '#706b9c',
            'ldangerbutton' => '#ff7a92', 'ldangerbuttonhover' => '#ff93a7',
            'ltextbutton' => '#6f6aa0', 'ltextbuttonhover' => '#8782b8',
            'borderradius' => '22',

            'subnavigation' => 1, 'graphcard' => 1, 'sidegraph' => 1, 'infoelement' => 1,
            'newserverlist' => 'table',
            'typealert' => 'disabled', 'alertdescription' => 'none',
            'discord' => 'none', 'website' => 'none', 'billing' => 'none',
            'knowledgebase' => 'none', 'status' => 'none',

            'contact_enabled' => 1,
            'contact_label' => 'Hubungi Pemilik Website',
            'contact_whatsapp' => '',
            'contact_telegram' => '',
            'contact_message' => 'Halo, saya butuh bantuan terkait akun panel.',

        ];
    }

    /**
     * Returns the settings row merged over the defaults. Never throws.
     */
    public static function get(): object
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $values = self::defaults();

        try {
            $row = DB::table('theme')->first();
            if ($row) {
                foreach ((array) $row as $key => $value) {
                    // Keep the default for NULL values; empty strings are valid (e.g. no background image).
                    if ($value !== null) {
                        $values[$key] = $value;
                    }
                }
            }
        } catch (\Throwable $exception) {
            // Table or column missing (migrations not run yet): fall back to the defaults.
        }

        return self::$cache = (object) $values;
    }

    public static function flush(): void
    {
        self::$cache = null;
    }

    public static function logo(): string
    {
        $logo = trim((string) self::get()->logo);

        return $logo !== '' ? $logo : self::DEFAULT_LOGO;
    }

    public static function siteName(): string
    {
        $name = trim((string) self::get()->sitename);

        return $name !== '' ? $name : (string) config('app.name', 'Pterodactyl');
    }

    /**
     * Normalises a phone number to digits only (wa.me format). A leading 0 is treated
     * as an Indonesian local number and converted to the 62 country code.
     */
    public static function normalizeWhatsapp(?string $number): string
    {
        $digits = preg_replace('/\D+/', '', (string) $number) ?? '';
        if ($digits !== '' && str_starts_with($digits, '0')) {
            $digits = '62' . substr($digits, 1);
        }

        return $digits;
    }

    /**
     * Accepts "@name", "name" or "https://t.me/name" and returns just the username.
     */
    public static function normalizeTelegram(?string $value): string
    {
        $value = trim((string) $value);
        $value = preg_replace('#^(https?://)?(t\.me|telegram\.me)/#i', '', $value) ?? '';

        return ltrim($value, '@');
    }

    /**
     * The subset of settings that is safe to expose to unauthenticated visitors
     * (the login page needs it). Injected into the page as window.ThemeConfiguration.
     */
    public static function publicConfig(): array
    {
        $s = self::get();

        $whatsapp = self::normalizeWhatsapp($s->contact_whatsapp);
        $telegram = self::normalizeTelegram($s->contact_telegram);
        $message = trim((string) $s->contact_message);

        $link = function ($value) {
            $value = (string) $value;

            return ($value === '' || $value === 'none') ? null : $value;
        };

        return [
            'name' => self::siteName(),
            'logo' => self::logo(),
            'serverList' => (string) $s->newserverlist,
            'contact' => [
                'enabled' => (bool) $s->contact_enabled && ($whatsapp !== '' || $telegram !== ''),
                'label' => (string) $s->contact_label,
                'whatsapp' => $whatsapp !== ''
                    ? 'https://wa.me/' . $whatsapp . ($message !== '' ? '?text=' . rawurlencode($message) : '')
                    : null,
                'telegram' => $telegram !== '' ? 'https://t.me/' . $telegram : null,
            ],
            'links' => [
                'website' => $link($s->website),
                'discord' => $link($s->discord),
                'billing' => $link($s->billing),
                'status' => $link($s->status),
                'knowledgebase' => $link($s->knowledgebase),
            ],
            'alert' => [
                'type' => (string) $s->typealert,
                'description' => (string) $s->alertdescription,
            ],
        ];
    }

    /**
     * Whitelisted value for output inside a <style> block (colours, urls, numbers).
     */
    public static function css($value): string
    {
        return preg_replace('/[^#a-zA-Z0-9(),.%\s\/:_\-]/', '', (string) $value) ?? '';
    }

    /**
     * Value for a CSS url("...") — strips everything that could break out of the quoted string.
     */
    public static function url($value): string
    {
        return preg_replace('/["\'\\\\<>()\s]/', '', (string) $value) ?? '';
    }
}
