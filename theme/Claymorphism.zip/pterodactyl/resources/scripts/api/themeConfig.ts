/**
 * Public theme settings injected by the server into every page as window.ThemeConfiguration
 * (see resources/views/templates/wrapper.blade.php). Because it is part of the HTML, it is
 * also available on the login page where the API cannot be used yet.
 */
export interface ThemeConfig {
    name: string;
    logo: string;
    serverList: string;
    contact: {
        enabled: boolean;
        label: string;
        whatsapp: string | null;
        telegram: string | null;
    };
    links: {
        website: string | null;
        discord: string | null;
        billing: string | null;
        status: string | null;
        knowledgebase: string | null;
    };
    alert: {
        type: string;
        description: string;
    };
}

const fallback: ThemeConfig = {
    name: 'Pterodactyl',
    logo: '/favicons/favicon-32x32.png',
    serverList: 'table',
    contact: { enabled: false, label: '', whatsapp: null, telegram: null },
    links: { website: null, discord: null, billing: null, status: null, knowledgebase: null },
    alert: { type: 'disabled', description: 'none' },
};

export const getThemeConfig = (): ThemeConfig => {
    const injected = (window as any).ThemeConfiguration as Partial<ThemeConfig> | undefined;

    return {
        ...fallback,
        ...(injected || {}),
        contact: { ...fallback.contact, ...(injected?.contact || {}) },
        links: { ...fallback.links, ...(injected?.links || {}) },
        alert: { ...fallback.alert, ...(injected?.alert || {}) },
    };
};
