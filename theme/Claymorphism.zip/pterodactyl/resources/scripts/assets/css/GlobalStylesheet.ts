import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';

export default createGlobalStyle`
    body {
        ${tw`font-sans`};
        color: var(--color);
        background-color: var(--background-color) !important;
        letter-spacing: 0.01em;
    }

    h1, h2, h3, h4, h5, h6 {
        ${tw`font-medium tracking-normal font-header`};
        font-weight: 800;
    }

    p {
        ${tw`leading-snug font-sans`};
        color: var(--color);
    }

    form {
        ${tw`m-0`};
    }

    textarea, select, input, button, button:focus, button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    ::selection {
        background: var(--primary);
        color: #fff;
    }

    /* Claymorphism scroll bar: a soft, puffy pill */
    ::-webkit-scrollbar {
        background: none;
        width: 16px;
        height: 16px;
    }

    ::-webkit-scrollbar-thumb {
        border: solid 4px transparent;
        border-radius: 999px;
        background-clip: padding-box;
        background-color: var(--color-6);
        box-shadow: inset 1px 1px 3px rgba(255, 255, 255, 0.5), inset -1px -1px 3px rgba(0, 0, 0, 0.15);
    }

    ::-webkit-scrollbar-track-piece {
        margin: 4px 0;
    }

    ::-webkit-scrollbar-thumb:hover {
        background-color: var(--primary);
    }

    ::-webkit-scrollbar-corner {
        background: transparent;
    }

    /* Soft entrance for every page */
    @keyframes clay-pop {
        from { opacity: 0; transform: translateY(8px) scale(0.99); }
        to { opacity: 1; transform: none; }
    }

    @media (prefers-reduced-motion: no-preference) {
        .fade-appear-active, .fade-enter-active {
            animation: clay-pop 0.28s ease both;
        }
    }
`;
