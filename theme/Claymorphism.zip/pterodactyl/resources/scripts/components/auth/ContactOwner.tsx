import React from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import { getThemeConfig } from '@/api/themeConfig';

const Wrapper = styled.div`
    margin-top: 1.75rem;
    padding-top: 1.25rem;
    text-align: center;
    border-top: 1px dashed rgba(128, 120, 190, 0.3);

    & > p {
        margin-bottom: 0.9rem;
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        color: var(--color-4);
    }

    & > div {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 0.9rem;
    }
`;

const ContactLink = styled.a<{ $brand: 'whatsapp' | 'telegram' }>`
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.7rem 1.35rem;
    border-radius: 999px;
    font-size: 0.85rem;
    font-weight: 800;
    text-decoration: none;
    color: #fff;
    background: ${({ $brand }) =>
        $brand === 'whatsapp' ? 'linear-gradient(145deg, #4be08a, #1fb862)' : 'linear-gradient(145deg, #5cc4f5, #2a97da)'};
    box-shadow: var(--clay-btn);
    transition: transform 0.15s ease, box-shadow 0.15s ease, filter 0.15s ease;

    &:hover {
        transform: translateY(-2px);
        filter: brightness(1.06);
    }

    &:active {
        transform: translateY(1px);
        box-shadow: var(--clay-in);
    }
`;

/**
 * "Contact the website owner" buttons shown under the "Forgot password?" link.
 * Number / username are configured in Admin > Theme > Contact Settings.
 */
export default () => {
    const { contact } = getThemeConfig();

    if (!contact.enabled || (!contact.whatsapp && !contact.telegram)) {
        return null;
    }

    return (
        <Wrapper>
            <p>{contact.label}</p>
            <div>
                {contact.whatsapp && (
                    <ContactLink $brand={'whatsapp'} href={contact.whatsapp} target={'_blank'} rel={'noopener noreferrer'}>
                        <Icon.MessageCircle size={18} />
                        WhatsApp
                    </ContactLink>
                )}
                {contact.telegram && (
                    <ContactLink $brand={'telegram'} href={contact.telegram} target={'_blank'} rel={'noopener noreferrer'}>
                        <Icon.Send size={18} />
                        Telegram
                    </ContactLink>
                )}
            </div>
        </Wrapper>
    );
};
