import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import { getThemeConfig } from '@/api/themeConfig';
import tw from 'twin.macro';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const Container = styled.div`
    ${breakpoint('sm')`
        ${tw`w-4/5 mx-auto`}
    `};

    ${breakpoint('md')`
        ${tw`p-10`}
    `};

    ${breakpoint('lg')`
        ${tw`w-3/5`}
    `};

    ${breakpoint('xl')`
        ${tw`w-full`}
        max-width: 560px;
    `};

    .box {
        background-color: var(--secondary);
        border: 1px solid var(--clay-edge);
        border-radius: calc(var(--clay-radius) + 8px);
        box-shadow: var(--clay-out);
        padding: 2rem;
    }
`;

const Brand = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 1.25rem;

    img {
        width: 84px;
        height: 84px;
        object-fit: contain;
        padding: 12px;
        border-radius: 30px;
        background-color: var(--secondary);
        box-shadow: var(--clay-out);
    }

    strong {
        margin-top: 0.9rem;
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--highlight-color);
    }
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const { logo, name } = getThemeConfig();

    return (
        <Container>
            <Brand>
                <img src={logo} alt={name} />
                <strong>{name}</strong>
            </Brand>
            {title && <h2 css={tw`text-2xl text-center text-neutral-100 font-medium pb-4`}>{title}</h2>}
            <FlashMessageRender css={tw`mb-2 px-1`} />
            <Form {...props} ref={ref}>
                <div css={tw`md:flex w-full mx-1`} className='box'>
                    <div css={tw`flex-1`}>{props.children}</div>
                </div>
            </Form>
            <p css={tw`text-center text-neutral-500 text-xs mt-5`}>
                &copy; {new Date().getFullYear()}&nbsp;
                <a
                    rel={'noopener nofollow noreferrer'}
                    href={'https://pterodactyl.io'}
                    target={'_blank'}
                    css={tw`no-underline text-neutral-500 hover:text-neutral-300`}
                >
                    Pterodactyl&reg;
                </a>
            </p>
        </Container>
    );
});
