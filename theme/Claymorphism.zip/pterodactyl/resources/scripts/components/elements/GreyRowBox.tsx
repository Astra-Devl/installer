import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded no-underline text-neutral-200 items-center p-4 border border-transparent transition-colors duration-150 overflow-hidden`};
    background-color: var(--secondary);
    border-radius:var(--clay-radius-sm);
    box-shadow:var(--clay-out-sm);
    border-color:var(--clay-edge);

    ${props => props.$hoverable !== false && 'transition:all .15s ease; &:hover{ box-shadow:var(--clay-out); transform:translateY(-1px); }'};

    & .icon {
        ${tw`rounded-full bg-neutral-500 p-3`};
    }
`;
