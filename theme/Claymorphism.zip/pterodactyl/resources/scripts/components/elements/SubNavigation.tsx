import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full overflow-x-auto`};

    & > div {
        ${tw`flex items-center text-sm mx-auto`};

        & > a, & > div {
            ${tw`inline-block py-3 text-neutral-300 no-underline whitespace-nowrap transition-all duration-150`};
            margin-right:10px;
            padding-left:1.1rem;
            padding-right:1.1rem;
            border-radius:999px;
            font-weight:700;

            &:hover {
                ${tw`text-neutral-100`};
            }

            &.active {
                color:var(--primary);
                background-color:var(--secondary-hover);
                box-shadow:var(--clay-in);
            }
        }
    }
`;

export default SubNavigation;
