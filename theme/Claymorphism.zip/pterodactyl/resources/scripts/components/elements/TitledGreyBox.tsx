import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import tw from 'twin.macro';
import isEqual from 'react-fast-compare';
import styled from 'styled-components/macro';

const Box = styled.div`
& {
    background-color: var(--secondary);
    border:1px solid var(--clay-edge);
    border-radius:var(--clay-radius);
    box-shadow:var(--clay-out);
}
& > div {
    background-color: transparent;
}
& > div:first-of-type {
    border-bottom:1px dashed rgba(128, 120, 190, 0.3);
}
`;

interface Props {
    icon?: IconProp;
    title: string | React.ReactNode;
    className?: string;
    children: React.ReactNode;
}

const TitledGreyBox = ({ icon, title, children, className }: Props) => (
    <Box className={className}>
        <div css={tw`py-4 px-5`}>
            {typeof title === 'string' ? (
                <p css={tw`text-sm uppercase`}>
                    {icon && <FontAwesomeIcon icon={icon} css={tw`mr-2 text-neutral-300`} />}
                    {title}
                </p>
            ) : (
                title
            )}
        </div>
        <div css={tw`py-4 px-5`}>{children}</div>
    </Box>
);

export default memo(TitledGreyBox, isEqual);
