import styled from 'styled-components/macro';
import tw from 'twin.macro';

/**
 * Claymorphism sidebar: a floating, puffy panel with soft light/dark shadows.
 * Colours come from the CSS variables written by partials/theme-variables.blade.php.
 */
const NavigationBar = styled.div`
    width: 323px;
    flex-shrink: 0;
    background-color: var(--secondary);
    border: 1px solid var(--clay-edge);
    border-radius: var(--clay-radius);
    box-shadow: var(--clay-out);
    height: calc(100vh - 32px);
    margin: 16px 0 16px 16px;
    position: sticky;
    top: 16px;
    transition: width 0.3s;

    #logo {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    #logo > a {
        padding: 0 !important;
        width: 100%;
        justify-content: center;
        gap: 12px;
    }
    #logo .collapseBtn {
        display: none;
    }
    #logo span {
        padding-left: 0;
        font-weight: 800;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 190px;
    }
    #logo img {
        width: 46px;
        height: 46px;
        object-fit: contain;
        border-radius: 16px;
        background-color: var(--secondary);
        box-shadow: var(--clay-out-sm);
        padding: 4px;
    }

    @media only screen and (min-width: 979px) {
        .collapse & {
            width: 84px;

            #logo img {
                display: block;
            }
            #logo > a > span {
                display: none;
            }

            & a {
                justify-content: center;
                & .icon {
                    margin-right: 0;
                }
                & > span {
                    transition: display 0.3s;
                    display: none;
                }
            }
            .subTitle {
                transition: display 0.3s;
                display: none;
            }
            .logOut {
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }
        }
        & > div:last-of-type {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
    }

    & > div:last-of-type {
        margin-left: 8px;
        padding-left: 6px;
        padding-right: 6px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        height: calc(100vh - 32px);
    }

    & #logo {
        text-align: center;
        padding: 22px 0 18px;

        & > a {
            ${tw`text-2xl font-header no-underline text-neutral-200 hover:text-neutral-100 transition-colors duration-150`};
            display: flex;
            align-items: center;
        }
    }

    & a,
    & button,
    & .navigation-link {
        ${tw`no-underline text-neutral-300 cursor-pointer transition-all duration-150`};
        padding: 8px 0.6em;
        margin: 3px 8px;
        display: flex;
        align-items: center;
        font-weight: 700;
        border-radius: var(--clay-radius-sm);

        &:hover {
            background-color: var(--secondary-hover);
            color: var(--highlight-color);
        }

        &:active,
        &.active {
            background-color: var(--secondary-hover);
            color: var(--primary);
            box-shadow: var(--clay-in);

            .icon {
                color: var(--primary);
            }
        }

        .icon {
            padding-left: 1px;
            width: 38px;
            height: 38px;
            font-size: 0.6em;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            border-radius: 14px;
            background-color: var(--secondary);
            box-shadow: var(--clay-out-sm);
        }
        &.active .icon,
        &:active .icon {
            box-shadow: none;
            background-color: transparent;
        }
    }
    .logOut {
        ${tw`text-neutral-500`};
        padding-bottom: 0.7em;
        border-top: 1px dashed rgba(128, 120, 190, 0.3);
        display: flex;
        justify-content: space-between;
        padding-top: 12px;

        a,
        button {
            margin: 0 2px;
            padding: 4px;
        }
        .icon {
            margin-right: 0;
        }
    }
    .media {
        margin-top: auto;
        padding-bottom: 4px;
        padding-top: 25px;
    }
    .subTitle {
        ${tw`text-neutral-500`};
        margin-top: 26px;
        padding: 0 1.1em 4px;
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.12em;
    }
    .last {
        margin-bottom: 5px;
    }
    @media only screen and (max-width: 979px) {
        #logo .collapseBtn {
            transform: rotate(90deg);
            display: block;
        }
        .subTitle {
            display: none;
        }
        & {
            width: auto;
            height: auto;
            position: relative;
            top: 0;
            margin: 12px;
        }
        & > div:last-of-type {
            margin-left: 0;
            padding-left: 10px;
            height: auto;
        }
        & a {
            display: none;
        }
        & .logOut {
            display: none;
        }
        & #logo a {
            display: flex;
        }
        .collapse & {
            & a {
                display: flex;
            }
            & .logOut {
                display: flex;
            }
            .subTitle {
                display: block;
            }
        }
    }
`;

export default NavigationBar;
