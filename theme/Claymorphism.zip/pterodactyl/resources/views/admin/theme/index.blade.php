@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'theme'])

@section('title')
    Theme Settings
@endsection

@section('content-header')
    <h1>Theme Settings<small>Logo, brand name and background of the panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <form action="{{ route('admin.theme.update') }}" method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="col-xs-12 col-md-7">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Header Logo &amp; Name</h3>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label class="control-label">Preview</label>
                            <div>
                                <div class="clay-logo-preview">
                                    <img src="{{ $theme->logo }}" alt="logo">
                                    <strong>{{ trim((string) $theme->sitename) !== '' ? $theme->sitename : config('app.name', 'Pterodactyl') }}</strong>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="sitename">Name next to the logo</label>
                            <input id="sitename" type="text" class="form-control" name="sitename" maxlength="40" value="{{ old('sitename', $theme->sitename) }}" placeholder="{{ config('app.name', 'Pterodactyl') }}" />
                            <p class="text-muted"><small>Shown in the header of the panel, the admin area and the login page. Leave empty to use the panel name ({{ config('app.name', 'Pterodactyl') }}).</small></p>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="logo_file">Upload logo</label>
                            <input id="logo_file" type="file" class="form-control" name="logo_file" accept="image/png,image/jpeg,image/gif,image/webp,image/x-icon" />
                            <p class="text-muted"><small>PNG, JPG, GIF, WEBP or ICO, max 2 MB. A square image around 128&times;128 px works best. An uploaded file replaces the URL below.</small></p>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="logo">&hellip; or logo URL</label>
                            <input id="logo" type="text" class="form-control" name="logo" value="{{ old('logo', $theme->logo) }}" placeholder="https://example.com/logo.png" />
                            <p class="text-muted"><small>Must start with <code>https://</code>, <code>http://</code> or <code>/</code>. Also used as the browser favicon.</small></p>
                        </div>
                        <div class="checkbox">
                            <label><input type="checkbox" name="reset_logo" value="1"> Reset to the default logo</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-5">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Background</h3>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label class="control-label" for="backgroundimage">Background image URL</label>
                            <input id="backgroundimage" type="text" class="form-control" name="backgroundimage" value="{{ old('backgroundimage', $theme->backgroundimage) }}" placeholder="(empty = soft clay gradient)" />
                            <p class="text-muted"><small>Leave empty to use the default Claymorphism gradient background.</small></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
