{{-- Claymorphism skin for the AdminLTE based admin area. Colours come from partials/theme-variables. --}}
<style>
    body, body.skin-blue { font-family: 'Nunito', 'Segoe UI', system-ui, sans-serif; color: var(--color); background-color: var(--background-color); }
    .wrapper, .content-wrapper, .right-side, .main-footer { background: transparent !important; color: var(--color); }
    .content-wrapper { padding-top: 6px; }
    .main-footer { border-top: 0; color: var(--color-4); }
    .main-footer a { color: var(--primary); }
    a { color: var(--primary); }
    a:hover, a:focus { color: var(--primary-hover); }
    h1, h2, h3, h4, h5, h6, .content-header > h1 { color: var(--highlight-color); font-weight: 800; }
    .content-header > h1 > small, .text-muted, small { color: var(--color-4); }
    .content-header > .breadcrumb { background: transparent; }
    .content-header > .breadcrumb > li > a, .breadcrumb > .active { color: var(--color-4); }

    /* Header */
    .skin-blue .main-header { box-shadow: none; max-height: none; }
    .skin-blue .main-header .navbar { background: var(--secondary); margin: 10px 14px 0 0; border-radius: 0 0 0 var(--clay-radius); box-shadow: var(--clay-out-sm); }
    .skin-blue .main-header .logo { background: transparent; color: var(--highlight-color); font-weight: 800; font-family: 'Nunito', sans-serif; border: 0; display: flex; align-items: center; justify-content: center; gap: 10px; padding: 0 10px; }
    .skin-blue .main-header .logo:hover { background: transparent; }
    .skin-blue .main-header .logo img { width: 34px; height: 34px; object-fit: contain; border-radius: 12px; box-shadow: var(--clay-out-sm); background: var(--secondary); }
    .skin-blue .main-header .logo .logo-mini, .skin-blue .main-header .logo .logo-lg { display: flex; align-items: center; gap: 10px; }
    .skin-blue .main-header .navbar .nav > li > a, .skin-blue .main-header .navbar .sidebar-toggle { color: var(--color); }
    .skin-blue .main-header .navbar .nav > li > a:hover, .skin-blue .main-header .navbar .sidebar-toggle:hover { background: var(--secondary-hover); color: var(--highlight-color); }
    .skin-blue .main-header .navbar .user-image { border-radius: 50%; box-shadow: var(--clay-out-sm); }

    /* Sidebar */
    .skin-blue .main-sidebar, .skin-blue .left-side { background: var(--secondary); box-shadow: var(--clay-out); border-radius: 0 var(--clay-radius) var(--clay-radius) 0; margin: 0; padding-top: 50px; }
    .skin-blue .sidebar-menu > li.header { background: transparent; color: var(--color-5); font-weight: 800; letter-spacing: .08em; }
    .skin-blue .sidebar-menu > li > a { color: var(--color); border-left: 0; margin: 4px 12px; border-radius: var(--clay-radius-sm); font-weight: 700; }
    .skin-blue .sidebar-menu > li:hover > a, .skin-blue .sidebar-menu > li.active > a { background: var(--secondary-hover); color: var(--highlight-color); box-shadow: var(--clay-in); border-left: 0; }
    .skin-blue .sidebar-menu > li.active > a > i, .skin-blue .sidebar-menu > li:hover > a > i { color: var(--primary); }

    /* Cards */
    .box, .info-box, .small-box, .nav-tabs-custom, .modal-content, .well, .callout, .panel { background: var(--secondary); color: var(--color); border: 1px solid var(--clay-edge); border-top: 1px solid var(--clay-edge); border-radius: var(--clay-radius); box-shadow: var(--clay-out); }
    .box-header, .box-footer, .box-header.with-border, .modal-header, .modal-footer { background: transparent; border-color: rgba(128, 120, 190, .18); color: var(--highlight-color); }
    .box-header:first-child, .box-footer:last-child { border-radius: var(--clay-radius) var(--clay-radius) 0 0; }
    .box-footer { border-radius: 0 0 var(--clay-radius) var(--clay-radius); }
    .box.box-solid > .box-header { background: transparent; color: var(--highlight-color); }
    .box-title { color: var(--highlight-color); font-weight: 800; }

    /* Tabs */
    .nav-tabs-custom { margin-bottom: 22px; }
    .nav-tabs-custom > .nav-tabs { border-bottom: 0; padding: 8px 10px 0; }
    .nav-tabs-custom > .nav-tabs > li { margin-right: 6px; margin-bottom: 8px; }
    .nav-tabs-custom > .nav-tabs > li > a { color: var(--color); border: 0 !important; border-radius: 999px; font-weight: 700; padding: 8px 16px; }
    .nav-tabs-custom > .nav-tabs > li > a:hover { background: var(--secondary-hover); }
    .nav-tabs-custom > .nav-tabs > li.active > a, .nav-tabs-custom > .nav-tabs > li.active:hover > a { background: var(--secondary-hover); color: var(--primary); box-shadow: var(--clay-in); }
    .nav-tabs-custom > .nav-tabs > li.active { border-top: 0; }
    .nav-tabs-custom > .tab-content { background: transparent; }

    /* Forms */
    .form-control, .select2-container--default .select2-selection--single, .select2-container--default .select2-selection--multiple, .input-group-addon { background: var(--input); color: var(--color); border: 0 !important; border-radius: 16px; box-shadow: var(--clay-in); height: auto; min-height: 38px; padding: 8px 14px; }
    .form-control::placeholder { color: var(--color-5); }
    .form-control:focus { box-shadow: var(--clay-in), 0 0 0 3px rgba(124, 108, 242, .35); }
    .form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control { background: var(--input); opacity: .7; }
    input[type=color].form-control { padding: 4px; height: 44px; cursor: pointer; }
    input[type=file].form-control { padding: 8px 12px; }
    .select2-container--default .select2-selection--single .select2-selection__rendered { color: var(--color); line-height: 22px; padding-left: 0; }
    .select2-dropdown { background: var(--secondary); border: 0; border-radius: 16px; box-shadow: var(--clay-out-sm); }
    .select2-results__option { color: var(--color); }
    .select2-container--default .select2-results__option--highlighted[aria-selected] { background: var(--primary); color: #fff; }
    label, .control-label { color: var(--light-color); font-weight: 700; }

    /* Buttons */
    .btn { border: 0 !important; border-radius: 999px; font-weight: 800; padding: 8px 18px; box-shadow: var(--clay-btn); transition: transform .15s, box-shadow .15s, filter .15s; text-shadow: none; }
    .btn:hover { transform: translateY(-1px); filter: brightness(1.05); }
    .btn:active, .btn.active { transform: translateY(1px); box-shadow: var(--clay-in); }
    .btn-xs, .btn-sm { padding: 5px 14px; }
    .btn-primary { background: linear-gradient(145deg, var(--primary-hover), var(--primary)); color: #fff; }
    .btn-success { background: linear-gradient(145deg, #6fe0b0, #3ec58c); color: #fff; }
    .btn-danger { background: linear-gradient(145deg, var(--danger-hover), var(--danger)); color: #fff; }
    .btn-warning { background: linear-gradient(145deg, #ffd27a, #f6b342); color: #5b3b00; }
    .btn-info { background: linear-gradient(145deg, #7fd4ff, #4aaee8); color: #fff; }
    .btn-default { background: var(--secondary); color: var(--color); }
    .btn-default:hover { background: var(--secondary-hover); color: var(--highlight-color); }

    /* Tables / labels / alerts */
    .table > thead > tr > th, .table > tbody > tr > td, .table > tbody > tr > th { border-color: rgba(128, 120, 190, .16) !important; color: var(--color); }
    .table > thead > tr > th { color: var(--highlight-color); font-weight: 800; }
    .table-hover > tbody > tr:hover, .table-striped > tbody > tr:nth-of-type(odd) { background: var(--secondary-hover); }
    .box-body.table-responsive, .table-responsive { border: 0; }
    .label { border-radius: 999px; padding: .4em .9em; font-weight: 800; box-shadow: var(--clay-out-sm); }
    .alert { border: 0; border-radius: var(--clay-radius-sm); box-shadow: var(--clay-out-sm); }
    .pagination > li > a, .pagination > li > span { background: var(--secondary); color: var(--color); border: 0; border-radius: 12px; margin: 0 3px; box-shadow: var(--clay-out-sm); }
    .pagination > .active > a, .pagination > .active > span { background: var(--primary); color: #fff; }
    .dropdown-menu { background: var(--secondary); border: 0; border-radius: var(--clay-radius-sm); box-shadow: var(--clay-out-sm); }
    .dropdown-menu > li > a { color: var(--color); }
    .dropdown-menu > li > a:hover { background: var(--secondary-hover); color: var(--highlight-color); }
    .progress { background: var(--input); box-shadow: var(--clay-in); border-radius: 999px; }
    .progress-bar { border-radius: 999px; }
    code, pre { background: var(--input); color: var(--color); border: 0; border-radius: 10px; }
    hr { border-color: rgba(128, 120, 190, .2); }
    .sweet-alert { border-radius: var(--clay-radius); background: var(--secondary); }
    .sweet-alert h2, .sweet-alert p { color: var(--color); }

    /* Logo preview used on the theme settings page */
    .clay-logo-preview { display: inline-flex; align-items: center; gap: 12px; padding: 12px 18px; border-radius: var(--clay-radius-sm); background: var(--secondary); box-shadow: var(--clay-out-sm); }
    .clay-logo-preview img { width: 44px; height: 44px; object-fit: contain; border-radius: 14px; }
    .clay-logo-preview strong { color: var(--highlight-color); font-size: 16px; }
</style>
<script>
    // Same colour mode as the client area (toggled with the moon button there).
    document.addEventListener('DOMContentLoaded', function () {
        try { if (localStorage.getItem('modes') === 'darkMode') document.body.classList.add('darkmode'); } catch (e) {}
    });
</script>
