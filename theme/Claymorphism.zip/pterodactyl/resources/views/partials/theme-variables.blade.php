@php
    $ClayTheme = \Pterodactyl\Services\Theme\ThemeSettings::class;
    $t = $ClayTheme::get();
    $c = fn ($value) => $ClayTheme::css($value);
    $bg = trim((string) $t->backgroundimage);
@endphp
<style>
    :root {
        --highlight-color: {{ $c($t->highlightcolor) }};
        --light-color: {{ $c($t->lightcolor) }};
        --color: {{ $c($t->color) }};
        --sub-color: {{ $c($t->subcolor) }};
        --color-4: {{ $c($t->color4) }};
        --color-5: {{ $c($t->color5) }};
        --color-6: {{ $c($t->color6) }};
        --dark: {{ $c($t->dark) }};
        --background-color: {{ $c($t->background) }};
        --input: {{ $c($t->input) }};
        --primary: {{ $c($t->primary) }};
        --secondary: {{ $c($t->secondary) }};
        --primary-hover: {{ $c($t->primaryhover) }};
        --secondary-hover: {{ $c($t->secondaryhover) }};
        --danger: {{ $c($t->dangerbutton) }};
        --danger-hover: {{ $c($t->dangerbuttonhover) }};
        --text: {{ $c($t->textbutton) }};
        --text-hover: {{ $c($t->textbuttonhover) }};
        --black: #000000;
        --white: #ffffff;
        --borderradius: {{ (int) $t->borderradius }}px;

        /* Claymorphism tokens (default mode) */
        --clay-radius: 26px;
        --clay-radius-sm: 16px;
        --clay-edge: rgba(255, 255, 255, .65);
        --clay-shadow-dark: rgba(140, 132, 196, .50);
        --clay-shadow-light: rgba(255, 255, 255, .95);
        --clay-out: 12px 12px 28px var(--clay-shadow-dark), -10px -10px 24px var(--clay-shadow-light),
                    inset -5px -5px 12px rgba(124, 108, 242, .10), inset 5px 5px 12px rgba(255, 255, 255, .90);
        --clay-out-sm: 6px 6px 14px var(--clay-shadow-dark), -5px -5px 12px var(--clay-shadow-light),
                       inset -3px -3px 6px rgba(124, 108, 242, .10), inset 3px 3px 6px rgba(255, 255, 255, .90);
        --clay-in: inset 6px 6px 12px rgba(140, 132, 196, .45), inset -6px -6px 12px rgba(255, 255, 255, .95);
        --clay-btn: 7px 7px 16px var(--clay-shadow-dark), -5px -5px 12px var(--clay-shadow-light),
                    inset -4px -4px 9px rgba(0, 0, 0, .16), inset 4px 4px 9px rgba(255, 255, 255, .38);

        @if (empty($t->sidegraph)) --sidegraph: none; @endif
        @if (empty($t->subnavigation)) --subnavigation: none; @endif
        @if (empty($t->infoelement)) --infoelement: none; @endif
        @if (empty($t->graphcard)) --graphcard: none; @endif

        --website: {{ in_array($t->website, ['none', ''], true) ? 'none' : 'flex' }};
        --status: {{ in_array($t->status, ['none', ''], true) ? 'none' : 'flex' }};
        --billing: {{ in_array($t->billing, ['none', ''], true) ? 'none' : 'flex' }};
        --discord: {{ in_array($t->discord, ['none', ''], true) ? 'none' : 'flex' }};
        --knowledgebase: {{ in_array($t->knowledgebase, ['none', ''], true) ? 'none' : 'flex' }};
    }

    /* Mode toggled with the moon button */
    .darkmode {
        --highlight-color: {{ $c($t->lhighlightcolor) }};
        --light-color: {{ $c($t->llightcolor) }};
        --color: {{ $c($t->lcolor) }};
        --sub-color: {{ $c($t->lsubcolor) }};
        --color-4: {{ $c($t->lcolor4) }};
        --color-5: {{ $c($t->lcolor5) }};
        --color-6: {{ $c($t->lcolor6) }};
        --dark: {{ $c($t->ldark) }};
        --background-color: {{ $c($t->lbackground) }};
        --input: {{ $c($t->linput) }};
        --primary: {{ $c($t->lprimary) }};
        --secondary: {{ $c($t->lsecondary) }};
        --primary-hover: {{ $c($t->lprimaryhover) }};
        --secondary-hover: {{ $c($t->lsecondaryhover) }};
        --danger: {{ $c($t->ldangerbutton) }};
        --danger-hover: {{ $c($t->ldangerbuttonhover) }};
        --text: {{ $c($t->ltextbutton) }};
        --text-hover: {{ $c($t->ltextbuttonhover) }};
        --black: #ffffff;
        --white: #ffffff;

        --clay-edge: rgba(255, 255, 255, .06);
        --clay-shadow-dark: rgba(8, 7, 22, .70);
        --clay-shadow-light: rgba(84, 79, 138, .38);
        --clay-out: 12px 12px 28px var(--clay-shadow-dark), -8px -8px 22px var(--clay-shadow-light),
                    inset -5px -5px 12px rgba(0, 0, 0, .28), inset 5px 5px 12px rgba(255, 255, 255, .07);
        --clay-out-sm: 6px 6px 14px var(--clay-shadow-dark), -4px -4px 12px var(--clay-shadow-light),
                       inset -3px -3px 6px rgba(0, 0, 0, .25), inset 3px 3px 6px rgba(255, 255, 255, .06);
        --clay-in: inset 6px 6px 12px rgba(6, 5, 16, .65), inset -5px -5px 11px rgba(84, 79, 138, .30);
        --clay-btn: 7px 7px 16px var(--clay-shadow-dark), -4px -4px 12px var(--clay-shadow-light),
                    inset -4px -4px 9px rgba(0, 0, 0, .26), inset 4px 4px 9px rgba(255, 255, 255, .22);
    }

    body {
        background-color: var(--background-color);
        @if ($bg !== '')
        background-image: url("{{ $ClayTheme::url($bg) }}");
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        @else
        background-image: radial-gradient(1200px 700px at 8% -5%, rgba(124, 108, 242, .18), transparent 60%),
                          radial-gradient(900px 600px at 100% 100%, rgba(240, 101, 125, .12), transparent 60%);
        background-attachment: fixed;
        @endif
    }
</style>
