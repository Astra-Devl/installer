@php
    $ClayTheme = \Pterodactyl\Services\Theme\ThemeSettings::class;
    $clay = $ClayTheme::get();
    $clayName = $ClayTheme::siteName();
    $clayLogo = $ClayTheme::logo();
@endphp
<!DOCTYPE html>
<html>
    <head>
        <title>{{ $clayName }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">

            <meta property="og:type" content="website" />
            <meta property="og:image" content="{{ $clayLogo }}" />
            <meta property="og:description" content="{{ $clay->discription }}" />
            <meta property="twitter:title" content="{{ $clay->title }}" />
            <meta name="theme-color" content="{{ $ClayTheme::css($clay->metacolor) }}">

            <link rel="icon" href="{{ $clayLogo }}">
            <link rel="shortcut icon" href="{{ $clayLogo }}">
            <link rel="apple-touch-icon" href="{{ $clayLogo }}">
            <link rel="manifest" href="/favicons/manifest.json">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        @show

        @include('partials.theme-variables')

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        {{-- Public theme settings (logo, brand name, contact buttons). Available on the login page too. --}}
        <script>
            window.ThemeConfiguration = {{ \Illuminate\Support\Js::from($ClayTheme::publicConfig()) }};
        </script>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=IBM+Plex+Mono&display=swap" rel="stylesheet">

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        <script>
            // Apply the saved colour mode before the first paint to avoid a flash.
            try { if (localStorage.getItem('modes') === 'darkMode') document.body.classList.add('darkmode'); } catch (e) {}
        </script>
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
