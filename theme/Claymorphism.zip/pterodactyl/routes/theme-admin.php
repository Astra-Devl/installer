<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin\Theme;

/*
|--------------------------------------------------------------------------
| Claymorphism Theme Routes
|--------------------------------------------------------------------------
|
| Endpoint: /admin/theme
|
| This file is loaded from routes/admin.php (see install.sh), so it inherits
| the "admin" prefix and middleware group of the panel.
|
*/
Route::group(['prefix' => 'theme'], function () {
    Route::get('/', [Theme\ThemeController::class, 'index'])->name('admin.theme');
    Route::post('/update', [Theme\ThemeController::class, 'update'])->name('admin.theme.update');

    Route::get('/meta', [Theme\MetaController::class, 'index'])->name('admin.theme.meta');
    Route::post('/meta/update', [Theme\MetaController::class, 'update'])->name('admin.theme.meta.update');

    Route::get('/color', [Theme\ColorController::class, 'index'])->name('admin.theme.color');
    Route::post('/color/update', [Theme\ColorController::class, 'update'])->name('admin.theme.color.update');

    Route::get('/button', [Theme\ButtonController::class, 'index'])->name('admin.theme.button');
    Route::post('/button/update', [Theme\ButtonController::class, 'update'])->name('admin.theme.button.update');

    Route::get('/element', [Theme\ElementController::class, 'index'])->name('admin.theme.element');
    Route::post('/element/update', [Theme\ElementController::class, 'update'])->name('admin.theme.element.update');

    Route::get('/alert', [Theme\AlertController::class, 'index'])->name('admin.theme.alert');
    Route::post('/alert/update', [Theme\AlertController::class, 'update'])->name('admin.theme.alert.update');

    Route::get('/media', [Theme\SocialController::class, 'index'])->name('admin.theme.social');
    Route::post('/media/update', [Theme\SocialController::class, 'update'])->name('admin.theme.social.update');

    Route::get('/contact', [Theme\ContactController::class, 'index'])->name('admin.theme.contact');
    Route::post('/contact/update', [Theme\ContactController::class, 'update'])->name('admin.theme.contact.update');


});
