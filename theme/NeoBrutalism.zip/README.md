# NeoBrutalism Theme untuk Pterodactyl

Tema **NeoBrutalism** mandiri: border hitam tebal, bayangan keras tanpa blur,
warna datar mencolok, huruf Space Grotesk. Berlaku untuk **seluruh panel**: login, dashboard, halaman
server (console, file, database, dll), sidebar, modal, dropdown, dan area admin.

## Install
```bash
unzip NeoBrutalism.zip && cd NeoBrutalism
bash install.sh /var/www/pterodactyl
```
Installer: backup file lama → copy tema → pasang `routes/theme-admin.php` di bawah `routes/admin.php`
→ `php artisan migrate` → build frontend (`yarn build:production`, Node.js v22+).

Migrasi `2026_10_14_000001_neobrutalism_theme_settings` menambah semua kolom yang dibutuhkan tema. Panel lama yang
warnanya belum sesuai bisa memakai *Quick Presets → Neo Classic*.

## Fitur
- **Logo & nama header** bisa diganti (Admin → Theme → *General & Logo*): upload/URL logo, nama di samping logo,
  bentuk logo (kotak / rounded / lingkaran), dan opsi sembunyikan nama. Tampil di header admin, sidebar, dan login.
- **Notifikasi merah mengambang** menggantikan halaman 403/500 saat proteksi memblokir aksi
  (Admin → Theme → *Protection & Alert Toast*): warna peringatan, warna teks, judul, pesan (`:action`),
  posisi (6 pilihan), dan durasi bisa diatur + tombol *Test notification*.
- **Proteksi via middleware** (`app/Http/Middleware/Admin/NeoProtection.php`), bukan lagi `if` di tiap controller.
  Aksi yang bisa dikunci untuk admin non-utama: hapus server, hapus user, hapus lokasi, hapus node/alokasi,
  hapus nest, ubah pengaturan panel, ubah tema, buka halaman kelola server. ID admin yang diizinkan bisa diatur (ID 1 selalu boleh).
- Tombol hubungi pemilik (WhatsApp/Telegram) di bawah *Forgot Password* tetap ada (Admin → Theme → *Contact Settings*).
- Pengaturan gaya baru di *Buttons & Input*: radius sudut, tebal border, ukuran bayangan.
- Mode malam (tombol bulan) tetap ada: kertas gelap, tinta terang. Semua warna bisa diubah di *Color Settings*.

## Catatan
- Guard `if (id !== 1)` yang dulu ditanam di controller/`ServerDeletionService` sudah dihapus (digantikan middleware),
  sehingga hapus server lewat **Application API** (mis. billing) tidak ikut terblokir.
- Middleware dipasang ke semua route `admin/*` dari `routes/theme-admin.php` — file itu harus di-`require` paling akhir
  di `routes/admin.php` (installer sudah melakukannya). `app/Http/Kernel.php` tidak perlu diubah.

## Pembaruan (versi ini)
**Dashboard** - banner hero + hitungan server, filter pencarian (halaman aktif), tombol Cards/Table per pengguna
(default mengikuti pengaturan admin), kartu server dengan strip status + meter CPU/RAM/Disk, tabel dengan meter mini.
**Console** - header info server dengan status pill, kartu CPU/RAM/Disk dengan bar pemakaian + uptime & network,
panel samping flat, terminal bergaya jendela (title bar, LIVE badge), grafik berwarna Neo.
**Admin Theme** - *Quick Presets* (6 tampilan sekali klik), *Live Preview* di Color Settings & Buttons, Elements Manager
berbentuk kartu toggle, ikon di tab navigasi.

### Perbaikan bug
- Controller Color/Meta/Alert/Social/Element/Button kini divalidasi; field kosong tidak lagi jadi NULL -> error 500.
- Pager mode kartu tidak lagi terjepit di dalam grid; tabel memakai thead/tbody yang valid.
- Label status "Running" yang salah untuk Starting/Stopping diganti label yang benar.
- Interval statistik server tidak bocor lagi saat kartu di-unmount.
- Pembungkus elemen (stat card, side graph, sub navigation) tidak lagi jatuh ke `display:inline`.
- SideGraph tidak lagi mendaftarkan listener statistik dua kali.
