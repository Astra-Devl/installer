# NeoBrutalism Theme untuk Pterodactyl

Hasil ubah total dari Claymorphism → **NeoBrutalism**: border hitam tebal, bayangan keras tanpa blur,
warna datar mencolok, huruf Space Grotesk. Berlaku untuk **seluruh panel**: login, dashboard, halaman
server (console, file, database, dll), sidebar, modal, dropdown, dan area admin.

## Install
```bash
unzip NeoBrutalism.zip && cd NeoBrutalism
bash install.sh /var/www/pterodactyl
```
Installer: backup file lama → copy tema → pasang `routes/theme-admin.php` di bawah `routes/admin.php`
→ `php artisan migrate` → build frontend (`yarn build:production`, Node.js v22+).

Panel yang sudah memakai Claymorphism: cukup jalankan installer; migrasi
`2026_10_14_000001_neobrutalism_theme_settings` mengganti warna bawaan Claymorphism ke palet Neo
(warna yang sudah Anda ubah sendiri tidak ditimpa).

## Fitur
- **Logo & nama header** bisa diganti (Admin → Theme → *General & Logo*): upload/URL logo, nama di samping logo,
  bentuk logo (kotak / rounded / lingkaran), dan opsi sembunyikan nama. Tampil di header admin, sidebar, dan login.
- **Notifikasi merah mengambang** menggantikan halaman 403/500 saat proteksi memblokir aksi
  (Admin → Theme → *Protection & Alert Toast*): warna peringatan, warna teks, judul, pesan (`:action`),
  posisi (6 pilihan), dan durasi bisa diatur + tombol *Test notification*.
- **Proteksi via middleware** (`app/Http/Middleware/Admin/NeoProtection.php`), bukan lagi `if` di tiap controller.
  Aksi yang bisa dikunci untuk admin non-utama: hapus server, hapus user, hapus lokasi, hapus node/alokasi,
  hapus nest, ubah pengaturan panel, ubah tema, buka halaman kelola server. ID admin yang diizinkan bisa diatur (ID 1 selalu boleh).
- Tombol hubungi pemilik (WhatsApp/Telegram) di bawah *Forgot Password* tetap ada (Admin → Theme → *Contact Settings*).
- Pengaturan gaya baru di *Buttons & Input*: radius sudut, tebal border, ukuran bayangan.
- Mode malam (tombol bulan) tetap ada: kertas gelap, tinta terang. Semua warna bisa diubah di *Color Settings*.

## Catatan
- Guard `if (id !== 1)` yang dulu ditanam di controller/`ServerDeletionService` sudah dihapus (digantikan middleware),
  sehingga hapus server lewat **Application API** (mis. billing) tidak ikut terblokir.
- Middleware dipasang ke semua route `admin/*` dari `routes/theme-admin.php` — file itu harus di-`require` paling akhir
  di `routes/admin.php` (installer sudah melakukannya). `app/Http/Kernel.php` tidak perlu diubah.
