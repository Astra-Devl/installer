#!/usr/bin/env bash
# NeoBrutalism theme installer for Pterodactyl Panel (idempotent, safe to run again).
# Usage:  bash install.sh [/var/www/pterodactyl]
set -euo pipefail

PANEL="${1:-/var/www/pterodactyl}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/pterodactyl"

[ -f "$PANEL/artisan" ] || { echo "Panel tidak ditemukan di $PANEL (artisan tidak ada)."; exit 1; }
[ -d "$SRC" ] || { echo "Folder 'pterodactyl' tidak ada di sebelah install.sh."; exit 1; }

echo "==> Backup file panel yang akan ditimpa"
BACKUP="$PANEL/storage/neobrutalism-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
( cd "$SRC" && find . -type f ) | while read -r f; do
  if [ -f "$PANEL/$f" ]; then mkdir -p "$BACKUP/$(dirname "$f")"; cp -p "$PANEL/$f" "$BACKUP/$f"; fi
done

echo "==> Copy file tema"
cp -r "$SRC"/. "$PANEL"/
mkdir -p "$PANEL/public/uploads/theme"

echo "==> Daftarkan routes/theme-admin.php di PALING BAWAH routes/admin.php"
ADMIN_ROUTES="$PANEL/routes/admin.php"
sed -i "/theme-admin\.php/d" "$ADMIN_ROUTES"
printf "\nrequire base_path('routes/theme-admin.php');\n" >> "$ADMIN_ROUTES"

cd "$PANEL"
echo "==> Migrasi database"
php artisan migrate --force
php artisan view:clear
php artisan config:clear
php artisan route:clear
php artisan cache:clear

echo "==> Build frontend (Node.js v22+ disarankan)"
if command -v yarn >/dev/null 2>&1; then
  export NODE_OPTIONS="--openssl-legacy-provider"
  yarn install --frozen-lockfile || yarn install
  yarn build:production
else
  echo "yarn tidak ditemukan. Jalankan manual:  npm i -g yarn && yarn install && yarn build:production"
fi

if id www-data >/dev/null 2>&1; then chown -R www-data:www-data "$PANEL"; fi
php artisan queue:restart || true

echo
echo "Selesai. Buka /admin/theme  ->  tab 'Protection & Alert Toast' untuk atur warna notifikasi merah."
echo "Backup file lama: $BACKUP"
