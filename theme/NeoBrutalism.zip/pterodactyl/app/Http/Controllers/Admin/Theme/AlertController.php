<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class AlertController extends Controller
{
    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.alert', ['theme' => ThemeSettings::get()]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'typealert' => ['required', 'in:disabled,info,warning,error,success'],
            'alertdescription' => ['nullable', 'string', 'max:255'],
        ]);

        // The client area treats "none" as "no text".
        $description = trim((string) ($data['alertdescription'] ?? ''));

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update([
            'typealert' => $data['typealert'],
            'alertdescription' => $description !== '' ? $description : 'none',
            'updated_at' => now(),
        ]);
        ThemeSettings::flush();

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
