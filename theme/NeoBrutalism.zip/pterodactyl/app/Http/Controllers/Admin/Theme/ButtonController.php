<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Services\Theme\ThemeSettings;
use Pterodactyl\Http\Controllers\Controller;

class ButtonController extends Controller
{
    /** Colour columns edited on the Buttons & Input page. */
    private const COLORS = [
        'textbutton', 'textbuttonhover', 'dangerbutton', 'dangerbuttonhover',
        'ltextbutton', 'ltextbuttonhover', 'ldangerbutton', 'ldangerbuttonhover',
        'primary', 'primaryhover', 'lprimary', 'lprimaryhover',
        'input', 'linput',
    ];

    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.button', ['theme' => ThemeSettings::get()]);
    }

    public function update(Request $request)
    {
        $rules = [
            'borderradius' => ['required', 'integer', 'min:0', 'max:32'],
            'borderwidth' => ['required', 'integer', 'min:1', 'max:6'],
            'shadowsize' => ['required', 'integer', 'min:0', 'max:14'],
        ];
        foreach (self::COLORS as $key) {
            $rules[$key] = ['nullable', 'regex:' . ThemeSettings::HEX];
        }

        $data = $request->validate($rules, ['*.regex' => 'Colours must be hex values such as #ffd93d.']);

        $values = [
            'borderradius' => (int) $data['borderradius'],
            'borderwidth' => (int) $data['borderwidth'],
            'shadowsize' => (int) $data['shadowsize'],
            'updated_at' => now(),
        ];
        foreach (self::COLORS as $key) {
            if (!empty($data[$key])) {
                $values[$key] = strtolower($data[$key]);
            }
        }

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update($values);
        ThemeSettings::flush();

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
