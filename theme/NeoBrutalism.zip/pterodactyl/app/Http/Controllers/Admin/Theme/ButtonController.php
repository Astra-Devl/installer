<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Services\Theme\ThemeSettings;
use Pterodactyl\Http\Controllers\Controller;

class ButtonController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.button', ['theme' => ThemeSettings::get()]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'borderradius' => ['required', 'integer', 'min:0', 'max:32'],
            'borderwidth' => ['required', 'integer', 'min:1', 'max:6'],
            'shadowsize' => ['required', 'integer', 'min:0', 'max:14'],
        ]);

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update([
            'textbutton' => $request->textbutton,
            'textbuttonhover' => $request->textbuttonhover,
            'dangerbutton' => $request->dangerbutton,
            'dangerbuttonhover' => $request->dangerbuttonhover,
            'ltextbutton' => $request->ltextbutton,
            'ltextbuttonhover' => $request->ltextbuttonhover,
            'ldangerbutton' => $request->ldangerbutton,
            'ldangerbuttonhover' => $request->ldangerbuttonhover,
            'primary' => $request->primary,
            'primaryhover' => $request->primaryhover,
            'lprimary' => $request->lprimary,
            'lprimaryhover' => $request->lprimaryhover,
            'borderradius' => (int) $request->borderradius,
            'borderwidth' => (int) $request->borderwidth,
            'shadowsize' => (int) $request->shadowsize,
            'input' => $request->input('input'),
            'linput' => $request->linput,
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
