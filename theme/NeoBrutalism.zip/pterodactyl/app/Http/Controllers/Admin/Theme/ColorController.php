<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class ColorController extends Controller
{
    /** Every colour column edited on the Color Settings page. */
    private const KEYS = [
        'highlightcolor', 'lightcolor', 'color', 'subcolor', 'color4', 'color5', 'color6', 'dark',
        'primary', 'primaryhover', 'secondary', 'secondaryhover', 'background',
        'lhighlightcolor', 'llightcolor', 'lcolor', 'lsubcolor', 'lcolor4', 'lcolor5', 'lcolor6', 'ldark',
        'lprimary', 'lprimaryhover', 'lsecondary', 'lsecondaryhover', 'lbackground',
    ];

    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.color', ['theme' => ThemeSettings::get()]);
    }

    /**
     * Only valid hex colours are stored. A field that is missing from the form keeps its current value
     * (the old version wrote NULL into the NOT NULL columns, which ended in a 500 error).
     */
    public function update(Request $request)
    {
        $rules = [];
        foreach (self::KEYS as $key) {
            $rules[$key] = ['nullable', 'regex:' . ThemeSettings::HEX];
        }

        $data = $request->validate($rules, ['*.regex' => 'Colours must be hex values such as #ffd93d.']);

        $values = [];
        foreach (self::KEYS as $key) {
            if (!empty($data[$key])) {
                $values[$key] = strtolower($data[$key]);
            }
        }

        if (count($values) > 0) {
            $existing = DB::table('theme')->first();
            DB::table('theme')->where('id', $existing->id)->update($values + ['updated_at' => now()]);
            ThemeSettings::flush();
        }

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
