<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class ContactController extends Controller
{
    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.contact', ['theme' => ThemeSettings::get()]);
    }

    /**
     * Saves the "contact website owner" button shown on the login page.
     */
    public function update(Request $request)
    {
        $request->merge([
            'contact_whatsapp' => ThemeSettings::normalizeWhatsapp($request->input('contact_whatsapp')),
            'contact_telegram' => ThemeSettings::normalizeTelegram($request->input('contact_telegram')),
        ]);

        $data = $request->validate([
            'contact_label' => ['required', 'string', 'max:60'],
            'contact_whatsapp' => ['nullable', 'regex:/^[1-9][0-9]{7,14}$/'],
            'contact_telegram' => ['nullable', 'regex:/^[A-Za-z0-9_]{5,32}$/'],
            'contact_message' => ['nullable', 'string', 'max:200'],
        ], [
            'contact_whatsapp.regex' => 'WhatsApp number must be 8-15 digits including the country code (e.g. 6281234567890).',
            'contact_telegram.regex' => 'Telegram username must be 5-32 characters: letters, numbers and underscores only.',
        ]);

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update([
            'contact_enabled' => $request->boolean('contact_enabled') ? 1 : 0,
            'contact_label' => trim($data['contact_label']),
            'contact_whatsapp' => $data['contact_whatsapp'] ?? '',
            'contact_telegram' => $data['contact_telegram'] ?? '',
            'contact_message' => trim((string) ($data['contact_message'] ?? '')),
            'updated_at' => now(),
        ]);

        $this->alert->success('Contact settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
