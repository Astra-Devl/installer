<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class ElementController extends Controller
{
    private const TOGGLES = ['infoelement', 'graphcard', 'sidegraph', 'subnavigation'];

    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.element', ['theme' => ThemeSettings::get()]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'newserverlist' => ['required', 'in:table,cards'],
        ]);

        $values = ['newserverlist' => $data['newserverlist'], 'updated_at' => now()];
        foreach (self::TOGGLES as $toggle) {
            $values[$toggle] = $request->boolean($toggle) ? 1 : 0;
        }

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update($values);
        ThemeSettings::flush();

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
