<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class MetaController extends Controller
{
    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.meta', ['theme' => ThemeSettings::get()]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:100'],
            'discription' => ['required', 'string', 'max:255'],
            'metacolor' => ['nullable', 'regex:' . ThemeSettings::HEX],
        ], ['metacolor.regex' => 'Meta colour must be a hex colour such as #ffd93d.']);

        $values = [
            'title' => trim($data['title']),
            'discription' => trim($data['discription']),
            'updated_at' => now(),
        ];
        if (!empty($data['metacolor'])) {
            $values['metacolor'] = strtolower($data['metacolor']);
        }

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update($values);
        ThemeSettings::flush();

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
