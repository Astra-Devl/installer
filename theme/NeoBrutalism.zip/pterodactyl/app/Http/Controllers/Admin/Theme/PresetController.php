<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemePresets;
use Pterodactyl\Services\Theme\ThemeSettings;

class PresetController extends Controller
{
    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    /**
     * Applies one of the ready-made looks. Only colours, corner radius, border width and shadow
     * size change. The NeoProtection middleware treats this like every other theme save.
     */
    public function update(Request $request)
    {
        $data = $request->validate(['preset' => ['required', 'string', 'max:40']]);

        if (!ThemePresets::exists($data['preset'])) {
            $this->alert->danger('That preset does not exist.')->flash();

            return redirect()->back();
        }

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update(array_merge(
            ThemePresets::values($data['preset']),
            ['updated_at' => now()]
        ));

        ThemeSettings::flush();
        $this->alert->success('Preset "' . ThemePresets::all()[$data['preset']]['name'] . '" has been applied.')->flash();

        return redirect()->back();
    }
}
