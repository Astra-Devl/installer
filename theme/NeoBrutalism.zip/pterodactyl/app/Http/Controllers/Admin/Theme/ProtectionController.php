<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class ProtectionController extends Controller
{
    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.protection', [
            'theme' => ThemeSettings::get(),
            'protection' => ThemeSettings::protection(),
        ]);
    }

    /**
     * Saves the protection middleware settings and the look of the floating red notification.
     */
    public function update(Request $request)
    {
        $color = ['required', 'regex:/^#[0-9a-fA-F]{6}$/'];

        $data = $request->validate([
            'antirusuh_title' => ['required', 'string', 'max:40'],
            'antirusuh_message' => ['required', 'string', 'max:200'],
            'antirusuh_color' => $color,
            'antirusuh_textcolor' => $color,
            'antirusuh_position' => ['required', 'in:' . implode(',', ThemeSettings::TOAST_POSITIONS)],
            'antirusuh_duration' => ['required', 'integer', 'min:0', 'max:60'],
            'antirusuh_allowed' => ['nullable', 'regex:/^[0-9,\s]*$/', 'max:100'],
            'rules' => ['nullable', 'array'],
            'rules.*' => ['string', 'in:' . implode(',', array_keys(ThemeSettings::PROTECTION_RULES))],
        ], [
            'antirusuh_color.regex' => 'Warning colour must be a hex colour such as #ff3b30.',
            'antirusuh_textcolor.regex' => 'Text colour must be a hex colour such as #ffffff.',
            'antirusuh_allowed.regex' => 'Allowed admin IDs may only contain numbers separated by commas.',
        ]);

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update([
            'antirusuh_enabled' => $request->boolean('antirusuh_enabled') ? 1 : 0,
            'antirusuh_rules' => implode(',', $data['rules'] ?? []),
            'antirusuh_allowed' => trim((string) ($data['antirusuh_allowed'] ?? '')) !== '' ? trim($data['antirusuh_allowed']) : '1',
            'antirusuh_title' => trim($data['antirusuh_title']),
            'antirusuh_message' => trim($data['antirusuh_message']),
            'antirusuh_color' => strtolower($data['antirusuh_color']),
            'antirusuh_textcolor' => strtolower($data['antirusuh_textcolor']),
            'antirusuh_position' => $data['antirusuh_position'],
            'antirusuh_duration' => (int) $data['antirusuh_duration'],
            'updated_at' => now(),
        ]);

        ThemeSettings::flush();
        $this->alert->success('Protection settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
