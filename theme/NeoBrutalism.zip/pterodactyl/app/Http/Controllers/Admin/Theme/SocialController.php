<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Theme\ThemeSettings;

class SocialController extends Controller
{
    private const FIELDS = ['website', 'discord', 'billing', 'status', 'knowledgebase'];

    private AlertsMessageBag $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        return view('admin.theme.social', ['theme' => ThemeSettings::get()]);
    }

    /**
     * A link is either "none" (button hidden) or a full http(s) URL. Empty fields become "none"
     * (they used to be written as NULL, which the NOT NULL columns refuse with a 500 error).
     */
    public function update(Request $request)
    {
        $rule = ['nullable', 'string', 'max:255', 'regex:/^(none|https?:\/\/[^\s"\'<>()\\\\]+)$/i'];
        $rules = [];
        foreach (self::FIELDS as $field) {
            $rules[$field] = $rule;
        }

        $data = $request->validate($rules, ['*.regex' => 'Use "none" to hide a button, otherwise a full link starting with https://']);

        $values = ['updated_at' => now()];
        foreach (self::FIELDS as $field) {
            $value = trim((string) ($data[$field] ?? ''));
            $values[$field] = $value !== '' ? $value : 'none';
        }

        $existing = DB::table('theme')->first();
        DB::table('theme')->where('id', $existing->id)->update($values);
        ThemeSettings::flush();

        $this->alert->success('Theme settings have been updated successfully.')->flash();

        return redirect()->back();
    }
}
