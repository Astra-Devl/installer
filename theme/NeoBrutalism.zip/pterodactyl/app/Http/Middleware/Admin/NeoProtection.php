<?php

namespace Pterodactyl\Http\Middleware\Admin;

use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Pterodactyl\Services\Theme\ThemeSettings;
use Symfony\Component\HttpFoundation\Response;

/**
 * NeoBrutalism protection middleware.
 *
 * Dangerous admin actions (delete server / user / location / node / nest, change panel settings, ...)
 * are only allowed for the main administrator(s). Everybody else is NOT sent to a 403 / 500 page:
 * the action is simply cancelled, the visitor is returned to the page they came from and a red
 * floating notification is shown. Colour, text, position and duration of that notification are
 * configured in Admin > Theme > Protection.
 *
 * The middleware is attached to every "admin/*" route by routes/theme-admin.php, so no changes
 * to app/Http/Kernel.php are needed. Rules are matched on the controller action, which means they
 * also work for the admin routes that have no route name.
 */
class NeoProtection
{
    private const NS = 'Pterodactyl\\Http\\Controllers\\Admin\\';

    /** Controller action (relative to the Admin namespace) => rule key. */
    private const ACTIONS = [
        'ServersController@delete' => 'delete_server',
        'UserController@delete' => 'users',
        'LocationController@delete' => 'locations',
        'NodesController@delete' => 'nodes',
        'NodesController@allocationRemoveSingle' => 'nodes',
        'NodesController@allocationRemoveMultiple' => 'nodes',
        'NodesController@allocationRemoveBlock' => 'nodes',
        'Nests\\NestController@destroy' => 'nests',
        'Settings\\IndexController@update' => 'settings',
        'Settings\\AdvancedController@update' => 'settings',
        'Settings\\MailController@update' => 'settings',
    ];

    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if ($user === null) {
            return $next($request);
        }

        $config = ThemeSettings::protection();
        if (!$config['enabled'] || in_array((int) $user->id, $config['allowed'], true)) {
            return $next($request);
        }

        $rule = $this->matchRule($request);
        if ($rule === null || !in_array($rule, $config['rules'], true)) {
            return $next($request);
        }

        return $this->deny($request, $rule, $config);
    }

    private function matchRule(Request $request): ?string
    {
        $route = $request->route();
        $action = $route ? (string) $route->getActionName() : '';

        if (str_starts_with($action, self::NS)) {
            $short = substr($action, strlen(self::NS));

            if (isset(self::ACTIONS[$short])) {
                return self::ACTIONS[$short];
            }

            // Locations are deleted through the update form (action=delete).
            if ($short === 'LocationController@update' && $request->input('action') === 'delete') {
                return 'locations';
            }

            // Every save button of the theme manager.
            if (str_starts_with($short, 'Theme\\') && str_ends_with($short, '@update')) {
                return 'theme';
            }
        }

        // Opening the management pages of a server in the admin area.
        if ($request->isMethod('GET') && $request->is('admin/servers/view/*')) {
            return 'server_access';
        }

        return null;
    }

    private function deny(Request $request, string $rule, array $config): Response
    {
        $label = ThemeSettings::PROTECTION_RULES[$rule] ?? 'melakukan aksi ini';
        $message = trim($config['message']) !== '' ? $config['message'] : 'Hanya admin utama yang boleh :action.';
        $message = str_replace(':action', $label, $message);

        // Scripted calls (e.g. removing an allocation) cannot follow a redirect: answer with a
        // refused-but-friendly JSON payload, the admin layout turns it into the same red toast.
        if ($request->ajax() || $request->expectsJson()) {
            return new JsonResponse([
                'error' => $message,
                'neo_blocked' => true,
                'toast' => $config['toast'],
            ], 422, ['X-Neo-Blocked' => '1']);
        }

        $request->session()->flash('neo_toast', [
            'message' => $message,
            'rule' => $rule,
        ]);

        return redirect()->to($this->returnUrl($request));
    }

    private function returnUrl(Request $request): string
    {
        $fallback = route('admin.index');
        $previous = (string) url()->previous($fallback);
        $path = (string) parse_url($previous, PHP_URL_PATH);

        // Never bounce back to the page that was just refused.
        if ($previous === $request->fullUrl() || rtrim($path, '/') === rtrim($request->getPathInfo(), '/')) {
            return $request->isMethod('GET') ? route('admin.servers') : $fallback;
        }

        if ($request->isMethod('GET') && str_contains($path, '/admin/servers/view/')) {
            return route('admin.servers');
        }

        return $previous;
    }
}
