<?php

namespace Pterodactyl\Services\Theme;

/**
 * One-click looks for the NeoBrutalism theme (Admin > Theme > General & Logo > Quick Presets).
 *
 * A preset only touches colours, corner radius, border width and shadow size. Logo, names, links,
 * protection and element toggles are left alone. Whatever a preset does not list falls back to the
 * NeoBrutalism default, so applying a preset always produces a complete, consistent palette.
 */
class ThemePresets
{
    /** Columns a preset controls. */
    public const KEYS = [
        'highlightcolor', 'lightcolor', 'color', 'subcolor', 'color4', 'color5', 'color6', 'dark',
        'primary', 'primaryhover', 'secondary', 'secondaryhover', 'background', 'input',
        'lhighlightcolor', 'llightcolor', 'lcolor', 'lsubcolor', 'lcolor4', 'lcolor5', 'lcolor6', 'ldark',
        'lprimary', 'lprimaryhover', 'lsecondary', 'lsecondaryhover', 'lbackground', 'linput',
        'dangerbutton', 'dangerbuttonhover', 'textbutton', 'textbuttonhover',
        'ldangerbutton', 'ldangerbuttonhover', 'ltextbutton', 'ltextbuttonhover',
        'metacolor', 'borderradius', 'borderwidth', 'shadowsize',
    ];

    public static function all(): array
    {
        return [
            'neo-classic' => [
                'name' => 'Neo Classic',
                'note' => 'Cream paper, yellow stickers, violet buttons.',
                'values' => [],
            ],
            'bubblegum' => [
                'name' => 'Bubblegum',
                'note' => 'Pink paper, softer corners.',
                'values' => [
                    'background' => '#ffe0f0', 'secondary' => '#ffffff', 'secondaryhover' => '#ffcfe6', 'input' => '#ffffff',
                    'primary' => '#d6197a', 'primaryhover' => '#b8106a',
                    'textbutton' => '#ffd93d', 'textbuttonhover' => '#ffc800',
                    'dangerbutton' => '#ff5252', 'dangerbuttonhover' => '#e03131',
                    'metacolor' => '#ff6bb5',
                    'lbackground' => '#1d1018', 'lsecondary' => '#2b1823', 'lsecondaryhover' => '#3a2030', 'linput' => '#22131c',
                    'lprimary' => '#ff8ac4', 'lprimaryhover' => '#ffa6d3',
                    'borderradius' => '12', 'borderwidth' => '3', 'shadowsize' => '6',
                ],
            ],
            'mint-fresh' => [
                'name' => 'Mint Fresh',
                'note' => 'Green paper, square corners, deep shadows.',
                'values' => [
                    'background' => '#d9f7e6', 'secondary' => '#ffffff', 'secondaryhover' => '#bff0d4', 'input' => '#ffffff',
                    'primary' => '#087f5b', 'primaryhover' => '#066649',
                    'textbutton' => '#ffe066', 'textbuttonhover' => '#ffd43b',
                    'dangerbutton' => '#ff6b6b', 'dangerbuttonhover' => '#e03131',
                    'metacolor' => '#3ddc97',
                    'lbackground' => '#0e1a14', 'lsecondary' => '#162820', 'lsecondaryhover' => '#1f362b', 'linput' => '#122019',
                    'lprimary' => '#69db7c', 'lprimaryhover' => '#8ce99a',
                    'borderradius' => '0', 'borderwidth' => '4', 'shadowsize' => '8',
                ],
            ],
            'sunset-pop' => [
                'name' => 'Sunset Pop',
                'note' => 'Peach paper, burnt orange buttons.',
                'values' => [
                    'background' => '#ffe8cc', 'secondary' => '#ffffff', 'secondaryhover' => '#ffd8a8', 'input' => '#ffffff',
                    'primary' => '#c2410c', 'primaryhover' => '#9a3412',
                    'textbutton' => '#ffd93d', 'textbuttonhover' => '#ffc800',
                    'dangerbutton' => '#ff4d4d', 'dangerbuttonhover' => '#e03131',
                    'metacolor' => '#ff9f1c',
                    'lbackground' => '#1c120a', 'lsecondary' => '#2a1b10', 'lsecondaryhover' => '#3a2616', 'linput' => '#22160d',
                    'lprimary' => '#ffa94d', 'lprimaryhover' => '#ffc078',
                    'borderradius' => '6', 'borderwidth' => '3', 'shadowsize' => '6',
                ],
            ],
            'ocean-blue' => [
                'name' => 'Ocean Blue',
                'note' => 'Sky paper, royal blue buttons.',
                'values' => [
                    'background' => '#dbeafe', 'secondary' => '#ffffff', 'secondaryhover' => '#bfdbfe', 'input' => '#ffffff',
                    'primary' => '#1d4ed8', 'primaryhover' => '#1e40af',
                    'textbutton' => '#ffd93d', 'textbuttonhover' => '#ffc800',
                    'dangerbutton' => '#ff5c5c', 'dangerbuttonhover' => '#e03131',
                    'metacolor' => '#4d96ff',
                    'lbackground' => '#0b1220', 'lsecondary' => '#121c30', 'lsecondaryhover' => '#1b2a47', 'linput' => '#0f182a',
                    'lprimary' => '#74a7ff', 'lprimaryhover' => '#9bbfff',
                    'borderradius' => '8', 'borderwidth' => '3', 'shadowsize' => '5',
                ],
            ],
            'mono-ink' => [
                'name' => 'Mono Ink',
                'note' => 'Newsprint grey, black buttons, no curves.',
                'values' => [
                    'background' => '#f2f2ee', 'secondary' => '#ffffff', 'secondaryhover' => '#e6e6df', 'input' => '#ffffff',
                    'primary' => '#111111', 'primaryhover' => '#333333',
                    'textbutton' => '#ffe66d', 'textbuttonhover' => '#ffd93d',
                    'dangerbutton' => '#ff4d4d', 'dangerbuttonhover' => '#e03131',
                    'metacolor' => '#111111',
                    'lbackground' => '#0c0c0c', 'lsecondary' => '#1a1a1a', 'lsecondaryhover' => '#262626', 'linput' => '#141414',
                    'lprimary' => '#f5f5f5', 'lprimaryhover' => '#ffffff',
                    'borderradius' => '0', 'borderwidth' => '3', 'shadowsize' => '6',
                ],
            ],
        ];
    }

    public static function exists(string $key): bool
    {
        return array_key_exists($key, self::all());
    }

    /** Complete column => value map of a preset (empty for an unknown key). */
    public static function values(string $key): array
    {
        $preset = self::all()[$key] ?? null;
        if ($preset === null) {
            return [];
        }

        $merged = array_merge(ThemeSettings::defaults(), $preset['values']);

        return array_intersect_key($merged, array_flip(self::KEYS));
    }

    /** The colours shown as small squares in the gallery. */
    public static function swatches(string $key): array
    {
        $v = self::values($key);

        return [$v['background'], $v['secondary'], $v['primary'], $v['textbutton'], $v['dangerbutton'], $v['lbackground']];
    }
}
