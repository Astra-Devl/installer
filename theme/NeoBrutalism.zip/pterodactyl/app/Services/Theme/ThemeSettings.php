<?php

namespace Pterodactyl\Services\Theme;

use Illuminate\Support\Facades\DB;

/**
 * Single source of truth for the NeoBrutalism theme settings.
 *
 * Every read goes through get(), which never throws: if the `theme` table (or a newly
 * added column) is missing because migrations have not been run yet, the defaults below
 * are used instead, so the login page can never crash with a 500 error.
 */
class ThemeSettings
{
    public const DEFAULT_LOGO = '/favicons/favicon-32x32.png';

    private static ?object $cache = null;

    /**
     * Rules of the protection middleware (Admin > Theme > Protection). The key is stored in the
     * `antirusuh_rules` column, the value is the text that replaces ":action" in the toast message.
     */
    public const PROTECTION_RULES = [
        'delete_server' => 'menghapus server',
        'users' => 'menghapus pengguna',
        'locations' => 'menghapus lokasi',
        'nodes' => 'menghapus node atau alokasi',
        'nests' => 'menghapus Nest',
        'settings' => 'mengubah pengaturan panel',
        'theme' => 'mengubah pengaturan tema',
        'server_access' => 'membuka halaman kelola server',
    ];

    public const TOAST_POSITIONS = ['top-right', 'top-center', 'top-left', 'bottom-right', 'bottom-center', 'bottom-left'];

    /**
     * NeoBrutalism default palette. Base keys = default mode (cream paper, black ink),
     * keys prefixed with "l" = mode that is toggled with the moon button (night paper, light ink).
     */
    public static function defaults(): array
    {
        return [
            'logo' => self::DEFAULT_LOGO,
            'longlogo' => self::DEFAULT_LOGO,
            'sitename' => '',
            'backgroundimage' => '',
            'title' => 'NeoBrutalism Panel',
            'discription' => 'Game server control panel',
            'metacolor' => '#ffd93d',

            'highlightcolor' => '#000000', 'lightcolor' => '#111111', 'color' => '#1a1a1a',
            'subcolor' => '#333333', 'color4' => '#4d4d4d', 'color5' => '#666666', 'color6' => '#8a8a8a',
            'dark' => '#1a1a1a', 'primary' => '#6c4dff', 'primaryhover' => '#5a3bf0',
            'secondary' => '#ffffff', 'secondaryhover' => '#fff1b8', 'background' => '#fff4d6', 'input' => '#ffffff',

            'lhighlightcolor' => '#ffffff', 'llightcolor' => '#f2eee2', 'lcolor' => '#e6e1d2',
            'lsubcolor' => '#cbc5b4', 'lcolor4' => '#aaa493', 'lcolor5' => '#8c8678', 'lcolor6' => '#6e695d',
            'ldark' => '#0b0b0b', 'lprimary' => '#a594ff', 'lprimaryhover' => '#bcb0ff',
            'lsecondary' => '#1f1f1f', 'lsecondaryhover' => '#2c2c2c', 'lbackground' => '#121212', 'linput' => '#181818',

            'dangerbutton' => '#ff4d4d', 'dangerbuttonhover' => '#e03131',
            'textbutton' => '#ffd93d', 'textbuttonhover' => '#ffc800',
            'ldangerbutton' => '#ff6b6b', 'ldangerbuttonhover' => '#ff8787',
            'ltextbutton' => '#ffd93d', 'ltextbuttonhover' => '#ffc800',
            'borderradius' => '4', 'borderwidth' => '3', 'shadowsize' => '6',
            'logoshape' => 'square', 'shownamelogo' => 1,

            'subnavigation' => 1, 'graphcard' => 1, 'sidegraph' => 1, 'infoelement' => 1,
            'newserverlist' => 'table',
            'typealert' => 'disabled', 'alertdescription' => 'none',
            'discord' => 'none', 'website' => 'none', 'billing' => 'none',
            'knowledgebase' => 'none', 'status' => 'none',

            'contact_enabled' => 1,
            'contact_label' => 'Hubungi Pemilik Website',
            'contact_whatsapp' => '',
            'contact_telegram' => '',
            'contact_message' => 'Halo, saya butuh bantuan terkait akun panel.',

            // Protection middleware + floating warning toast
            'antirusuh_enabled' => 1,
            'antirusuh_rules' => 'delete_server,users,locations,nodes,nests,settings,theme',
            'antirusuh_allowed' => '1',
            'antirusuh_message' => 'Hanya admin utama yang boleh :action.',
            'antirusuh_title' => 'AKSES DITOLAK',
            'antirusuh_color' => '#ff3b30',
            'antirusuh_textcolor' => '#ffffff',
            'antirusuh_position' => 'top-right',
            'antirusuh_duration' => 6,
        ];
    }

    /**
     * Returns the settings row merged over the defaults. Never throws.
     */
    public static function get(): object
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $values = self::defaults();

        try {
            $row = DB::table('theme')->first();
            if ($row) {
                foreach ((array) $row as $key => $value) {
                    // Keep the default for NULL values; empty strings are valid (e.g. no background image).
                    if ($value !== null) {
                        $values[$key] = $value;
                    }
                }
            }
        } catch (\Throwable $exception) {
            // Table or column missing (migrations not run yet): fall back to the defaults.
        }

        return self::$cache = (object) $values;
    }

    public static function flush(): void
    {
        self::$cache = null;
    }

    public static function logo(): string
    {
        $logo = trim((string) self::get()->logo);

        return $logo !== '' ? $logo : self::DEFAULT_LOGO;
    }

    public static function siteName(): string
    {
        $name = trim((string) self::get()->sitename);

        return $name !== '' ? $name : (string) config('app.name', 'Pterodactyl');
    }

    /**
     * Protection middleware settings in a ready-to-use shape.
     */
    public static function protection(): array
    {
        $s = self::get();

        $rules = array_values(array_intersect(
            array_map('trim', explode(',', (string) $s->antirusuh_rules)),
            array_keys(self::PROTECTION_RULES)
        ));

        $allowed = array_values(array_filter(
            array_map('intval', preg_split('/[\s,;]+/', (string) $s->antirusuh_allowed, -1, PREG_SPLIT_NO_EMPTY) ?: []),
            fn ($id) => $id > 0
        ));

        return [
            'enabled' => (bool) $s->antirusuh_enabled,
            'rules' => $rules,
            // The main administrator can never be locked out of his own protection.
            'allowed' => array_values(array_unique(array_merge([1], $allowed))),
            'message' => (string) $s->antirusuh_message,
            'toast' => self::toast(),
        ];
    }

    /**
     * Look of the floating warning notification. Used by the admin layout and exposed to the client area.
     */
    public static function toast(): array
    {
        $s = self::get();

        $position = (string) $s->antirusuh_position;
        $duration = (int) $s->antirusuh_duration;

        return [
            'title' => (string) $s->antirusuh_title,
            'color' => self::css($s->antirusuh_color) ?: '#ff3b30',
            'textColor' => self::css($s->antirusuh_textcolor) ?: '#ffffff',
            'position' => in_array($position, self::TOAST_POSITIONS, true) ? $position : 'top-right',
            'duration' => max(0, min(60, $duration)),
        ];
    }

    /**
     * Normalises a phone number to digits only (wa.me format). A leading 0 is treated
     * as an Indonesian local number and converted to the 62 country code.
     */
    public static function normalizeWhatsapp(?string $number): string
    {
        $digits = preg_replace('/\D+/', '', (string) $number) ?? '';
        if ($digits !== '' && str_starts_with($digits, '0')) {
            $digits = '62' . substr($digits, 1);
        }

        return $digits;
    }

    /**
     * Accepts "@name", "name" or "https://t.me/name" and returns just the username.
     */
    public static function normalizeTelegram(?string $value): string
    {
        $value = trim((string) $value);
        $value = preg_replace('#^(https?://)?(t\.me|telegram\.me)/#i', '', $value) ?? '';

        return ltrim($value, '@');
    }

    /**
     * The subset of settings that is safe to expose to unauthenticated visitors
     * (the login page needs it). Injected into the page as window.ThemeConfiguration.
     */
    public static function publicConfig(): array
    {
        $s = self::get();

        $whatsapp = self::normalizeWhatsapp($s->contact_whatsapp);
        $telegram = self::normalizeTelegram($s->contact_telegram);
        $message = trim((string) $s->contact_message);

        $link = function ($value) {
            $value = (string) $value;

            return ($value === '' || $value === 'none') ? null : $value;
        };

        return [
            'name' => self::siteName(),
            'logo' => self::logo(),
            'serverList' => (string) $s->newserverlist,
            'logoShape' => in_array($s->logoshape, ['square', 'rounded', 'circle'], true) ? (string) $s->logoshape : 'square',
            'showName' => (bool) $s->shownamelogo,
            'toast' => self::toast(),
            'contact' => [
                'enabled' => (bool) $s->contact_enabled && ($whatsapp !== '' || $telegram !== ''),
                'label' => (string) $s->contact_label,
                'whatsapp' => $whatsapp !== ''
                    ? 'https://wa.me/' . $whatsapp . ($message !== '' ? '?text=' . rawurlencode($message) : '')
                    : null,
                'telegram' => $telegram !== '' ? 'https://t.me/' . $telegram : null,
            ],
            'links' => [
                'website' => $link($s->website),
                'discord' => $link($s->discord),
                'billing' => $link($s->billing),
                'status' => $link($s->status),
                'knowledgebase' => $link($s->knowledgebase),
            ],
            'alert' => [
                'type' => (string) $s->typealert,
                'description' => (string) $s->alertdescription,
            ],
        ];
    }

    /**
     * Whitelisted value for output inside a <style> block (colours, urls, numbers).
     */
    public static function css($value): string
    {
        return preg_replace('/[^#a-zA-Z0-9(),.%\s\/:_\-]/', '', (string) $value) ?? '';
    }

    /**
     * Value for a CSS url("...") — strips everything that could break out of the quoted string.
     */
    public static function url($value): string
    {
        return preg_replace('/["\'\\\\<>()\s]/', '', (string) $value) ?? '';
    }
}
