<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateThemeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('theme', function (Blueprint $table) {
            $table->id();
            $table->string('logo');
            $table->string('highlightcolor');
            $table->string('lightcolor');
            $table->string('color');
            $table->string('subcolor');
            $table->string('color4');
            $table->string('color5');
            $table->string('color6');
            $table->string('dark');
            $table->string('primary');
            $table->string('primaryhover');
            $table->string('secondary');
            $table->string('secondaryhover');
            $table->string('background');
            $table->string('input');
            $table->string('lhighlightcolor');
            $table->string('llightcolor');
            $table->string('lcolor');
            $table->string('lsubcolor');
            $table->string('lcolor4');
            $table->string('lcolor5');
            $table->string('lcolor6');
            $table->string('ldark');
            $table->string('lprimary');
            $table->string('lprimaryhover');
            $table->string('lsecondary');
            $table->string('lsecondaryhover');
            $table->string('lbackground');
            $table->string('linput');
            $table->boolean('subnavigation');
            $table->boolean('graphcard');
            $table->string('discription');
            $table->string('backgroundimage');
            $table->string('title');
            $table->timestamps();
        });

        DB::table('theme')->insert(
            array(
                'logo' => '/favicons/favicon-32x32.png',
                'highlightcolor' => '#2f2b52',
                'lightcolor' => '#3d3969',
                'color' => '#4b4778',
                'subcolor' => '#6a668f',
                'color4' => '#7a769c',
                'color5' => '#8d89ad',
                'color6' => '#a3a0bf',
                'dark' => '#3a3566',
                'primary' => '#7c6cf2',
                'primaryhover' => '#6b5ae6',
                'secondary' => '#eeedfb',
                'secondaryhover' => '#e0def4',
                'background' => '#e3e1f4',
                'input' => '#dcdaf0',
                'lhighlightcolor' => '#f3f1ff',
                'llightcolor' => '#e2dffa',
                'lcolor' => '#cfcbee',
                'lsubcolor' => '#b3afd9',
                'lcolor4' => '#a09bcc',
                'lcolor5' => '#8e89bd',
                'lcolor6' => '#7b76ab',
                'ldark' => '#4a4775',
                'lprimary' => '#9a8cff',
                'lprimaryhover' => '#b0a5ff',
                'lsecondary' => '#302e4d',
                'lsecondaryhover' => '#3a3860',
                'lbackground' => '#25233d',
                'linput' => '#201e36',
                'backgroundimage' => '',
                'subnavigation' => 1,
                'graphcard' => 1,
                'discription' => 'Game server control panel',
                'title' => 'Claymorphism Panel',
                'created_at' => now(),
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('theme');
    }
}
