<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateThemeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('theme', function (Blueprint $table) {
            $table->id();
            $table->string('logo');
            $table->string('highlightcolor');
            $table->string('lightcolor');
            $table->string('color');
            $table->string('subcolor');
            $table->string('color4');
            $table->string('color5');
            $table->string('color6');
            $table->string('dark');
            $table->string('primary');
            $table->string('primaryhover');
            $table->string('secondary');
            $table->string('secondaryhover');
            $table->string('background');
            $table->string('input');
            $table->string('lhighlightcolor');
            $table->string('llightcolor');
            $table->string('lcolor');
            $table->string('lsubcolor');
            $table->string('lcolor4');
            $table->string('lcolor5');
            $table->string('lcolor6');
            $table->string('ldark');
            $table->string('lprimary');
            $table->string('lprimaryhover');
            $table->string('lsecondary');
            $table->string('lsecondaryhover');
            $table->string('lbackground');
            $table->string('linput');
            $table->boolean('subnavigation');
            $table->boolean('graphcard');
            $table->string('discription');
            $table->string('backgroundimage');
            $table->string('title');
            $table->timestamps();
        });

        DB::table('theme')->insert(
            array(
                'logo' => '/favicons/favicon-32x32.png',
                'highlightcolor' => '#000000',
                'lightcolor' => '#111111',
                'color' => '#1a1a1a',
                'subcolor' => '#333333',
                'color4' => '#4d4d4d',
                'color5' => '#666666',
                'color6' => '#8a8a8a',
                'dark' => '#1a1a1a',
                'primary' => '#6c4dff',
                'primaryhover' => '#5a3bf0',
                'secondary' => '#ffffff',
                'secondaryhover' => '#fff1b8',
                'background' => '#fff4d6',
                'input' => '#ffffff',
                'lhighlightcolor' => '#ffffff',
                'llightcolor' => '#f2eee2',
                'lcolor' => '#e6e1d2',
                'lsubcolor' => '#cbc5b4',
                'lcolor4' => '#aaa493',
                'lcolor5' => '#8c8678',
                'lcolor6' => '#6e695d',
                'ldark' => '#0b0b0b',
                'lprimary' => '#a594ff',
                'lprimaryhover' => '#bcb0ff',
                'lsecondary' => '#1f1f1f',
                'lsecondaryhover' => '#2c2c2c',
                'lbackground' => '#121212',
                'linput' => '#181818',
                'backgroundimage' => '',
                'subnavigation' => 1,
                'graphcard' => 1,
                'discription' => 'Game server control panel',
                'title' => 'NeoBrutalism Panel',
                'created_at' => now(),
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('theme');
    }
}
