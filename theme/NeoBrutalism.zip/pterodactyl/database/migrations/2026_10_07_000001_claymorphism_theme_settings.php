<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Pterodactyl\Services\Theme\ThemeSettings;

/**
 * Converts the old Stellar theme settings to Claymorphism:
 *  - adds the brand name column and the "contact website owner" columns
 *  - swaps the untouched Stellar default colours for the Claymorphism palette
 *    (any value you customised yourself is left alone)
 */
return new class extends Migration {
    /** Stellar factory defaults. Only values that still equal these are replaced. */
    private const STELLAR = [
        'highlightcolor' => '#f5f6f8', 'lightcolor' => '#ecf0f3', 'color' => '#D9D9D9', 'subcolor' => '#c0bfc0',
        'color4' => '#7c8a99', 'color5' => '#748291', 'color6' => '#636f7d', 'dark' => '#33383d',
        'primary' => '#3B6CDE', 'primaryhover' => '#6493FF', 'secondary' => '#222339', 'secondaryhover' => '#1b1c2e',
        'background' => '#1B1C30', 'input' => '#2A2F41',
        'lhighlightcolor' => '#33383d', 'llightcolor' => '#636f7d', 'lcolor' => '#748291', 'lsubcolor' => '#7c8a99',
        'lcolor4' => '#7c8a99', 'lcolor5' => '#7c8a99', 'lcolor6' => '#636f7d', 'ldark' => '#33383d',
        'lprimary' => '#3B6CDE', 'lprimaryhover' => '#6493FF', 'lsecondary' => '#ffffff', 'lsecondaryhover' => '#e3e3e3',
        'lbackground' => '#F0F0F0', 'linput' => '#d9d9d9',
        'metacolor' => '#3B6CDE', 'dangerbutton' => '#DC2626', 'textbutton' => '#4E5C7E',
        'dangerbuttonhover' => '#ff4040', 'textbuttonhover' => '#60709A', 'ldangerbutton' => '#FF4747',
        'ltextbutton' => '#E0EFFF', 'ldangerbuttonhover' => '#FF5C5C', 'ltextbuttonhover' => '#EBF4FF',
        'borderradius' => '7',
        'backgroundimage' => 'https://img0.pixhost.to/images/235/521847757_skyzopedia.jpg',
        'discription' => '©Skyzopedia', 'title' => 'copyright by skyzopedia',
    ];

    public function up(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            if (!Schema::hasColumn('theme', 'sitename')) {
                $table->string('sitename')->default('');
            }
            if (!Schema::hasColumn('theme', 'contact_enabled')) {
                $table->boolean('contact_enabled')->default(true);
            }
            if (!Schema::hasColumn('theme', 'contact_label')) {
                $table->string('contact_label')->default('Hubungi Pemilik Website');
            }
            if (!Schema::hasColumn('theme', 'contact_whatsapp')) {
                $table->string('contact_whatsapp')->default('');
            }
            if (!Schema::hasColumn('theme', 'contact_telegram')) {
                $table->string('contact_telegram')->default('');
            }
            if (!Schema::hasColumn('theme', 'contact_message')) {
                $table->string('contact_message')->default('Halo, saya butuh bantuan terkait akun panel.');
            }
            if (!Schema::hasColumn('theme', 'antirusuh_enabled')) {
                $table->boolean('antirusuh_enabled')->default(false);
            }
            foreach (['ar_server_delete', 'ar_user', 'ar_location', 'ar_node', 'ar_nest', 'ar_settings', 'ar_server_access'] as $column) {
                if (!Schema::hasColumn('theme', $column)) {
                    $table->boolean($column)->default(true);
                }
            }
        });

        $defaults = ThemeSettings::defaults();
        foreach (self::STELLAR as $column => $old) {
            if (Schema::hasColumn('theme', $column) && array_key_exists($column, $defaults)) {
                DB::table('theme')->where($column, $old)->update([$column => $defaults[$column]]);
            }
        }

        // A row must always exist, otherwise the admin forms have nothing to update.
        if (DB::table('theme')->count() === 0) {
            DB::table('theme')->insert(array_merge($defaults, ['created_at' => now()]));
        }
    }

    public function down(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $table->dropColumn(['sitename', 'contact_enabled', 'contact_label', 'contact_whatsapp', 'contact_telegram', 'contact_message',
                'antirusuh_enabled', 'ar_server_delete', 'ar_user', 'ar_location', 'ar_node', 'ar_nest', 'ar_settings', 'ar_server_access']);
        });
    }
};
