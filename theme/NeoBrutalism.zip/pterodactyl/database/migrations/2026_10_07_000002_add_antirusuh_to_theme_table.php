<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            if (!Schema::hasColumn('theme', 'antirusuh_enabled')) {
                $table->boolean('antirusuh_enabled')->default(false);
            }
            if (!Schema::hasColumn('theme', 'antirusuh_rules')) {
                $table->string('antirusuh_rules', 255)->default('delete_server,users,locations,nodes,nests,settings,theme,server_access');
            }
            if (!Schema::hasColumn('theme', 'antirusuh_message')) {
                $table->string('antirusuh_message', 255)->default('Akses ditolak: hanya admin utama (ID 1) yang diizinkan.');
            }
        });
    }

    public function down(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $table->dropColumn(['antirusuh_enabled', 'antirusuh_rules', 'antirusuh_message']);
        });
    }
};
