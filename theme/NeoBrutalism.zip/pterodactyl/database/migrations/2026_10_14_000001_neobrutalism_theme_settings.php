<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Pterodactyl\Services\Theme\ThemeSettings;

/**
 * NeoBrutalism theme settings. Adds every column the theme needs (idempotent, safe to run on an
 * existing `theme` table): brand name, contact button, neo style options and the protection /
 * warning toast settings.
 */
return new class extends Migration {
    /** Initial column defaults of the base theme table. */
    private const INITIAL = [
        'metacolor' => '#3B6CDE', 'borderradius' => '7',
        'dangerbutton' => '#DC2626', 'dangerbuttonhover' => '#ff4040',
        'textbutton' => '#4E5C7E', 'textbuttonhover' => '#60709A',
        'ldangerbutton' => '#FF4747', 'ldangerbuttonhover' => '#FF5C5C',
        'ltextbutton' => '#E0EFFF', 'ltextbuttonhover' => '#EBF4FF',
    ];

    public function up(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $this->addString($table, 'sitename', '');
            if (!Schema::hasColumn('theme', 'contact_enabled')) {
                $table->boolean('contact_enabled')->default(true);
            }
            $this->addString($table, 'contact_label', 'Hubungi Pemilik Website');
            $this->addString($table, 'contact_whatsapp', '');
            $this->addString($table, 'contact_telegram', '');
            $this->addString($table, 'contact_message', 'Halo, saya butuh bantuan terkait akun panel.');
            $this->addString($table, 'borderwidth', 3);
            $this->addString($table, 'shadowsize', 6);
            $this->addString($table, 'logoshape', 'square');

            if (!Schema::hasColumn('theme', 'shownamelogo')) {
                $table->boolean('shownamelogo')->default(true);
            }
            if (!Schema::hasColumn('theme', 'antirusuh_enabled')) {
                $table->boolean('antirusuh_enabled')->default(true);
            }
            if (!Schema::hasColumn('theme', 'antirusuh_rules')) {
                $table->string('antirusuh_rules', 255)->default('delete_server,users,locations,nodes,nests,settings,theme');
            }
            if (!Schema::hasColumn('theme', 'antirusuh_message')) {
                $table->string('antirusuh_message', 255)->default('Hanya admin utama yang boleh :action.');
            }
            $this->addString($table, 'antirusuh_allowed', '1');
            $this->addString($table, 'antirusuh_title', 'AKSES DITOLAK');
            $this->addString($table, 'antirusuh_color', '#ff3b30');
            $this->addString($table, 'antirusuh_textcolor', '#ffffff');
            $this->addString($table, 'antirusuh_position', 'top-right');

            if (!Schema::hasColumn('theme', 'antirusuh_duration')) {
                $table->unsignedTinyInteger('antirusuh_duration')->default(6);
            }
        });

        $defaults = ThemeSettings::defaults();

        // Columns added by 2022_07_27_134330 start with their own plain defaults; on a fresh install move
        // them to the NeoBrutalism palette. Anything you changed yourself no longer matches and is kept.
        foreach (self::INITIAL as $column => $initial) {
            if (Schema::hasColumn('theme', $column) && array_key_exists($column, $defaults)) {
                DB::table('theme')->where($column, $initial)->update([$column => $defaults[$column]]);
            }
        }

        // A row must always exist, otherwise the admin forms have nothing to update.
        if (DB::table('theme')->count() === 0) {
            DB::table('theme')->insert(array_merge($defaults, ['created_at' => now()]));
        }
    }

    public function down(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $table->dropColumn([
                'borderwidth', 'shadowsize', 'logoshape', 'shownamelogo',
                'antirusuh_allowed', 'antirusuh_title', 'antirusuh_color', 'antirusuh_textcolor',
                'antirusuh_position', 'antirusuh_duration',
            ]);
        });
    }

    private function addString(Blueprint $table, string $column, $default): void
    {
        if (!Schema::hasColumn('theme', $column)) {
            $table->string($column)->default((string) $default);
        }
    }
};
