<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Pterodactyl\Services\Theme\ThemeSettings;

/**
 * Converts the Claymorphism theme settings to NeoBrutalism:
 *  - adds the neo style columns (border width, shadow size, logo shape, name next to the logo)
 *  - adds the protection / floating warning notification columns
 *  - swaps the untouched Claymorphism default colours for the NeoBrutalism palette
 *    (any value you customised yourself is left alone)
 */
return new class extends Migration {
    /** Claymorphism factory defaults. Only values that still equal these are replaced. */
    private const CLAY = [
        'highlightcolor' => '#2f2b52', 'lightcolor' => '#3d3969', 'color' => '#4b4778',
        'subcolor' => '#6a668f', 'color4' => '#7a769c', 'color5' => '#8d89ad', 'color6' => '#a3a0bf',
        'dark' => '#3a3566', 'primary' => '#7c6cf2', 'primaryhover' => '#6b5ae6',
        'secondary' => '#eeedfb', 'secondaryhover' => '#e0def4', 'background' => '#e3e1f4', 'input' => '#dcdaf0',
        'lhighlightcolor' => '#f3f1ff', 'llightcolor' => '#e2dffa', 'lcolor' => '#cfcbee',
        'lsubcolor' => '#b3afd9', 'lcolor4' => '#a09bcc', 'lcolor5' => '#8e89bd', 'lcolor6' => '#7b76ab',
        'ldark' => '#4a4775', 'lprimary' => '#9a8cff', 'lprimaryhover' => '#b0a5ff',
        'lsecondary' => '#302e4d', 'lsecondaryhover' => '#3a3860', 'lbackground' => '#25233d', 'linput' => '#201e36',
        'metacolor' => '#7c6cf2',
        'dangerbutton' => '#f0657d', 'dangerbuttonhover' => '#e34d67',
        'textbutton' => '#8a85b3', 'textbuttonhover' => '#706b9c',
        'ldangerbutton' => '#ff7a92', 'ldangerbuttonhover' => '#ff93a7',
        'ltextbutton' => '#6f6aa0', 'ltextbuttonhover' => '#8782b8',
        'borderradius' => '22',
        'title' => 'Claymorphism Panel',
    ];

    private const OLD_PROTECTION_MESSAGE = 'Akses ditolak: hanya admin utama (ID 1) yang diizinkan.';

    public function up(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $this->addString($table, 'borderwidth', 3);
            $this->addString($table, 'shadowsize', 6);
            $this->addString($table, 'logoshape', 'square');

            if (!Schema::hasColumn('theme', 'shownamelogo')) {
                $table->boolean('shownamelogo')->default(true);
            }
            if (!Schema::hasColumn('theme', 'antirusuh_enabled')) {
                $table->boolean('antirusuh_enabled')->default(true);
            }
            if (!Schema::hasColumn('theme', 'antirusuh_rules')) {
                $table->string('antirusuh_rules', 255)->default('delete_server,users,locations,nodes,nests,settings,theme');
            }
            if (!Schema::hasColumn('theme', 'antirusuh_message')) {
                $table->string('antirusuh_message', 255)->default('Hanya admin utama yang boleh :action.');
            }
            $this->addString($table, 'antirusuh_allowed', '1');
            $this->addString($table, 'antirusuh_title', 'AKSES DITOLAK');
            $this->addString($table, 'antirusuh_color', '#ff3b30');
            $this->addString($table, 'antirusuh_textcolor', '#ffffff');
            $this->addString($table, 'antirusuh_position', 'top-right');

            if (!Schema::hasColumn('theme', 'antirusuh_duration')) {
                $table->unsignedTinyInteger('antirusuh_duration')->default(6);
            }
        });

        $defaults = ThemeSettings::defaults();

        foreach (self::CLAY as $column => $old) {
            if (Schema::hasColumn('theme', $column) && array_key_exists($column, $defaults)) {
                DB::table('theme')->where($column, $old)->update([$column => $defaults[$column]]);
            }
        }

        // The Claymorphism build shipped the (unused) protection columns switched off and with a
        // fixed message; switch the protection on and use the message with the :action placeholder.
        DB::table('theme')->where('antirusuh_message', self::OLD_PROTECTION_MESSAGE)
            ->update(['antirusuh_message' => $defaults['antirusuh_message']]);
        DB::table('theme')->where('antirusuh_enabled', 0)->update(['antirusuh_enabled' => 1]);
        DB::table('theme')->where('antirusuh_rules', 'delete_server,users,locations,nodes,nests,settings,theme,server_access')
            ->update(['antirusuh_rules' => $defaults['antirusuh_rules']]);

        // A row must always exist, otherwise the admin forms have nothing to update.
        if (DB::table('theme')->count() === 0) {
            DB::table('theme')->insert(array_merge($defaults, ['created_at' => now()]));
        }
    }

    public function down(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $table->dropColumn([
                'borderwidth', 'shadowsize', 'logoshape', 'shownamelogo',
                'antirusuh_allowed', 'antirusuh_title', 'antirusuh_color', 'antirusuh_textcolor',
                'antirusuh_position', 'antirusuh_duration',
            ]);
        });
    }

    private function addString(Blueprint $table, string $column, $default): void
    {
        if (!Schema::hasColumn('theme', $column)) {
            $table->string($column)->default((string) $default);
        }
    }
};
