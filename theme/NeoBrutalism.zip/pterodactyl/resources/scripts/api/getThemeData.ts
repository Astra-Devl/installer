import { getThemeConfig } from '@/api/themeConfig';

/**
 * Kept for the existing components (social buttons, alerts, server list layout).
 * The data no longer comes from an authenticated API call, it is read from
 * window.ThemeConfiguration, so there is no extra request and no loading flicker.
 */
export default async () => {
    const config = getThemeConfig();

    return {
        logo: config.logo,
        sitename: config.name,
        website: config.links.website ?? 'none',
        discord: config.links.discord ?? 'none',
        billing: config.links.billing ?? 'none',
        status: config.links.status ?? 'none',
        knowledgebase: config.links.knowledgebase ?? 'none',
        typealert: config.alert.type,
        alertdescription: config.alert.description,
        newserverlist: config.serverList,
    };
};
