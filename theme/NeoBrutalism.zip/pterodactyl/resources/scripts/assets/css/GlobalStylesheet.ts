import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';

export default createGlobalStyle`
    body {
        ${tw`font-sans`};
        color: var(--color);
        background-color: var(--background-color) !important;
        letter-spacing: 0;
        font-weight: 500;
    }

    h1, h2, h3, h4, h5, h6 {
        ${tw`font-medium tracking-normal font-header`};
        font-weight: 700;
        letter-spacing: -0.01em;
    }

    p {
        ${tw`leading-snug font-sans`};
        color: var(--color);
    }

    form {
        ${tw`m-0`};
    }

    textarea, select, input, button, button:focus, button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    ::selection {
        background: var(--neo-yellow);
        color: #000;
    }

    /* NeoBrutalism scroll bar: square thumb with an ink outline */
    ::-webkit-scrollbar {
        background: var(--background-color);
        width: 16px;
        height: 16px;
        border-left: 3px solid var(--neo-ink);
    }

    ::-webkit-scrollbar-thumb {
        border: solid 3px var(--neo-ink);
        border-radius: 0;
        background-color: var(--primary);
    }

    ::-webkit-scrollbar-track-piece {
        margin: 0;
    }

    ::-webkit-scrollbar-thumb:hover {
        background-color: var(--neo-yellow);
    }

    ::-webkit-scrollbar-corner {
        background: var(--background-color);
    }

    :focus-visible {
        outline: 3px dashed var(--neo-ink);
        outline-offset: 2px;
    }

    code, kbd, samp, pre {
        font-family: 'Space Mono', 'IBM Plex Mono', monospace;
    }

    /* Pages hop in instead of fading softly */
    @keyframes neo-pop {
        0% { opacity: 0; transform: translateY(10px) rotate(-0.4deg); }
        60% { opacity: 1; transform: translateY(-2px); }
        100% { opacity: 1; transform: none; }
    }

    @media (prefers-reduced-motion: no-preference) {
        .fade-appear-active, .fade-enter-active {
            animation: neo-pop 0.28s ease both;
        }
    }
`;
