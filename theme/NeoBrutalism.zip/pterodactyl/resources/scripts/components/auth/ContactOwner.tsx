import React from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import { getThemeConfig } from '@/api/themeConfig';

const Wrapper = styled.div`
    margin-top: 1.75rem;
    padding-top: 1.25rem;
    text-align: center;
    border-top: 3px dashed var(--neo-ink);

    & > p {
        margin-bottom: 0.9rem;
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--highlight-color);
    }

    & > div {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 1rem;
    }
`;

const ContactLink = styled.a<{ $brand: 'whatsapp' | 'telegram' }>`
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.7rem 1.25rem;
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    text-decoration: none;
    color: #000;
    background: ${({ $brand }) => ($brand === 'whatsapp' ? '#3ddc97' : '#4d96ff')};
    box-shadow: var(--neo-shadow-btn);
    transition: transform 0.08s ease, box-shadow 0.08s ease;

    &:hover {
        color: #000;
        transform: translate(-2px, -2px);
        box-shadow: calc(var(--neo-so) * 0.66 + 2px) calc(var(--neo-so) * 0.66 + 2px) 0 0 var(--neo-ink);
    }

    &:active {
        transform: translate(calc(var(--neo-so) * 0.66), calc(var(--neo-so) * 0.66));
        box-shadow: 0 0 0 0 var(--neo-ink);
    }
`;

/**
 * "Contact the website owner" buttons shown under the "Forgot password?" link.
 * Number / username are configured in Admin > Theme > Contact Settings.
 */
export default () => {
    const { contact } = getThemeConfig();

    if (!contact.enabled || (!contact.whatsapp && !contact.telegram)) {
        return null;
    }

    return (
        <Wrapper>
            <p>{contact.label}</p>
            <div>
                {contact.whatsapp && (
                    <ContactLink $brand={'whatsapp'} href={contact.whatsapp} target={'_blank'} rel={'noopener noreferrer'}>
                        <Icon.MessageCircle size={18} />
                        WhatsApp
                    </ContactLink>
                )}
                {contact.telegram && (
                    <ContactLink $brand={'telegram'} href={contact.telegram} target={'_blank'} rel={'noopener noreferrer'}>
                        <Icon.Send size={18} />
                        Telegram
                    </ContactLink>
                )}
            </div>
        </Wrapper>
    );
};
