import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import { getThemeConfig } from '@/api/themeConfig';
import tw from 'twin.macro';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const Container = styled.div`
    ${breakpoint('sm')`
        ${tw`w-4/5 mx-auto`}
    `};

    ${breakpoint('md')`
        ${tw`p-10`}
    `};

    ${breakpoint('lg')`
        ${tw`w-3/5`}
    `};

    ${breakpoint('xl')`
        ${tw`w-full`}
        max-width: 560px;
    `};

    .box {
        background-color: var(--secondary);
        border: var(--neo-border);
        border-radius: var(--neo-radius);
        box-shadow: calc(var(--neo-so) + 4px) calc(var(--neo-so) + 4px) 0 0 var(--neo-ink);
        padding: 2rem;
    }
`;

const radiusFor = (shape: 'square' | 'rounded' | 'circle') =>
    shape === 'circle' ? '50%' : shape === 'rounded' ? '14px' : '0';

const Brand = styled.div<{ $shape: 'square' | 'rounded' | 'circle' }>`
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 1.5rem;

    img {
        width: 84px;
        height: 84px;
        object-fit: contain;
        padding: 10px;
        border: var(--neo-border);
        border-radius: ${({ $shape }) => radiusFor($shape)};
        background-color: #ffffff;
        box-shadow: var(--neo-shadow);
        transform: rotate(-3deg);
    }

    strong {
        margin-top: 1.1rem;
        padding: 4px 14px;
        font-size: 1.3rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        color: #000;
        background-color: var(--neo-yellow);
        border: var(--neo-border);
        box-shadow: var(--neo-shadow-sm);
    }
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const { logo, name, logoShape, showName } = getThemeConfig();

    return (
        <Container>
            <Brand $shape={logoShape}>
                <img src={logo} alt={name} />
                {showName && <strong>{name}</strong>}
            </Brand>
            {title && <h2 css={tw`text-2xl text-center text-neutral-100 pb-4 uppercase`}>{title}</h2>}
            <FlashMessageRender css={tw`mb-2 px-1`} />
            <Form {...props} ref={ref}>
                <div css={tw`md:flex w-full mx-1`} className='box'>
                    <div css={tw`flex-1`}>{props.children}</div>
                </div>
            </Form>
            <p css={tw`text-center text-neutral-500 text-xs mt-5`}>
                &copy; {new Date().getFullYear()}&nbsp;
                <a
                    rel={'noopener nofollow noreferrer'}
                    href={'https://pterodactyl.io'}
                    target={'_blank'}
                    css={tw`no-underline text-neutral-500 hover:text-neutral-300`}
                >
                    Pterodactyl&reg;
                </a>
            </p>
        </Container>
    );
});
