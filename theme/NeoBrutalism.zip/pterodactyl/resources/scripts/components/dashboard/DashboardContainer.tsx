import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useStoreState } from 'easy-peasy';
import useSWR from 'swr';
import styled from 'styled-components/macro';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import { PaginatedResult } from '@/api/http';
import { getThemeConfig } from '@/api/themeConfig';
import { ip } from '@/lib/formatters';
import ServerRow from '@/components/dashboard/ServerRow';
import ServerCard from '@/components/dashboard/ServerCard';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import Pagination from '@/components/elements/Pagination';
import Switch from '@/components/elements/Switch';
import useFlash from '@/plugins/useFlash';
import { usePersistedState } from '@/plugins/usePersistedState';
import * as Lang from '@/lang';

type ViewMode = 'cards' | 'table';

const Hero = styled.div`
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 1.5rem;
    padding: 1.1rem 1.4rem;
    color: #000;
    background-color: var(--neo-yellow);
    background-image: radial-gradient(rgba(0, 0, 0, 0.2) 1.5px, transparent 1.5px);
    background-size: 14px 14px;
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
`;

const HeroTitle = styled.h1`
    margin: 0;
    font-size: 1.7rem;
    font-weight: 700;
    line-height: 1.1;
    letter-spacing: -0.01em;
    text-transform: uppercase;
    color: #000;
`;

const HeroSub = styled.p`
    margin-top: 0.3rem;
    font-size: 0.85rem;
    font-weight: 600;
    color: #000;
    opacity: 0.8;
`;

const Stickers = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
`;

const Sticker = styled.div`
    padding: 0.35rem 0.8rem;
    color: #000;
    border: 2px solid #000;
    border-radius: var(--neo-radius-sm);
    box-shadow: 3px 3px 0 0 #000;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    transform: rotate(-1.5deg);

    & > b {
        margin-right: 0.35rem;
        font-size: 1.1rem;
    }

    &:nth-of-type(even) {
        transform: rotate(1.5deg);
    }
`;

const Toolbar = styled.div`
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.9rem;
    margin-bottom: 1.5rem;
`;

const Search = styled.input`
    flex: 1 1 220px;
    min-width: 0;
    padding: 0.65rem 0.9rem;
    color: var(--highlight-color);
    background: var(--input);
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    box-shadow: var(--neo-shadow-sm);
    font-weight: 600;
    transition: transform 0.08s ease, box-shadow 0.08s ease;

    &::placeholder {
        color: var(--color-5);
        font-weight: 500;
    }

    &:focus {
        transform: translate(-2px, -2px);
        box-shadow: var(--neo-shadow);
    }
`;

const Toggle = styled.div`
    display: inline-flex;
    overflow: hidden;
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    box-shadow: var(--neo-shadow-sm);

    & > button {
        padding: 0.6rem 1rem;
        color: var(--highlight-color);
        background: var(--secondary);
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;

        &:hover {
            background: var(--neo-yellow);
            color: #000;
        }

        &[aria-pressed='true'] {
            background: var(--primary);
            color: var(--on-primary);
        }

        & + button {
            border-left: var(--neo-border);
        }
    }
`;

const AdminSwitch = styled.label`
    display: inline-flex;
    align-items: center;
    gap: 0.7rem;
    margin: 0;
    padding: 0.45rem 0.8rem;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    box-shadow: var(--neo-shadow-sm);
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--highlight-color);
`;

const Grid = styled.div`
    display: grid;
    grid-template-columns: repeat(1, minmax(0, 1fr));
    gap: 1.5rem;

    @media (min-width: 768px) {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    @media (min-width: 1280px) {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
`;

const TableWrap = styled.div`
    max-width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    padding: 0 calc(var(--neo-so) + 2px) calc(var(--neo-so) + 4px) 0;
`;

const Table = styled.table`
    width: 100%;
    min-width: 820px;
    border-collapse: separate;
    border-spacing: 0;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);

    & > thead > tr > th {
        padding: 0.9rem 1.1rem;
        text-align: left;
        color: #000;
        background: var(--neo-yellow);
        border-bottom: var(--neo-border);
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
    }

    & > thead > tr > th:first-of-type {
        border-top-left-radius: calc(var(--neo-radius) * 0.5);
    }

    & > thead > tr > th:last-of-type {
        border-top-right-radius: calc(var(--neo-radius) * 0.5);
    }
`;

const Empty = styled.div`
    padding: 2.5rem 1.5rem;
    text-align: center;
    color: var(--highlight-color);
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
    font-weight: 700;

    & > .big {
        display: inline-block;
        margin-bottom: 0.9rem;
        padding: 0.2rem 0.9rem;
        color: #000;
        background: var(--neo-pink);
        border: 2px solid var(--neo-ink);
        border-radius: var(--neo-radius-sm);
        box-shadow: 3px 3px 0 0 var(--neo-ink);
        font-size: 1.4rem;
        letter-spacing: 0.1em;
        transform: rotate(-3deg);
    }
`;

const matches = (server: Server, query: string): boolean => {
    const needle = query.trim().toLowerCase();
    if (needle === '') return true;

    const allocation = server.allocations
        .filter((alloc) => alloc.isDefault)
        .map((alloc) => `${alloc.alias || ip(alloc.ip)}:${alloc.port}`)
        .join(' ');

    return [server.name, server.description, server.id, server.uuid, server.node, allocation].some((value) =>
        String(value || '')
            .toLowerCase()
            .includes(needle)
    );
};

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const [query, setQuery] = useState('');
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    // The admin picks the default layout (Admin > Theme > Elements); every user can still switch for themselves.
    const configuredView: ViewMode = getThemeConfig().serverList === 'cards' ? 'cards' : 'table';
    const [savedView, setSavedView] = usePersistedState<ViewMode | ''>(`${uuid}:server_view`, '');
    const view: ViewMode = savedView === 'cards' || savedView === 'table' ? savedView : configuredView;

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    const total = servers?.pagination.total ?? 0;
    const onPage = servers?.items.length ?? 0;

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>
            <Hero>
                <div>
                    <HeroTitle>{showOnlyAdmin ? Lang.showing_others_servers : 'Your Servers'}</HeroTitle>
                    <HeroSub>{showOnlyAdmin ? 'Everything running on this panel.' : Lang.showing_your_servers}</HeroSub>
                </div>
                <Stickers>
                    <Sticker style={{ background: 'var(--neo-pink)' }}>
                        <b>{total}</b>
                        total
                    </Sticker>
                    <Sticker style={{ background: 'var(--neo-mint)' }}>
                        <b>{onPage}</b>
                        this page
                    </Sticker>
                </Stickers>
            </Hero>

            <Toolbar>
                <Search
                    type={'search'}
                    value={query}
                    onChange={(e) => setQuery(e.currentTarget.value)}
                    placeholder={'Filter servers on this page by name, IP, node or ID...'}
                    aria-label={'Filter servers on this page'}
                />
                <Toggle role={'group'} aria-label={'Server list layout'}>
                    <button type={'button'} aria-pressed={view === 'cards'} onClick={() => setSavedView('cards')}>
                        Cards
                    </button>
                    <button type={'button'} aria-pressed={view === 'table'} onClick={() => setSavedView('table')}>
                        Table
                    </button>
                </Toggle>
                {rootAdmin && (
                    <AdminSwitch>
                        {showOnlyAdmin ? Lang.showing_others_servers : Lang.showing_your_servers}
                        <Switch
                            name={'show_all_servers'}
                            defaultChecked={showOnlyAdmin}
                            onChange={() => setShowOnlyAdmin((s) => !s)}
                        />
                    </AdminSwitch>
                )}
            </Toolbar>

            {!servers ? (
                <Spinner centered size={'large'} />
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) => {
                        const visible = items.filter((server) => matches(server, query));

                        if (visible.length === 0) {
                            return (
                                <Empty>
                                    <div className={'big'}>0 / 0</div>
                                    <p>
                                        {query.trim() !== ''
                                            ? `No server on this page matches "${query.trim()}".`
                                            : showOnlyAdmin
                                            ? Lang.there_are_no_other_servers_to_display
                                            : Lang.there_are_no_servers_associated_with_your_account}
                                    </p>
                                </Empty>
                            );
                        }

                        return view === 'cards' ? (
                            <Grid>
                                {visible.map((server) => (
                                    <ServerCard key={server.uuid} server={server} />
                                ))}
                            </Grid>
                        ) : (
                            <TableWrap>
                                <Table>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>{Lang.Name}</th>
                                            <th>{Lang.Allocation}</th>
                                            <th>CPU</th>
                                            <th>Ram</th>
                                            <th>Disk</th>
                                            <th>{Lang.Status}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {visible.map((server) => (
                                            <ServerRow key={server.uuid} server={server} />
                                        ))}
                                    </tbody>
                                </Table>
                            </TableWrap>
                        );
                    }}
                </Pagination>
            )}
        </PageContentBlock>
    );
};
