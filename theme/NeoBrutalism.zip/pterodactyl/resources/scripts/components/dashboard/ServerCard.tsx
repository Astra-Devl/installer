import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Globe, Server as ServerIcon } from 'react-feather';
import styled from 'styled-components/macro';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import CopyOnClick from '@/components/elements/CopyOnClick';
import Spinner from '@/components/elements/Spinner';
import StatusPill from '@/components/elements/neo/StatusPill';
import Meter from '@/components/elements/neo/Meter';
import { percentOf, resolveStatus, statusMeta } from '@/components/elements/neo/status';

const Card = styled.div`
    position: relative;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: var(--secondary);
    color: var(--color);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
    transition: transform 0.1s ease, box-shadow 0.1s ease;

    &:hover {
        transform: translate(-3px, -3px);
        box-shadow: calc(var(--neo-so) + 3px) calc(var(--neo-so) + 3px) 0 0 var(--neo-ink);
    }
`;

// A hatched strip in the colour of the current status: readable at a glance, even from across the room.
const Stripe = styled.div`
    height: 14px;
    border-bottom: var(--neo-border);
    background-image: repeating-linear-gradient(135deg, rgba(0, 0, 0, 0.16) 0 8px, transparent 8px 16px);
`;

const Body = styled.div`
    display: flex;
    flex: 1;
    flex-direction: column;
    gap: 1rem;
    padding: 1.25rem;
`;

const Head = styled.div`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 0.75rem;
`;

const Title = styled.h3`
    margin: 0;
    font-size: 1.15rem;
    font-weight: 700;
    line-height: 1.2;
    color: var(--highlight-color);
    word-break: break-word;
`;

const Description = styled.p`
    display: -webkit-box;
    margin-top: 0.3rem;
    overflow: hidden;
    font-size: 0.8rem;
    color: var(--color);
    opacity: 0.8;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
`;

const Chips = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
`;

const Chip = styled.span`
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    max-width: 100%;
    padding: 0.2rem 0.55rem;
    background: var(--secondary-hover);
    color: var(--highlight-color);
    border: 2px solid var(--neo-ink);
    border-radius: var(--neo-radius-sm);
    font-family: 'Space Mono', 'IBM Plex Mono', monospace;
    font-size: 0.75rem;
    font-weight: 700;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    &.copy:hover {
        background: var(--neo-yellow);
        color: #000;
    }
`;

const Meters = styled.div`
    display: grid;
    gap: 0.85rem;
`;

const Notice = styled.div`
    padding: 0.9rem;
    border: 2px dashed var(--neo-ink);
    border-radius: var(--neo-radius-sm);
    text-align: center;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--highlight-color);
`;

const Manage = styled(Link)`
    display: block;
    margin-top: auto;
    padding: 0.7rem;
    background: var(--primary);
    color: var(--on-primary);
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    box-shadow: var(--neo-shadow-btn);
    text-align: center;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    transition: transform 0.08s ease, box-shadow 0.08s ease, background-color 0.08s ease;

    &:hover {
        background: var(--primary-hover);
        color: var(--on-primary);
        transform: translate(-2px, -2px);
        box-shadow: calc(var(--neo-so) * 0.66 + 2px) calc(var(--neo-so) * 0.66 + 2px) 0 0 var(--neo-ink);
    }

    &:active {
        transform: translate(calc(var(--neo-so) * 0.66), calc(var(--neo-so) * 0.66));
        box-shadow: 0 0 0 0 var(--neo-ink);
    }
`;

type Timer = ReturnType<typeof setInterval>;

export default ({ server }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Nothing worth polling for a suspended server.
        if (isSuspended) return;

        let cancelled = false;

        getStats().then(() => {
            // The card may have been unmounted (page change, filter) while the request was in flight.
            if (!cancelled) {
                interval.current = setInterval(() => getStats(), 30000);
            }
        });

        return () => {
            cancelled = true;
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const connectionError = isSuspended && server.status !== 'suspended';
    const status = connectionError
        ? 'unavailable'
        : resolveStatus({
              power: stats?.status,
              serverStatus: server.status,
              isSuspended,
              isTransferring: server.isTransferring,
          });

    const defaultAllocation = server.allocations.find((allocation) => allocation.isDefault);
    const address = defaultAllocation ? `${defaultAllocation.alias || ip(defaultAllocation.ip)}:${defaultAllocation.port}` : null;

    const limits = server.limits;
    const unlimited = 'Unlimited';
    const cpuLimit = limits.cpu !== 0 ? `${limits.cpu} %` : unlimited;
    const memoryLimit = limits.memory !== 0 ? bytesToString(mbToBytes(limits.memory)) : unlimited;
    const diskLimit = limits.disk !== 0 ? bytesToString(mbToBytes(limits.disk)) : unlimited;

    const showMeters = stats !== null && !isSuspended && status !== 'unavailable' && status !== 'installing';

    return (
        <Card>
            <Stripe style={{ background: statusMeta(status).color }} />
            <Body>
                <Head>
                    <div css={'min-width:0;'}>
                        <Title>{server.name}</Title>
                        {server.description && <Description>{server.description}</Description>}
                    </div>
                    <StatusPill status={status} label={connectionError ? 'Connection Error' : undefined} />
                </Head>

                <Chips>
                    {address && (
                        <CopyOnClick text={address}>
                            <Chip className={'copy'} title={'Click to copy'}>
                                <Globe size={13} />
                                {address}
                            </Chip>
                        </CopyOnClick>
                    )}
                    <Chip>
                        <ServerIcon size={13} />
                        {server.node}
                    </Chip>
                </Chips>

                {showMeters && stats ? (
                    <Meters>
                        <Meter
                            label={'CPU'}
                            value={`${stats.cpuUsagePercent.toFixed(2)} %`}
                            limit={cpuLimit}
                            percent={percentOf(stats.cpuUsagePercent, limits.cpu)}
                            color={'var(--neo-yellow)'}
                        />
                        <Meter
                            label={'Memory'}
                            value={bytesToString(stats.memoryUsageInBytes)}
                            limit={memoryLimit}
                            percent={percentOf(stats.memoryUsageInBytes, mbToBytes(limits.memory))}
                            color={'var(--neo-pink)'}
                        />
                        <Meter
                            label={'Disk'}
                            value={bytesToString(stats.diskUsageInBytes)}
                            limit={diskLimit}
                            percent={percentOf(stats.diskUsageInBytes, mbToBytes(limits.disk))}
                            color={'var(--neo-mint)'}
                        />
                    </Meters>
                ) : status === 'checking' ? (
                    <Notice>
                        <Spinner size={'small'} />
                    </Notice>
                ) : (
                    <Notice>{connectionError ? 'Could not reach the node' : statusMeta(status).label}</Notice>
                )}

                <Manage to={`/server/${server.id}`}>Manage Server</Manage>
            </Body>
        </Card>
    );
};
