import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components/macro';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import CopyOnClick from '@/components/elements/CopyOnClick';
import StatusPill from '@/components/elements/neo/StatusPill';
import Meter from '@/components/elements/neo/Meter';
import { percentOf, resolveStatus } from '@/components/elements/neo/status';

const Tr = styled.tr`
    transition: background-color 0.08s ease;

    &:hover {
        background: var(--secondary-hover);
    }

    & > td {
        padding: 0.85rem 1.1rem;
        vertical-align: middle;
        border-top: 2px solid var(--neo-ink);
        color: var(--color);
        font-weight: 600;
    }
`;

const RowLink = styled(Link)`
    font-weight: 700;
    color: var(--highlight-color);
    text-decoration: underline;
    text-decoration-color: var(--neo-yellow);
    text-decoration-thickness: 3px;

    &:hover {
        background: var(--neo-yellow);
        color: #000;
    }
`;

const Sub = styled.div`
    margin-top: 0.15rem;
    max-width: 22rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 0.75rem;
    font-weight: 500;
    opacity: 0.75;
`;

const Mono = styled.span`
    font-family: 'Space Mono', 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    font-weight: 700;
    color: var(--highlight-color);
    cursor: pointer;

    &:hover {
        background: var(--neo-yellow);
        color: #000;
    }
`;

const Dash = styled.span`
    font-weight: 700;
    opacity: 0.5;
`;

type Timer = ReturnType<typeof setInterval>;

export default ({ server }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        if (isSuspended) return;

        let cancelled = false;

        getStats().then(() => {
            if (!cancelled) {
                interval.current = setInterval(() => getStats(), 30000);
            }
        });

        return () => {
            cancelled = true;
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const connectionError = isSuspended && server.status !== 'suspended';
    const status = connectionError
        ? 'unavailable'
        : resolveStatus({
              power: stats?.status,
              serverStatus: server.status,
              isSuspended,
              isTransferring: server.isTransferring,
          });

    const defaultAllocation = server.allocations.find((allocation) => allocation.isDefault);
    const address = defaultAllocation ? `${defaultAllocation.alias || ip(defaultAllocation.ip)}:${defaultAllocation.port}` : null;

    const limits = server.limits;
    const unlimited = 'Unlimited';
    const showMeters = stats !== null && !isSuspended && status !== 'unavailable' && status !== 'installing';

    return (
        <Tr>
            <td>
                <RowLink to={`/server/${server.id}`}>{server.id}</RowLink>
            </td>
            <td>
                <RowLink to={`/server/${server.id}`}>{server.name}</RowLink>
                {server.description && <Sub>{server.description}</Sub>}
            </td>
            <td>
                {address ? (
                    <CopyOnClick text={address}>
                        <Mono title={'Click to copy'}>{address}</Mono>
                    </CopyOnClick>
                ) : (
                    <Dash>-</Dash>
                )}
            </td>
            {showMeters && stats ? (
                <>
                    <td css={'min-width:150px;'}>
                        <Meter
                            compact
                            value={`${stats.cpuUsagePercent.toFixed(2)} %`}
                            limit={limits.cpu !== 0 ? `${limits.cpu} %` : unlimited}
                            percent={percentOf(stats.cpuUsagePercent, limits.cpu)}
                            color={'var(--neo-yellow)'}
                        />
                    </td>
                    <td css={'min-width:150px;'}>
                        <Meter
                            compact
                            value={bytesToString(stats.memoryUsageInBytes)}
                            limit={limits.memory !== 0 ? bytesToString(mbToBytes(limits.memory)) : unlimited}
                            percent={percentOf(stats.memoryUsageInBytes, mbToBytes(limits.memory))}
                            color={'var(--neo-pink)'}
                        />
                    </td>
                    <td css={'min-width:150px;'}>
                        <Meter
                            compact
                            value={bytesToString(stats.diskUsageInBytes)}
                            limit={limits.disk !== 0 ? bytesToString(mbToBytes(limits.disk)) : unlimited}
                            percent={percentOf(stats.diskUsageInBytes, mbToBytes(limits.disk))}
                            color={'var(--neo-mint)'}
                        />
                    </td>
                </>
            ) : (
                <>
                    <td>
                        <Dash>-</Dash>
                    </td>
                    <td>
                        <Dash>-</Dash>
                    </td>
                    <td>
                        <Dash>-</Dash>
                    </td>
                </>
            )}
            <td>
                <StatusPill status={status} label={connectionError ? 'Connection Error' : undefined} />
            </td>
        </Tr>
    );
};
