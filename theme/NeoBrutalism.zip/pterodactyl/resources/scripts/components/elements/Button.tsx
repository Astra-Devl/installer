import React from 'react';
import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';
import Spinner from '@/components/elements/Spinner';

interface Props {
    isLoading?: boolean;
    size?: 'xsmall' | 'small' | 'large' | 'xlarge';
    color?: 'green' | 'red' | 'primary' | 'grey';
    isSecondary?: boolean;
}

const ButtonStyle = styled.button<Omit<Props, 'isLoading'>>`
    ${tw`relative inline-block p-2 uppercase tracking-wide text-sm`};
    border: var(--neo-border);
    border-radius: var(--neo-radius-sm);
    font-weight: 700;
    letter-spacing: 0.05em;
    color: var(--highlight-color);
    background-color: var(--secondary);
    box-shadow: var(--neo-shadow-btn);
    transition: transform 0.08s ease, box-shadow 0.08s ease, background-color 0.08s ease;

    &:hover:not(:disabled) {
        transform: translate(-2px, -2px);
        box-shadow: calc(var(--neo-so) * 0.66 + 2px) calc(var(--neo-so) * 0.66 + 2px) 0 0 var(--neo-ink);
    }

    &:active:not(:disabled) {
        transform: translate(calc(var(--neo-so) * 0.66), calc(var(--neo-so) * 0.66));
        box-shadow: 0 0 0 0 var(--neo-ink);
    }

    &:focus-visible {
        outline: 3px dashed var(--neo-ink);
        outline-offset: 3px;
    }

    ${(props) =>
        ((!props.isSecondary && !props.color) || props.color === 'primary') &&
        css<Props>`
            ${(props) => !props.isSecondary && 'color:var(--on-primary);'};
            ${(props) => !props.isSecondary && 'background-color:var(--primary);'};

            &:hover:not(:disabled) {
                ${(props) => !props.isSecondary && 'background-color:var(--primary-hover);'};
            }
        `};

    ${(props) =>
        props.color === 'grey' &&
        css`
            color: var(--highlight-color);
            background-color: var(--secondary-hover);

            &:hover:not(:disabled) {
                background-color: var(--neo-yellow);
                color: #000;
            }
        `};

    ${(props) =>
        props.color === 'green' &&
        css<Props>`
            color: #000;
            background-color: var(--neo-mint);

            &:hover:not(:disabled) {
                background-color: #2fc888;
            }
        `};

    ${(props) =>
        props.color === 'red' &&
        css<Props>`
            color: var(--on-danger);
            background-color: var(--danger);

            &:hover:not(:disabled) {
                background-color: var(--danger-hover);
            }
        `};

    ${(props) => props.size === 'xsmall' && tw`px-2 py-1 text-xs`};
    ${(props) => (!props.size || props.size === 'small') && tw`px-4 py-2`};
    ${(props) => props.size === 'large' && tw`p-4 text-sm`};
    ${(props) => props.size === 'xlarge' && tw`p-4 w-full`};

    ${(props) =>
        props.isSecondary &&
        css<Props>`
            color: var(--highlight-color);
            background-color: var(--secondary);

            &:hover:not(:disabled) {
                background-color: var(--neo-yellow);
                color: #000;
                ${(props) => props.color === 'red' && 'background-color:var(--danger); color:var(--on-danger);'};
                ${(props) => props.color === 'primary' && 'background-color:var(--primary); color:var(--on-primary);'};
                ${(props) => props.color === 'green' && 'background-color:var(--neo-mint); color:#000;'};
            }
        `};

    &:disabled {
        opacity: 0.55;
        cursor: not-allowed;
        box-shadow: none;
    }
`;

type ComponentProps = Omit<JSX.IntrinsicElements['button'], 'ref' | keyof Props> & Props;

const Button: React.FC<ComponentProps> = ({ children, isLoading, ...props }) => (
    <ButtonStyle {...props}>
        {isLoading && (
            <div css={tw`flex absolute justify-center items-center w-full h-full left-0 top-0`}>
                <Spinner size={'small'} />
            </div>
        )}
        <span css={isLoading ? tw`text-transparent` : undefined}>{children}</span>
    </ButtonStyle>
);

type LinkProps = Omit<JSX.IntrinsicElements['a'], 'ref' | keyof Props> & Props;

const LinkButton: React.FC<LinkProps> = (props) => <ButtonStyle as={'a'} {...props} />;

export { LinkButton, ButtonStyle };
export default Button;
