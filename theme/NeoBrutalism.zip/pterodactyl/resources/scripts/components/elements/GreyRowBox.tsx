import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex no-underline text-neutral-200 items-center p-4 overflow-hidden`};
    background-color: var(--secondary);
    border:var(--neo-border);
    border-radius:var(--neo-radius-sm);
    box-shadow:var(--neo-shadow-sm);

    ${props => props.$hoverable !== false && 'transition:transform .08s ease, box-shadow .08s ease, background-color .08s ease; &:hover{ background-color:var(--secondary-hover); box-shadow:var(--neo-shadow); transform:translate(-2px, -2px); }'};

    & .icon {
        ${tw`bg-neutral-500 p-3`};
        border:2px solid var(--neo-ink);
        border-radius:var(--neo-radius-sm);
    }
`;
