import styled, { css } from 'styled-components/macro';
import tw from 'twin.macro';

export interface Props {
    isLight?: boolean;
    hasError?: boolean;
}

const light = css<Props>`
    ${tw`bg-white border-neutral-200 text-neutral-800`};
    &:focus {
        ${tw`border-primary-400`}
    }

    &:disabled {
        ${tw`bg-neutral-100 border-neutral-200`};
    }
`;

const checkboxStyle = css<Props>`
    ${tw`bg-neutral-500 cursor-pointer appearance-none inline-block align-middle select-none flex-shrink-0 w-4 h-4 rounded-sm`};
    background-color:var(--input);
    border:3px solid var(--neo-ink);
    color-adjust: exact;
    background-origin: border-box;
    color:var(--primary);
    transition: all 75ms linear, box-shadow 25ms linear;

    &:checked {
        ${tw`bg-no-repeat bg-center`};
        background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='black' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M5.707 7.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4a1 1 0 0 0-1.414-1.414L7 8.586 5.707 7.293z'/%3e%3c/svg%3e");
        background-color: var(--neo-mint);
        background-size: 100% 100%;
    }

    &:focus {
        ${tw`outline-none`};
        border-color:var(--neo-ink);
        box-shadow: var(--neo-shadow-sm);
    }
`;

const inputStyle = css<Props>`
    // Reset to normal styling.
    resize: none;
    ${tw`appearance-none outline-none w-full min-w-0`};
    ${tw`p-3 border-2 text-sm transition-all duration-150`};
    ${tw`text-neutral-200 focus:ring-0`};
    background-color:var(--input);
    color:var(--highlight-color);
    font-weight:600;
    border-radius:var(--neo-radius-sm);
    border:var(--neo-border);
    box-shadow:none;
    transition:transform .08s ease, box-shadow .08s ease;

    & + .input-help {
        ${tw`mt-1 text-xs`};
        ${(props) => (props.hasError ? tw`text-red-200` : tw`text-neutral-200`)};
    }

    &:required,
    &:invalid {
        box-shadow:none;
    }

    &:not(:disabled):not(:read-only):focus {
        transform:translate(-2px, -2px);
        box-shadow:var(--neo-shadow-sm);
        ${(props) => props.hasError && 'box-shadow:calc(var(--neo-so) * 0.6) calc(var(--neo-so) * 0.6) 0 0 var(--danger);'};
    }

    &:disabled {
        ${tw`opacity-75`};
    }

    ${(props) => props.isLight && light};
    ${(props) => props.hasError && tw`text-red-100 border-red-400 hover:border-red-300`};
`;

const Input = styled.input<Props>`
    &:not([type='checkbox']):not([type='radio']) {
        ${inputStyle};
    }

    &[type='checkbox'],
    &[type='radio'] {
        ${checkboxStyle};

        &[type='radio'] {
            ${tw`rounded-full`};
        }
    }
`;
const Textarea = styled.textarea<Props>`
    ${inputStyle}
`;

export { Textarea };
export default Input;
