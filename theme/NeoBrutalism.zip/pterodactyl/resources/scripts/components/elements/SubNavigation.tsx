import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full overflow-x-auto`};
    padding:2px 8px 10px 2px;

    & > div {
        ${tw`flex items-center text-sm mx-auto`};

        & > a, & > div {
            ${tw`inline-block py-3 text-neutral-300 no-underline whitespace-nowrap transition-all duration-150`};
            margin-right:12px;
            margin-bottom:6px;
            padding-left:1.1rem;
            padding-right:1.1rem;
            border:var(--neo-border);
            border-radius:var(--neo-radius-sm);
            background-color:var(--secondary);
            box-shadow:var(--neo-shadow-sm);
            font-weight:700;
            text-transform:uppercase;
            letter-spacing:.04em;
            font-size:.75rem;
            transition:transform .08s ease, box-shadow .08s ease, background-color .08s ease;

            &:hover {
                background-color:var(--neo-yellow);
                color:#000;
                transform:translate(-1px, -1px);
            }

            &.active {
                color:var(--on-primary);
                background-color:var(--primary);
                box-shadow:0 0 0 0 var(--neo-ink);
                transform:translate(calc(var(--neo-so) * 0.6), calc(var(--neo-so) * 0.6));
            }
        }
    }
`;

export default SubNavigation;
