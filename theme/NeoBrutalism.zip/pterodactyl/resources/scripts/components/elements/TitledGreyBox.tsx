import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import tw from 'twin.macro';
import isEqual from 'react-fast-compare';
import styled from 'styled-components/macro';

const Box = styled.div`
& {
    background-color: var(--secondary);
    border:var(--neo-border);
    border-radius:var(--neo-radius);
    box-shadow:var(--neo-shadow);
}
& > div {
    background-color: transparent;
}
& > div:first-of-type {
    background-color: var(--neo-yellow);
    border-bottom:var(--neo-border);
    border-radius:calc(var(--neo-radius) * 0.5) calc(var(--neo-radius) * 0.5) 0 0;
}
& > div:first-of-type p,
& > div:first-of-type svg,
& > div:first-of-type span {
    color:#000 !important;
    font-weight:700;
    letter-spacing:.05em;
}
`;

interface Props {
    icon?: IconProp;
    title: string | React.ReactNode;
    className?: string;
    children: React.ReactNode;
}

const TitledGreyBox = ({ icon, title, children, className }: Props) => (
    <Box className={className}>
        <div css={tw`py-4 px-5`}>
            {typeof title === 'string' ? (
                <p css={tw`text-sm uppercase`}>
                    {icon && <FontAwesomeIcon icon={icon} css={tw`mr-2 text-neutral-300`} />}
                    {title}
                </p>
            ) : (
                title
            )}
        </div>
        <div css={tw`py-4 px-5`}>{children}</div>
    </Box>
);

export default memo(TitledGreyBox, isEqual);
