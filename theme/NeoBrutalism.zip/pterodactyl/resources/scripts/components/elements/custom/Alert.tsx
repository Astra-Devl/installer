import React, { useEffect, useState } from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import getTheme from '@/api/getThemeData';
import AlertDescription from '@/components/elements/custom/AlertDescription';
import tw from 'twin.macro';

/**
 * Announcement banner configured in Admin > Theme > Alert Manager.
 * NeoBrutalism: flat bright colour, thick ink border and a hard shadow.
 */
const Alert = styled.div<{ $color: string }>`
    ${tw`flex items-center px-4 py-3 mt-4`};
    background-color: ${({ $color }) => $color};
    color: #000;
    font-weight: 700;
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow-sm);

    & p,
    & span {
        color: #000;
    }

    & > svg {
        flex-shrink: 0;
    }
`;

const types: { [key: string]: { color: string; icon: React.ReactNode } } = {
    info: { color: '#4d96ff', icon: <Icon.Info css={tw`mr-2`} /> },
    warning: { color: '#ffd93d', icon: <Icon.AlertCircle css={tw`mr-2`} /> },
    error: { color: '#ff5c5c', icon: <Icon.XCircle css={tw`mr-2`} /> },
    success: { color: '#3ddc97', icon: <Icon.CheckCircle css={tw`mr-2`} /> },
};

export default () => {
    const [themeData, setThemeData] = useState<string>();

    useEffect(() => {
        async function getThemeData() {
            const data = await getTheme();
            setThemeData(data.typealert);
        }
        getThemeData();
    }, []);

    const type = themeData ? types[themeData] : undefined;

    if (!type) {
        return null;
    }

    return (
        <Alert $color={type.color}>
            {type.icon} <AlertDescription />
        </Alert>
    );
};
