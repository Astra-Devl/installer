import styled from 'styled-components/macro';
import tw from 'twin.macro';

/**
 * NeoBrutalism sidebar: a flat panel with a thick ink border and a hard offset shadow.
 * Colours come from the CSS variables written by partials/theme-variables.blade.php.
 */
const NavigationBar = styled.div`
    width: 323px;
    flex-shrink: 0;
    background-color: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
    height: calc(100vh - 32px);
    margin: 16px 0 16px 16px;
    position: sticky;
    top: 16px;
    transition: width 0.3s;

    #logo {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    #logo > a {
        padding: 0 !important;
        width: 100%;
        justify-content: center;
        gap: 12px;
    }
    #logo .collapseBtn {
        display: none;
    }
    #logo span {
        padding-left: 0;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 190px;
    }
    #logo img {
        width: 46px;
        height: 46px;
        object-fit: contain;
        border: 2px solid var(--neo-ink);
        border-radius: var(--neo-logo-radius, 0);
        background-color: #ffffff;
        box-shadow: 3px 3px 0 0 var(--neo-ink);
        padding: 4px;
        flex-shrink: 0;
    }

    @media only screen and (min-width: 979px) {
        .collapse & {
            width: 84px;

            #logo img {
                display: block;
            }
            #logo > a > span {
                display: none;
            }

            & a {
                justify-content: center;
                & .icon {
                    margin-right: 0;
                }
                & > span {
                    transition: display 0.3s;
                    display: none;
                }
            }
            .subTitle {
                transition: display 0.3s;
                display: none;
            }
            .logOut {
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }
        }
        & > div:last-of-type {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
    }

    & > div:last-of-type {
        margin-left: 8px;
        padding-left: 6px;
        padding-right: 6px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        height: calc(100vh - 32px);
    }

    & #logo {
        text-align: center;
        padding: 22px 0 18px;

        & > a {
            ${tw`text-2xl font-header no-underline text-neutral-200 hover:text-neutral-100 transition-colors duration-150`};
            display: flex;
            align-items: center;
        }
    }

    & a,
    & button,
    & .navigation-link {
        ${tw`no-underline text-neutral-300 cursor-pointer transition-all duration-150`};
        padding: 8px 0.6em;
        margin: 3px 8px;
        display: flex;
        align-items: center;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.03em;
        border: 3px solid transparent;
        border-radius: var(--neo-radius-sm);
        transition: transform 0.08s ease, box-shadow 0.08s ease, background-color 0.08s ease;

        &:hover {
            background-color: var(--neo-yellow);
            color: #000;
            border-color: var(--neo-ink);
            box-shadow: var(--neo-shadow-sm);
            transform: translate(-1px, -1px);

            .icon {
                color: #000;
            }
        }

        &:active,
        &.active {
            background-color: var(--primary);
            color: var(--on-primary);
            border-color: var(--neo-ink);
            box-shadow: var(--neo-shadow-sm);
            transform: none;

            .icon {
                color: var(--on-primary);
            }
        }

        .icon {
            padding-left: 1px;
            width: 38px;
            height: 38px;
            font-size: 0.6em;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            border: 2px solid var(--neo-ink);
            border-radius: var(--neo-radius-sm);
            background-color: var(--secondary);
            color: var(--highlight-color);
            box-shadow: 2px 2px 0 0 var(--neo-ink);
        }
        &.active .icon,
        &:active .icon {
            box-shadow: none;
            background-color: transparent;
            border-color: var(--on-primary);
        }
        &:hover .icon {
            background-color: #ffffff;
        }
    }
    .logOut {
        ${tw`text-neutral-500`};
        padding-bottom: 0.7em;
        border-top: 3px dashed var(--neo-ink);
        display: flex;
        justify-content: space-between;
        padding-top: 12px;

        a,
        button {
            margin: 0 2px;
            padding: 4px;
        }
        .icon {
            margin-right: 0;
        }
    }
    .media {
        margin-top: auto;
        padding-bottom: 4px;
        padding-top: 25px;
    }
    .subTitle {
        ${tw`text-neutral-500`};
        margin-top: 26px;
        padding: 0 1.1em 4px;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.14em;
    }
    .last {
        margin-bottom: 5px;
    }
    @media only screen and (max-width: 979px) {
        #logo .collapseBtn {
            transform: rotate(90deg);
            display: block;
        }
        .subTitle {
            display: none;
        }
        & {
            width: auto;
            height: auto;
            position: relative;
            top: 0;
            margin: 12px;
        }
        & > div:last-of-type {
            margin-left: 0;
            padding-left: 10px;
            height: auto;
        }
        & a {
            display: none;
        }
        & .logOut {
            display: none;
        }
        & #logo a {
            display: flex;
        }
        .collapse & {
            & a {
                display: flex;
            }
            & .logOut {
                display: flex;
            }
            .subTitle {
                display: block;
            }
        }
    }
`;

export default NavigationBar;
