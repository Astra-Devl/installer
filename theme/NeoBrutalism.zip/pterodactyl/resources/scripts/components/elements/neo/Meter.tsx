import React from 'react';
import styled, { css } from 'styled-components/macro';

const ALARM_AT = 90;

const Wrap = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
    min-width: 0;
`;

const Head = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    gap: 0.5rem;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.07em;
    text-transform: uppercase;
    color: var(--color);
`;

const Value = styled.div`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 0.82rem;
    letter-spacing: 0;
    text-transform: none;
    color: var(--color);

    & > b {
        color: var(--highlight-color);
        font-weight: 700;
    }
`;

const Track = styled.div<{ $compact: boolean; $unlimited: boolean }>`
    position: relative;
    overflow: hidden;
    height: ${(p) => (p.$compact ? '9px' : '16px')};
    background: var(--input);
    border: 2px solid var(--neo-ink);
    border-radius: var(--neo-radius-sm);

    ${(p) =>
        p.$unlimited &&
        css`
            background-image: repeating-linear-gradient(
                135deg,
                transparent 0 6px,
                var(--neo-dot) 6px 12px
            );
        `};
`;

const Fill = styled.div`
    height: 100%;
    box-sizing: border-box;
    border-right: 2px solid var(--neo-ink);
    transition: width 0.4s ease;
`;

interface BarProps {
    percent: number | null;
    color: string;
    compact?: boolean;
    label?: string;
}

/** Just the bar, for places that print the numbers themselves. */
export const MeterBar = ({ percent, color, compact = false, label }: BarProps) => {
    const alarm = percent !== null && percent >= ALARM_AT;

    return (
        <Track
            $compact={compact}
            $unlimited={percent === null}
            role={'progressbar'}
            aria-label={label}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={percent === null ? undefined : Math.round(percent)}
        >
            {percent !== null && percent > 0 && (
                <Fill
                    style={{
                        width: `${percent}%`,
                        background: alarm ? 'var(--danger)' : color,
                        borderRightWidth: percent >= 100 ? 0 : 2,
                    }}
                />
            )}
        </Track>
    );
};

interface MeterProps extends BarProps {
    value: string;
    limit: string;
}

const Meter = ({ label, value, limit, percent, color, compact = false }: MeterProps) => (
    <Wrap>
        <Head>
            {!compact && label && <span>{label}</span>}
            <Value>
                <b>{value}</b> / {limit}
            </Value>
        </Head>
        <MeterBar percent={percent} color={color} compact={compact} label={label} />
    </Wrap>
);

export default Meter;
