import React from 'react';
import styled, { css, keyframes } from 'styled-components/macro';
import { NeoStatusKey, statusMeta } from '@/components/elements/neo/status';

const blink = keyframes`
    0%, 100% { opacity: 1; }
    50% { opacity: 0.2; }
`;

const Pill = styled.span<{ $color: string; $large: boolean }>`
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    flex-shrink: 0;
    background: ${(p) => p.$color};
    color: #000;
    border: 2px solid var(--neo-ink);
    border-radius: var(--neo-radius-sm);
    box-shadow: 2px 2px 0 0 var(--neo-ink);
    padding: ${(p) => (p.$large ? '0.3rem 0.85rem' : '0.15rem 0.6rem')};
    font-size: ${(p) => (p.$large ? '0.85rem' : '0.7rem')};
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
`;

const Dot = styled.i<{ $pulse: boolean }>`
    display: inline-block;
    width: 0.55rem;
    height: 0.55rem;
    border-radius: 50%;
    background: #000;

    ${(p) =>
        p.$pulse &&
        css`
            @media (prefers-reduced-motion: no-preference) {
                animation: ${blink} 1s steps(2, start) infinite;
            }
        `};
`;

interface Props {
    status: NeoStatusKey;
    /** Replaces the default label, e.g. "Connection Error". */
    label?: string;
    large?: boolean;
    className?: string;
}

const StatusPill = ({ status, label, large = false, className }: Props) => {
    const meta = statusMeta(status);

    return (
        <Pill className={className} $color={meta.color} $large={large} role={'status'}>
            <Dot $pulse={meta.pulse} />
            {label || meta.label}
        </Pill>
    );
};

export default StatusPill;
