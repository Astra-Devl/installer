/**
 * Shared status vocabulary for the NeoBrutalism theme. Every place that shows the state of a
 * server (dashboard card, table row, console header, side panel) goes through here so the label
 * and the colour always agree.
 */
export type NeoStatusKey =
    | 'running'
    | 'offline'
    | 'starting'
    | 'stopping'
    | 'suspended'
    | 'installing'
    | 'transferring'
    | 'restoring'
    | 'unavailable'
    | 'checking';

export interface NeoStatusMeta {
    label: string;
    color: string;
    pulse: boolean;
}

const META: Record<NeoStatusKey, NeoStatusMeta> = {
    running: { label: 'Online', color: 'var(--neo-mint)', pulse: false },
    offline: { label: 'Offline', color: 'var(--danger)', pulse: false },
    starting: { label: 'Starting', color: 'var(--neo-yellow)', pulse: true },
    stopping: { label: 'Stopping', color: 'var(--neo-orange)', pulse: true },
    suspended: { label: 'Suspended', color: 'var(--neo-pink)', pulse: false },
    installing: { label: 'Installing', color: 'var(--neo-blue)', pulse: true },
    transferring: { label: 'Transferring', color: 'var(--neo-blue)', pulse: true },
    restoring: { label: 'Restoring', color: 'var(--neo-blue)', pulse: true },
    unavailable: { label: 'Unavailable', color: 'var(--secondary-hover)', pulse: false },
    checking: { label: 'Checking', color: 'var(--secondary-hover)', pulse: true },
};

export const statusMeta = (key: NeoStatusKey): NeoStatusMeta => META[key];

interface ResolveInput {
    /** Power state reported by the daemon (offline | starting | running | stopping). */
    power?: string | null;
    /** Panel level status of the server (installing, suspended, restoring_backup, ...). */
    serverStatus?: string | null;
    isSuspended?: boolean;
    isTransferring?: boolean;
}

export const resolveStatus = ({ power, serverStatus, isSuspended, isTransferring }: ResolveInput): NeoStatusKey => {
    if (isSuspended || serverStatus === 'suspended') return 'suspended';
    if (isTransferring) return 'transferring';
    if (serverStatus === 'installing') return 'installing';
    if (serverStatus === 'restoring_backup') return 'restoring';
    if (serverStatus) return 'unavailable';

    switch (power) {
        case 'running':
            return 'running';
        case 'starting':
            return 'starting';
        case 'stopping':
            return 'stopping';
        case 'offline':
            return 'offline';
        default:
            return 'checking';
    }
};

/** Usage as a 0-100 number, or null when the limit is 0 (= unlimited). */
export const percentOf = (current: number, limit: number): number | null =>
    limit > 0 ? Math.min(100, Math.max(0, (current / limit) * 100)) : null;
