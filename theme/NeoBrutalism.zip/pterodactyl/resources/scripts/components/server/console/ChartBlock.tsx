import React from 'react';
import classNames from 'classnames';
import styles from '@/components/server/console/style.module.css';

interface ChartBlockProps {
    title: string;
    legend?: React.ReactNode;
    /** Colour of the header strip, e.g. `var(--neo-pink)`. */
    color?: string;
    children: React.ReactNode;
}

export default ({ title, legend, color, children }: ChartBlockProps) => (
    <div className={classNames(styles.chart_container, 'group')}>
        <div className={styles.chart_header} style={color ? { background: color } : undefined}>
            <h3 className={'font-header'}>{title}</h3>
            {legend && <div className={styles.chart_legend}>{legend}</div>}
        </div>
        <div className={'z-10 px-2 pt-2'}>{children}</div>
    </div>
);
