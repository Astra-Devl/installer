import React, { useEffect, useMemo, useState } from 'react';
import styled from 'styled-components/macro';
import * as Icon from 'react-feather';
import { bytesToString, mbToBytes } from '@/lib/formatters';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import UptimeDuration from '@/components/server/UptimeDuration';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { MeterBar } from '@/components/elements/neo/Meter';
import { percentOf } from '@/components/elements/neo/status';

const Grid = styled.div`
    display: grid;
    grid-template-columns: repeat(1, minmax(0, 1fr));
    gap: 1.25rem;
    margin-bottom: 1.25rem;

    @media (min-width: 768px) {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
`;

const Card = styled.div`
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
`;

const CardHead = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    color: #000;
    border-bottom: var(--neo-border);
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
`;

const CardBody = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    padding: 1rem 1.1rem 1.2rem;
`;

const Big = styled.div`
    font-size: clamp(1.7rem, 3.2vw, 2.4rem);
    font-weight: 700;
    line-height: 1;
    letter-spacing: -0.02em;
    color: var(--highlight-color);
    white-space: nowrap;
`;

const Limit = styled.div`
    display: flex;
    justify-content: space-between;
    gap: 0.5rem;
    font-size: 0.78rem;
    font-weight: 700;
    color: var(--color);
`;

const MiniRow = styled.div`
    display: grid;
    grid-template-columns: repeat(1, minmax(0, 1fr));
    gap: 1.25rem;
    margin-bottom: 1.25rem;

    @media (min-width: 640px) {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
`;

const Mini = styled.div`
    display: flex;
    align-items: center;
    gap: 0.8rem;
    padding: 0.7rem 1rem;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow-sm);

    & > .badge {
        display: flex;
        flex-shrink: 0;
        align-items: center;
        justify-content: center;
        width: 2.4rem;
        height: 2.4rem;
        color: #000;
        border: 2px solid var(--neo-ink);
        border-radius: var(--neo-radius-sm);
        box-shadow: 2px 2px 0 0 var(--neo-ink);
    }

    & > div > span {
        display: block;
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--color);
    }

    & > div > b {
        display: block;
        font-size: 1.05rem;
        font-weight: 700;
        color: var(--highlight-color);
    }
`;

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

const ServerDetailsBlock = ({ className }: { className?: string }) => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);

    const labels = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    useEffect(() => {
        if (!connected || !instance) {
            return;
        }

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let parsed: any = {};
        try {
            parsed = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: parsed.memory_bytes,
            cpu: parsed.cpu_absolute,
            disk: parsed.disk_bytes,
            tx: parsed.network?.tx_bytes || 0,
            rx: parsed.network?.rx_bytes || 0,
            uptime: parsed.uptime || 0,
        });
    });

    const infinity = <>&infin;</>;
    const online = status !== 'offline' && stats.uptime > 0;

    return (
        <div className={className}>
            <Grid>
                <Card>
                    <CardHead style={{ background: 'var(--neo-yellow)' }}>
                        <span>CPU</span>
                        <Icon.Cpu size={18} />
                    </CardHead>
                    <CardBody>
                        <Big>{stats.cpu.toFixed(2)}%</Big>
                        <MeterBar percent={percentOf(stats.cpu, limits?.cpu || 0)} color={'var(--neo-yellow)'} label={'CPU usage'} />
                        <Limit>
                            <span>Limit</span>
                            <span>{labels.cpu || infinity}</span>
                        </Limit>
                    </CardBody>
                </Card>
                <Card>
                    <CardHead style={{ background: 'var(--neo-pink)' }}>
                        <span>Memory</span>
                        <Icon.Activity size={18} />
                    </CardHead>
                    <CardBody>
                        <Big>{bytesToString(stats.memory)}</Big>
                        <MeterBar
                            percent={percentOf(stats.memory, mbToBytes(limits?.memory || 0))}
                            color={'var(--neo-pink)'}
                            label={'Memory usage'}
                        />
                        <Limit>
                            <span>Limit</span>
                            <span>{labels.memory || infinity}</span>
                        </Limit>
                    </CardBody>
                </Card>
                <Card>
                    <CardHead style={{ background: 'var(--neo-mint)' }}>
                        <span>Disk</span>
                        <Icon.HardDrive size={18} />
                    </CardHead>
                    <CardBody>
                        <Big>{bytesToString(stats.disk)}</Big>
                        <MeterBar
                            percent={percentOf(stats.disk, mbToBytes(limits?.disk || 0))}
                            color={'var(--neo-mint)'}
                            label={'Disk usage'}
                        />
                        <Limit>
                            <span>Limit</span>
                            <span>{labels.disk || infinity}</span>
                        </Limit>
                    </CardBody>
                </Card>
            </Grid>
            <MiniRow>
                <Mini>
                    <div className={'badge'} style={{ background: 'var(--neo-orange)' }}>
                        <Icon.Clock size={18} />
                    </div>
                    <div>
                        <span>Uptime</span>
                        <b>{online ? <UptimeDuration uptime={stats.uptime / 1000} /> : '-'}</b>
                    </div>
                </Mini>
                <Mini>
                    <div className={'badge'} style={{ background: 'var(--neo-mint)' }}>
                        <Icon.Download size={18} />
                    </div>
                    <div>
                        <span>Network in</span>
                        <b>{bytesToString(stats.rx)}</b>
                    </div>
                </Mini>
                <Mini>
                    <div className={'badge'} style={{ background: 'var(--neo-blue)' }}>
                        <Icon.Upload size={18} />
                    </div>
                    <div>
                        <span>Network out</span>
                        <b>{bytesToString(stats.tx)}</b>
                    </div>
                </Mini>
            </MiniRow>
        </div>
    );
};

export default ServerDetailsBlock;
