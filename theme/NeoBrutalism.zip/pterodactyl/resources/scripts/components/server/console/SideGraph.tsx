import React, { useEffect, useMemo, useState } from 'react';
import styled from 'styled-components/macro';
import * as Icon from 'react-feather';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { ServerContext } from '@/state/server';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import UptimeDuration from '@/components/server/UptimeDuration';
import RamGraph from '@/components/server/console/graphs/RamGraph';
import CPUGraph from '@/components/server/console/graphs/CPUGraph';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import StatusPill from '@/components/elements/neo/StatusPill';
import { MeterBar } from '@/components/elements/neo/Meter';
import { percentOf, resolveStatus } from '@/components/elements/neo/status';

const Panel = styled.div`
    position: relative;
    margin-bottom: 1.25rem;
    overflow: hidden;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
`;

const Head = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
    padding: 0.45rem 1rem;
    color: #000;
    border-bottom: var(--neo-border);
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
`;

const Info = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    padding: 1rem 1.1rem 1.2rem;

    & > b {
        font-size: 1.05rem;
        line-height: 1.2;
        color: var(--highlight-color);
        word-break: break-word;
    }
`;

const Line = styled.div`
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--color);
    word-break: break-all;

    & > svg {
        flex-shrink: 0;
        color: var(--primary);
    }

    &.copy {
        cursor: pointer;
    }

    &.copy:hover {
        text-decoration: underline;
        text-decoration-color: var(--neo-yellow);
        text-decoration-thickness: 3px;
    }
`;

// Value on top, the live graph sits behind it at the bottom of the card.
const GraphBody = styled.div`
    position: relative;
    height: 150px;
    overflow: hidden;

    & > .value {
        position: relative;
        z-index: 10;
        padding: 0.9rem 1.1rem 0;
        color: var(--highlight-color);
    }

    & > .value > p {
        font-size: clamp(1.6rem, 2.6vw, 2.1rem);
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
    }

    & > .value > span {
        display: block;
        margin-top: 0.3rem;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: var(--color);
    }

    & canvas {
        position: absolute;
        bottom: -2px;
        left: 0;
        z-index: 1;
        width: 100% !important;
        max-height: 100px;
    }
`;

const DiskBody = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    padding: 0.9rem 1.1rem 1.1rem;

    & > p {
        font-size: clamp(1.6rem, 2.6vw, 2.1rem);
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        color: var(--highlight-color);
    }

    & > span {
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: var(--color);
    }
`;

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

const SideGraph = () => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });

    const power = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const serverID = ServerContext.useStoreState((state) => state.server.data!.id);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    const labels = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    useEffect(() => {
        if (!connected || !instance) {
            return;
        }

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    // One listener only: the old version registered the same handler twice.
    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let parsed: any = {};
        try {
            parsed = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: parsed.memory_bytes,
            cpu: parsed.cpu_absolute,
            disk: parsed.disk_bytes,
            tx: parsed.network?.tx_bytes || 0,
            rx: parsed.network?.rx_bytes || 0,
            uptime: parsed.uptime || 0,
        });
    });

    const status = resolveStatus({
        power,
        serverStatus: isInstalling ? 'installing' : null,
        isTransferring,
    });

    const infinity = <>&infin;</>;

    return (
        <div className={'break-words'}>
            <Panel>
                <Head style={{ background: 'var(--neo-blue)' }}>
                    <span>Server</span>
                    <StatusPill status={status} />
                </Head>
                <Info>
                    <b>{name}</b>
                    {stats.uptime > 0 && power !== 'offline' && (
                        <Line>
                            <Icon.Power size={16} />
                            <UptimeDuration uptime={stats.uptime / 1000} />
                        </Line>
                    )}
                    <CopyOnClick text={allocation}>
                        <Line className={'copy'}>
                            <Icon.Globe size={16} />
                            {allocation}
                        </Line>
                    </CopyOnClick>
                    <CopyOnClick text={serverID}>
                        <Line className={'copy'}>
                            <Icon.Hash size={16} />
                            {serverID}
                        </Line>
                    </CopyOnClick>
                    <Line>
                        <Icon.Server size={16} />
                        {node}
                    </Line>
                </Info>
            </Panel>

            <Panel>
                <Head style={{ background: 'var(--neo-pink)' }}>
                    <span>Memory</span>
                    <Icon.Activity size={16} />
                </Head>
                <GraphBody>
                    <div className={'value'}>
                        <p>{bytesToString(stats.memory)}</p>
                        <span>/ {labels.memory || infinity} ram</span>
                    </div>
                    <RamGraph />
                </GraphBody>
            </Panel>

            <Panel>
                <Head style={{ background: 'var(--neo-yellow)' }}>
                    <span>CPU</span>
                    <Icon.Cpu size={16} />
                </Head>
                <GraphBody>
                    <div className={'value'}>
                        <p>{stats.cpu.toFixed(2)}%</p>
                        <span>/ {labels.cpu || infinity} cpu</span>
                    </div>
                    <CPUGraph />
                </GraphBody>
            </Panel>

            <Panel>
                <Head style={{ background: 'var(--neo-mint)' }}>
                    <span>Disk</span>
                    <Icon.HardDrive size={16} />
                </Head>
                <DiskBody>
                    <p>{bytesToString(stats.disk)}</p>
                    <MeterBar
                        percent={percentOf(stats.disk, mbToBytes(limits?.disk || 0))}
                        color={'var(--neo-mint)'}
                        label={'Disk usage'}
                    />
                    <span>/ {labels.disk || infinity} disk</span>
                </DiskBody>
            </Panel>
        </div>
    );
};

export default SideGraph;
