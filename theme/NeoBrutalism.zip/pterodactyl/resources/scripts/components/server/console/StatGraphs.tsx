import React, { useEffect, useRef } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { Line } from 'react-chartjs-2';
import { useChart, useChartTickLabel } from '@/components/server/console/chart';
import { hexToRgba } from '@/lib/helpers';
import { bytesToString } from '@/lib/formatters';
import { NEO } from '@/lib/neoColors';
import ChartBlock from '@/components/server/console/ChartBlock';
import styles from '@/components/server/console/style.module.css';

export default () => {
    const status = ServerContext.useStoreState((state) => state.status.value);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const previous = useRef<Record<'tx' | 'rx', number>>({ tx: -1, rx: -1 });

    const cpu = useChartTickLabel('CPU', limits.cpu, '%', 2, NEO.yellow);
    const memory = useChartTickLabel('Memory', limits.memory, 'MB', undefined, NEO.pink);
    const network = useChart('Network', {
        sets: 2,
        options: {
            scales: {
                y: {
                    ticks: {
                        callback(value) {
                            return bytesToString(typeof value === 'string' ? parseInt(value, 10) : value);
                        },
                    },
                },
            },
        },
        // The first set is what the server sends (outbound), the second what it receives (inbound).
        callback(opts, index) {
            return {
                ...opts,
                label: !index ? 'Network Out' : 'Network In',
                backgroundColor: hexToRgba(!index ? NEO.blue : NEO.mint, 0.85),
            };
        },
    });

    useEffect(() => {
        if (status === 'offline') {
            cpu.clear();
            memory.clear();
            network.clear();
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let values: any = {};
        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }
        cpu.push(values.cpu_absolute);
        memory.push(Math.floor(values.memory_bytes / 1024 / 1024));
        network.push([
            previous.current.tx < 0 ? 0 : Math.max(0, values.network.tx_bytes - previous.current.tx),
            previous.current.rx < 0 ? 0 : Math.max(0, values.network.rx_bytes - previous.current.rx),
        ]);

        previous.current = { tx: values.network.tx_bytes, rx: values.network.rx_bytes };
    });

    return (
        <>
            <ChartBlock title={'CPU Load'} color={'var(--neo-yellow)'}>
                <Line {...cpu.props} />
            </ChartBlock>
            <ChartBlock title={'Memory'} color={'var(--neo-pink)'}>
                <Line {...memory.props} />
            </ChartBlock>
            <ChartBlock
                title={'Network'}
                color={'var(--neo-blue)'}
                legend={
                    <>
                        <span className={styles.legend_key}>
                            <i style={{ background: NEO.mint }} />
                            In
                        </span>
                        <span className={styles.legend_key}>
                            <i style={{ background: NEO.blue }} />
                            Out
                        </span>
                    </>
                }
            >
                <Line {...network.props} />
            </ChartBlock>
        </>
    );
};