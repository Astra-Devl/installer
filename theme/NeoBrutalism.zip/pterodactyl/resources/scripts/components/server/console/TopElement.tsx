import React from 'react';
import styled from 'styled-components/macro';
import * as Icon from 'react-feather';
import { ServerContext } from '@/state/server';
import CopyOnClick from '@/components/elements/CopyOnClick';
import StatusPill from '@/components/elements/neo/StatusPill';
import { resolveStatus, statusMeta } from '@/components/elements/neo/status';
import { ip } from '@/lib/formatters';

const Card = styled.div`
    position: relative;
    margin-bottom: 1.25rem;
    overflow: hidden;
    background: var(--secondary);
    border: var(--neo-border);
    border-radius: var(--neo-radius);
    box-shadow: var(--neo-shadow);
`;

const Stripe = styled.div`
    height: 14px;
    border-bottom: var(--neo-border);
    background-image: repeating-linear-gradient(135deg, rgba(0, 0, 0, 0.16) 0 8px, transparent 8px 16px);
`;

const Body = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.9rem;
    padding: 1.2rem 1.5rem 1.4rem;
`;

const Head = styled.div`
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
`;

const Name = styled.h1`
    margin: 0;
    min-width: 0;
    font-size: 1.6rem;
    font-weight: 700;
    line-height: 1.15;
    color: var(--highlight-color);
    word-break: break-word;
`;

const Description = styled.p`
    margin-top: -0.3rem;
    font-size: 0.85rem;
    opacity: 0.8;
`;

const Chips = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: 0.6rem;
`;

const Chip = styled.span`
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    padding: 0.3rem 0.7rem;
    color: var(--highlight-color);
    background: var(--secondary-hover);
    border: 2px solid var(--neo-ink);
    border-radius: var(--neo-radius-sm);
    box-shadow: 2px 2px 0 0 var(--neo-ink);
    font-family: 'Space Mono', 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    font-weight: 700;

    & > svg {
        flex-shrink: 0;
    }

    &.copy:hover {
        background: var(--neo-yellow);
        color: #000;
    }
`;

const TopElement = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const power = ServerContext.useStoreState((state) => state.status.value);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    const status = resolveStatus({
        power,
        serverStatus: isInstalling ? 'installing' : null,
        isTransferring,
    });

    return (
        <Card>
            <Stripe style={{ background: statusMeta(status).color }} />
            <Body>
                <Head>
                    <Name>{name}</Name>
                    <StatusPill status={status} large />
                </Head>
                {description && <Description>{description}</Description>}
                <Chips>
                    <CopyOnClick text={allocation}>
                        <Chip className={'copy'} title={'Click to copy'}>
                            <Icon.Globe size={16} />
                            {allocation}
                        </Chip>
                    </CopyOnClick>
                    <CopyOnClick text={id}>
                        <Chip className={'copy'} title={'Click to copy'}>
                            <Icon.Hash size={16} />
                            {id}
                        </Chip>
                    </CopyOnClick>
                    <Chip>
                        <Icon.Server size={16} />
                        {node}
                    </Chip>
                </Chips>
            </Body>
        </Card>
    );
};

export default TopElement;
