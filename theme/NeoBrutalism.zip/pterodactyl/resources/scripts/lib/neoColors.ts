/**
 * Canvas based widgets (chart.js) cannot read `var(--x)` colours, so the NeoBrutalism palette is
 * mirrored here. The values match the tokens in resources/views/partials/theme-variables.blade.php.
 */
export const NEO = {
    yellow: '#ffd93d',
    pink: '#ff6bb5',
    mint: '#3ddc97',
    blue: '#4d96ff',
    orange: '#ff9f1c',
} as const;

/**
 * Reads a CSS variable as it is right now. `.darkmode` lives on <body>, so the value has to come
 * from there to follow the moon toggle.
 */
export const cssVar = (name: string, fallback: string): string => {
    if (typeof window === 'undefined' || !document.body) {
        return fallback;
    }

    const value = getComputedStyle(document.body).getPropertyValue(name).trim();

    return value || fallback;
};
