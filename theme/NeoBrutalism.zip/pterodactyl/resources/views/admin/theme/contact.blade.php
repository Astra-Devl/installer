@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'contact'])

@section('title')
    Theme Settings
@endsection

@section('content-header')
    <h1>Contact Settings<small>"Contact website owner" button on the login page.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Contact the website owner</h3>
                </div>
                <form action="{{ route('admin.theme.contact.update') }}" method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="contact_enabled" value="1" @if(old('contact_enabled', $theme->contact_enabled)) checked @endif>
                                        Show the contact buttons under "Forgot password?" on the login page
                                    </label>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label" for="contact_label">Title above the buttons</label>
                                <input id="contact_label" type="text" class="form-control" name="contact_label" maxlength="60" value="{{ old('contact_label', $theme->contact_label) }}" required />
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label" for="contact_message">WhatsApp pre-filled message</label>
                                <input id="contact_message" type="text" class="form-control" name="contact_message" maxlength="200" value="{{ old('contact_message', $theme->contact_message) }}" />
                                <p class="text-muted"><small>Optional. The text that is already typed when the chat opens.</small></p>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label" for="contact_whatsapp">WhatsApp number</label>
                                <input id="contact_whatsapp" type="text" class="form-control" name="contact_whatsapp" value="{{ old('contact_whatsapp', $theme->contact_whatsapp) }}" placeholder="6281234567890" />
                                <p class="text-muted"><small>Include the country code, e.g. <code>6281234567890</code>. A number starting with <code>0</code> is converted to <code>62</code> (Indonesia). Leave empty to hide the WhatsApp button.</small></p>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label" for="contact_telegram">Telegram username</label>
                                <input id="contact_telegram" type="text" class="form-control" name="contact_telegram" value="{{ old('contact_telegram', $theme->contact_telegram) }}" placeholder="username" />
                                <p class="text-muted"><small>Username only (without <code>@</code>), e.g. <code>myusername</code>. Leave empty to hide the Telegram button.</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
