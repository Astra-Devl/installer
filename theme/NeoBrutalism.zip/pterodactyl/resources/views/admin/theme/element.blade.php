@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'element'])

@section('title')
    Theme Settings
@endsection

@section('content-header')
    <h1>Elements Manager<small>Choose what the dashboard and the console show.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    @php
        $neoToggles = [
            'infoelement' => ['Server info header', 'Big header on the console page: server name, status, IP, ID and node.', 'fa-id-card-o'],
            'graphcard' => ['Stat cards', 'CPU, memory and disk cards with usage bars, plus uptime and network totals.', 'fa-tachometer'],
            'sidegraph' => ['Side graphs', 'Left column with live memory and CPU graphs next to the console.', 'fa-area-chart'],
            'subnavigation' => ['Sub navigation bar', 'The row of buttons for Console, Files, Databases and the other server pages.', 'fa-bars'],
        ];
    @endphp
    <form action="{{ route('admin.theme.element.update') }}" method="POST">
        <div class="row neo-fields">
            <div class="col-xs-12 col-md-5">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-list"></i> Server list layout</h3>
                    </div>
                    <div class="box-body">
                        <p class="text-muted" style="margin-bottom:16px;">Default layout of the dashboard. Every user can still switch between Cards and Table for themselves.</p>
                        <div class="neo-tiles">
                            <label class="neo-tile">
                                <input type="radio" name="newserverlist" value="table" @if(old('newserverlist', $theme->newserverlist) !== 'cards') checked @endif>
                                <span class="neo-tile-face">
                                    <span class="neo-ill neo-ill-table"><i></i><i></i><i></i></span>
                                    <b>Table</b>
                                    <small>Compact rows with live meters</small>
                                </span>
                            </label>
                            <label class="neo-tile">
                                <input type="radio" name="newserverlist" value="cards" @if(old('newserverlist', $theme->newserverlist) === 'cards') checked @endif>
                                <span class="neo-tile-face">
                                    <span class="neo-ill neo-ill-cards"><i></i><i></i><i></i><i></i></span>
                                    <b>Cards</b>
                                    <small>Big cards with status stripe</small>
                                </span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-7">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-toggle-on"></i> Console &amp; navigation</h3>
                    </div>
                    <div class="box-body">
                        <div class="neo-toggles">
                            @foreach ($neoToggles as $field => $toggle)
                                <label class="neo-toggle">
                                    <input type="hidden" name="{{ $field }}" value="0">
                                    <input type="checkbox" name="{{ $field }}" value="1" @if(old($field, $theme->{$field})) checked @endif>
                                    <span class="neo-toggle-icon"><i class="fa {{ $toggle[2] }}"></i></span>
                                    <span class="neo-toggle-text"><b>{{ $toggle[0] }}</b><small>{{ $toggle[1] }}</small></span>
                                    <span class="neo-toggle-switch"></span>
                                </label>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row neo-fields">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
