@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'protection'])

@section('title')
    Theme Settings
@endsection

@section('content-header')
    <h1>Protection<small>Block risky admin actions and show a red floating warning instead of a 403 / 500 page.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <form action="{{ route('admin.theme.protection.update') }}" method="POST" id="protection-form">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Protection middleware</h3>
                    </div>
                    <div class="box-body">
                        <div class="checkbox" style="margin-top:0;">
                            <label><input type="checkbox" name="antirusuh_enabled" value="1" @if(old('antirusuh_enabled', $protection['enabled'])) checked @endif> <strong>Protection enabled</strong></label>
                        </div>
                        <p class="text-muted"><small>When an admin that is not on the allowed list tries one of the actions below, nothing happens except a red floating notification.</small></p>
                        <hr>
                        <div class="form-group">
                            <label class="control-label">Actions that need the main admin</label>
                            @php($activeRules = old('rules', $protection['rules']))
                            @foreach (\Pterodactyl\Services\Theme\ThemeSettings::PROTECTION_RULES as $key => $label)
                                <div class="checkbox">
                                    <label style="text-transform:none;letter-spacing:0;font-size:14px;">
                                        <input type="checkbox" name="rules[]" value="{{ $key }}" @if(in_array($key, (array) $activeRules, true)) checked @endif>
                                        {{ ucfirst($label) }}
                                    </label>
                                </div>
                            @endforeach
                            <p class="text-muted"><small>&ldquo;Membuka halaman kelola server&rdquo; also hides the admin server pages (view / build / startup / manage) from other admins.</small></p>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="antirusuh_allowed">Allowed admin IDs</label>
                            <input id="antirusuh_allowed" type="text" class="form-control" name="antirusuh_allowed" value="{{ old('antirusuh_allowed', implode(', ', $protection['allowed'])) }}" placeholder="1, 2">
                            <p class="text-muted"><small>Comma separated user IDs that may do the protected actions. Admin ID 1 is always allowed.</small></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Floating warning notification</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="antirusuh_color">Warning colour</label>
                                <input id="antirusuh_color" type="color" class="form-control" name="antirusuh_color" value="{{ old('antirusuh_color', $theme->antirusuh_color) }}">
                                <p class="text-muted"><small>Background of the notification (default red).</small></p>
                            </div>
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="antirusuh_textcolor">Text colour</label>
                                <input id="antirusuh_textcolor" type="color" class="form-control" name="antirusuh_textcolor" value="{{ old('antirusuh_textcolor', $theme->antirusuh_textcolor) }}">
                                <p class="text-muted"><small>Colour of the title and the message.</small></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="antirusuh_title">Title</label>
                            <input id="antirusuh_title" type="text" class="form-control" name="antirusuh_title" maxlength="40" value="{{ old('antirusuh_title', $theme->antirusuh_title) }}">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="antirusuh_message">Message</label>
                            <input id="antirusuh_message" type="text" class="form-control" name="antirusuh_message" maxlength="200" value="{{ old('antirusuh_message', $theme->antirusuh_message) }}">
                            <p class="text-muted"><small><code>:action</code> is replaced with what was blocked, e.g. &ldquo;menghapus server&rdquo;.</small></p>
                        </div>
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="antirusuh_position">Position</label>
                                <select id="antirusuh_position" class="form-control" name="antirusuh_position">
                                    @foreach (\Pterodactyl\Services\Theme\ThemeSettings::TOAST_POSITIONS as $position)
                                        <option value="{{ $position }}" @if(old('antirusuh_position', $theme->antirusuh_position) === $position) selected @endif>{{ ucwords(str_replace('-', ' ', $position)) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-sm-6">
                                <label class="control-label" for="antirusuh_duration">Visible for (seconds)</label>
                                <input id="antirusuh_duration" type="number" min="0" max="60" class="form-control" name="antirusuh_duration" value="{{ old('antirusuh_duration', $theme->antirusuh_duration) }}">
                                <p class="text-muted"><small>0 = stays until it is closed.</small></p>
                            </div>
                        </div>
                        <button type="button" class="btn btn-warning" id="neo-toast-test"><i class="fa fa-bell"></i> Test notification</button>
                        <p class="text-muted" style="margin-top:8px;"><small>Shows the notification with the values above, before you save.</small></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('#neo-toast-test').on('click', function () {
            var message = ($('#antirusuh_message').val() || 'Hanya admin utama yang boleh :action.').replace(':action', 'menghapus server');
            NeoToast.show(message, {
                title: $('#antirusuh_title').val(),
                color: $('#antirusuh_color').val(),
                textColor: $('#antirusuh_textcolor').val(),
                position: $('#antirusuh_position').val(),
                duration: $('#antirusuh_duration').val()
            });
        });
    </script>
@endsection
