{{-- NeoBrutalism skin for the AdminLTE based admin area. Colours/tokens come from partials/theme-variables. --}}
<style>
    body, body.skin-blue { font-family: 'Space Grotesk', 'Segoe UI', system-ui, sans-serif; font-weight: 500; color: var(--color); background-color: var(--background-color); }
    .wrapper, .content-wrapper, .right-side, .main-footer { background: transparent !important; color: var(--color); }
    .content-wrapper { padding-top: 10px; }
    .main-footer { border-top: var(--neo-border); background: var(--secondary) !important; color: var(--color); font-weight: 600; }
    .main-footer a { color: var(--primary); font-weight: 700; }
    a { color: var(--primary); font-weight: 600; }
    a:hover, a:focus { color: var(--highlight-color); text-decoration: underline; text-decoration-thickness: 3px; }
    h1, h2, h3, h4, h5, h6, .content-header > h1 { color: var(--highlight-color); font-family: 'Space Grotesk', sans-serif; font-weight: 700; letter-spacing: -.01em; }
    .content-header > h1 { text-transform: uppercase; display: inline-block; background: var(--neo-yellow); color: #000; border: var(--neo-border); box-shadow: var(--neo-shadow-sm); padding: 6px 14px; margin-bottom: 6px; }
    .content-header > h1 > small, .text-muted, small { color: var(--color-4); font-weight: 600; text-transform: none; }
    .content-header > h1 > small { color: #000; opacity: .75; margin-left: 8px; }
    .content-header > .breadcrumb { background: transparent; }
    .content-header > .breadcrumb > li > a, .breadcrumb > .active { color: var(--color); font-weight: 700; text-transform: uppercase; font-size: 11px; letter-spacing: .06em; }

    /* Header */
    .skin-blue .main-header { box-shadow: none; max-height: none; border-bottom: var(--neo-border); background: var(--secondary); }
    .skin-blue .main-header .navbar { background: var(--secondary); border: 0; }
    .skin-blue .main-header .logo { background: var(--neo-yellow); color: #000; font-weight: 700; font-family: 'Space Grotesk', sans-serif; border: 0; border-right: var(--neo-border); height: 50px; line-height: 1; padding: 0 12px; overflow: hidden; text-transform: uppercase; letter-spacing: .02em; }
    .skin-blue .main-header .logo:hover { background: var(--neo-orange); color: #000; text-decoration: none; }
    .skin-blue .main-header .logo img { width: 34px; height: 34px; object-fit: contain; border: 2px solid #000; border-radius: var(--neo-logo-radius); box-shadow: 3px 3px 0 0 #000; background: #fff; flex: 0 0 auto; }
    /* Only ONE logo variant at a time: full logo + name normally, the small one when the sidebar is collapsed. */
    .skin-blue .main-header .logo .logo-mini, .skin-blue .main-header .logo .logo-lg { height: 50px; align-items: center; justify-content: center; gap: 10px; margin: 0; font-size: inherit; }
    .skin-blue .main-header .logo .logo-mini { display: none !important; }
    .skin-blue .main-header .logo .logo-lg { display: flex !important; }
    @media (min-width: 768px) {
        .sidebar-mini.sidebar-collapse .main-header .logo { padding: 0; }
        .sidebar-mini.sidebar-collapse .main-header .logo .logo-mini { display: flex !important; width: 100%; margin: 0; }
        .sidebar-mini.sidebar-collapse .main-header .logo .logo-lg { display: none !important; }
        .sidebar-mini.sidebar-collapse .main-header .logo .logo-mini img { width: 30px; height: 30px; box-shadow: 2px 2px 0 0 #000; }
    }
    .skin-blue .main-header .logo .logo-lg > span { max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .skin-blue .main-header .navbar .nav > li > a, .skin-blue .main-header .navbar .sidebar-toggle { color: var(--color); font-weight: 700; }
    .skin-blue .main-header .navbar .nav > li > a:hover, .skin-blue .main-header .navbar .sidebar-toggle:hover, .skin-blue .main-header .navbar .nav > li > a:focus { background: var(--neo-yellow); color: #000; text-decoration: none; }
    .skin-blue .main-header .navbar .sidebar-toggle .icon-bar { background: var(--neo-ink); height: 3px; }
    .skin-blue .main-header .navbar .user-image { border-radius: 0; border: 2px solid var(--neo-ink); width: 28px; height: 28px; margin: 0 8px 0 0; float: none; }
    .skin-blue .main-header .navbar { min-height: 50px; }
    .skin-blue .main-header .navbar .navbar-custom-menu, .skin-blue .main-header .navbar .navbar-custom-menu > .navbar-nav { display: flex; align-items: stretch; float: right; margin: 0; }
    .skin-blue .main-header .navbar .navbar-custom-menu > .navbar-nav > li { float: none; display: flex; }
    .skin-blue .main-header .navbar .navbar-custom-menu > .navbar-nav > li > a { display: flex; align-items: center; justify-content: center; height: 50px; padding: 0 14px; line-height: 1; border-left: 2px solid var(--neo-ink); white-space: nowrap; }
    .skin-blue .main-header .navbar .sidebar-toggle { display: flex; flex-direction: column; justify-content: center; gap: 4px; height: 50px; padding: 0 16px; float: left; border-right: 2px solid var(--neo-ink); }
    .skin-blue .main-header .navbar .sidebar-toggle .icon-bar { margin: 0; width: 20px; }
    .skin-blue .main-header .navbar .sidebar-toggle .icon-bar + .icon-bar { margin-top: 0; }

    /* Sidebar */
    .skin-blue .main-sidebar, .skin-blue .left-side { background: var(--secondary); border-right: var(--neo-border); padding-top: calc(50px + var(--neo-bw)); }
    .fixed .content-wrapper, .fixed .right-side { padding-top: calc(50px + var(--neo-bw) + 10px); }
    .skin-blue .main-sidebar { overflow-x: hidden; }
    @media (max-width: 767px) {
        .skin-blue .main-header { height: auto; }
        .skin-blue .main-header .logo { width: 100%; float: none; border-right: 0; border-bottom: var(--neo-border); }
        .skin-blue .main-header .navbar { width: 100%; float: none; margin: 0; }
        .skin-blue .main-sidebar, .skin-blue .left-side { padding-top: calc(100px + var(--neo-bw) * 2); }
        .fixed .content-wrapper, .fixed .right-side { padding-top: calc(100px + var(--neo-bw) * 2 + 10px); }
        .skin-blue .main-header .navbar .navbar-custom-menu > .navbar-nav > li > a { padding: 0 12px; }
        .content-header > h1 { display: block; }
        .nav-tabs-custom > .nav-tabs > li > a { padding: 8px 11px; }
    }
    /* Collapsed (icon-only) sidebar on desktop */
    @media (min-width: 768px) {
        .sidebar-mini.sidebar-collapse .main-sidebar .sidebar-menu > li > a { margin: 6px 4px; padding: 10px 0; text-align: center; }
        .sidebar-mini.sidebar-collapse .main-sidebar .sidebar-menu > li > a > .fa { width: auto; margin: 0; }
        .sidebar-mini.sidebar-collapse .main-sidebar .sidebar-menu > li:hover > a > span { background: var(--neo-yellow); color: #000; border: var(--neo-border); left: 54px; }
    }
    .skin-blue .sidebar-menu > li.header { background: var(--neo-ink); color: var(--background-color); font-weight: 700; letter-spacing: .12em; font-size: 11px; }
    .skin-blue .sidebar-menu > li > a { color: var(--color); border-left: 6px solid transparent; font-weight: 700; margin: 6px 10px; padding: 10px 12px 10px 12px; border: 2px solid transparent; border-radius: var(--neo-radius-sm); text-transform: uppercase; font-size: 13px; letter-spacing: .02em; }
    .skin-blue .sidebar-menu > li:hover > a { background: var(--neo-yellow); color: #000; border: 2px solid var(--neo-ink); box-shadow: var(--neo-shadow-sm); }
    .skin-blue .sidebar-menu > li.active > a { background: var(--primary); color: var(--on-primary); border: 2px solid var(--neo-ink); box-shadow: var(--neo-shadow-sm); }
    .skin-blue .sidebar-menu > li.active > a > i, .skin-blue .sidebar-menu > li:hover > a > i { color: inherit; }
    .skin-blue .sidebar-menu > li > a > .fa { width: 22px; }

    /* Cards */
    .box, .info-box, .small-box, .nav-tabs-custom, .modal-content, .well, .callout, .panel { background: var(--secondary); color: var(--color); border: var(--neo-border); border-top: var(--neo-border); border-radius: var(--neo-radius); box-shadow: var(--neo-shadow); }
    .box { margin-bottom: 26px; }
    .box-header, .box-footer, .box-header.with-border, .modal-header, .modal-footer { background: transparent; border-color: var(--neo-ink); border-bottom-width: var(--neo-bw); color: var(--highlight-color); }
    .box-footer, .modal-footer { border-top: var(--neo-border); border-bottom: 0; }
    .box-header.with-border { border-bottom: var(--neo-border); background: var(--neo-yellow); color: #000; }
    .box-header.with-border .box-title, .box-header.with-border > .fa { color: #000; }
    .box-header:first-child { border-radius: calc(var(--neo-radius) * .5) calc(var(--neo-radius) * .5) 0 0; }
    .box.box-solid > .box-header { background: var(--neo-yellow); color: #000; }
    .box-title { color: var(--highlight-color); font-weight: 700; text-transform: uppercase; letter-spacing: .03em; font-size: 15px; }
    .box.box-primary, .box.box-info, .box.box-danger, .box.box-warning, .box.box-success { border-top: var(--neo-border); }
    .box.box-danger > .box-header { background: var(--danger); color: #000; }
    .box.box-primary > .box-header { background: var(--primary); color: var(--on-primary); }
    .box.box-info > .box-header { background: var(--neo-blue); color: #000; }
    .box.box-success > .box-header { background: var(--neo-mint); color: #000; }
    .box.box-warning > .box-header { background: var(--neo-orange); color: #000; }
    .small-box { color: #000; }
    .small-box h3, .small-box p, .small-box .icon { color: #000 !important; }
    .small-box > .small-box-footer { background: var(--neo-ink); color: var(--background-color); border-top: 0; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; }
    .small-box > .small-box-footer:hover { background: var(--neo-yellow); color: #000; }
    .info-box-icon { border-right: var(--neo-border); border-radius: 0; }
    .modal-content { box-shadow: calc(var(--neo-so) + 4px) calc(var(--neo-so) + 4px) 0 0 var(--neo-ink); }

    /* Tabs: chunky sticker buttons */
    .nav-tabs-custom { margin-bottom: 26px; background: transparent; box-shadow: none; border: 0; }
    .nav-tabs-custom > .nav-tabs { border: 0; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 10px; }
    .nav-tabs-custom > .nav-tabs:before, .nav-tabs-custom > .nav-tabs:after { display: none; content: none; }
    .nav-tabs-custom > .nav-tabs > li { margin: 0; float: none; }
    .nav-tabs-custom > .nav-tabs > li > a { color: var(--color); background: var(--secondary); border: var(--neo-border) !important; border-radius: var(--neo-radius-sm); font-weight: 700; text-transform: uppercase; font-size: 12px; letter-spacing: .04em; padding: 9px 15px; margin: 0; box-shadow: var(--neo-shadow-sm); transition: transform .08s ease, box-shadow .08s ease; }
    .nav-tabs-custom > .nav-tabs > li > a:hover { background: var(--neo-yellow); color: #000; transform: translate(-1px, -1px); }
    .nav-tabs-custom > .nav-tabs > li.active > a, .nav-tabs-custom > .nav-tabs > li.active:hover > a { background: var(--primary); color: var(--on-primary); transform: translate(2px, 2px); box-shadow: 0 0 0 0 var(--neo-ink); }
    .nav-tabs-custom > .nav-tabs > li.active { border-top: 0; }
    .nav-tabs-custom > .tab-content { background: transparent; }
    .nav-tabs-custom.nav-tabs-floating { background: transparent; }

    /* Forms */
    .form-control, .select2-container--default .select2-selection--single, .select2-container--default .select2-selection--multiple, .input-group-addon { background: var(--input); color: var(--highlight-color); font-weight: 600; border: var(--neo-border) !important; border-radius: var(--neo-radius-sm); box-shadow: none; height: auto; min-height: 40px; padding: 8px 12px; }
    .input-group-addon { background: var(--neo-yellow); color: #000; font-weight: 700; }
    .form-control::placeholder { color: var(--color-5); font-weight: 500; }
    .form-control:focus, .select2-container--focus .select2-selection { box-shadow: var(--neo-shadow-sm) !important; transform: translate(-2px, -2px); outline: 0; border-color: var(--neo-ink) !important; }
    .form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control { background: var(--secondary-hover); opacity: .75; }
    input[type=color].form-control { padding: 3px; height: 46px; cursor: pointer; }
    input[type=file].form-control { padding: 8px 10px; }
    input[type=checkbox], input[type=radio] { accent-color: var(--primary); width: 16px; height: 16px; }
    .select2-container--default .select2-selection--single .select2-selection__rendered { color: var(--highlight-color); line-height: 22px; padding-left: 0; font-weight: 600; }
    .select2-dropdown { background: var(--secondary); border: var(--neo-border); border-radius: var(--neo-radius-sm); box-shadow: var(--neo-shadow-sm); }
    .select2-results__option { color: var(--color); font-weight: 600; }
    .select2-container--default .select2-results__option--highlighted[aria-selected] { background: var(--neo-yellow); color: #000; }
    label, .control-label { color: var(--highlight-color); font-weight: 700; text-transform: uppercase; font-size: 12px; letter-spacing: .05em; }
    .has-error .form-control { border-color: var(--danger) !important; }

    /* Buttons: flat colour, hard shadow, they sink when pressed */
    .btn { border: var(--neo-border) !important; border-radius: var(--neo-radius-sm); font-weight: 700; text-transform: uppercase; letter-spacing: .04em; font-size: 12px; padding: 8px 16px; box-shadow: var(--neo-shadow-btn); transition: transform .08s ease, box-shadow .08s ease, background .08s ease; text-shadow: none; color: #000; }
    .btn:hover, .btn:focus { transform: translate(-2px, -2px); box-shadow: calc(var(--neo-so) * 0.66 + 2px) calc(var(--neo-so) * 0.66 + 2px) 0 0 var(--neo-ink); text-decoration: none; }
    .btn:active, .btn.active { transform: translate(calc(var(--neo-so) * 0.66), calc(var(--neo-so) * 0.66)); box-shadow: 0 0 0 0 var(--neo-ink); }
    .btn-xs, .btn-sm { padding: 5px 12px; font-size: 11px; }
    .btn-primary { background: var(--primary); color: var(--on-primary); }
    .btn-primary:hover, .btn-primary:focus { background: var(--primary-hover); color: var(--on-primary); }
    .btn-success { background: var(--neo-mint); color: #000; }
    .btn-success:hover, .btn-success:focus { background: #2fc888; color: #000; }
    .btn-danger { background: var(--danger); color: var(--on-danger); }
    .btn-danger:hover, .btn-danger:focus { background: var(--danger-hover); color: var(--on-danger); }
    .btn-warning { background: var(--neo-yellow); color: #000; }
    .btn-warning:hover, .btn-warning:focus { background: var(--neo-orange); color: #000; }
    .btn-info { background: var(--neo-blue); color: #000; }
    .btn-info:hover, .btn-info:focus { background: #3a82ec; color: #000; }
    .btn-default { background: var(--secondary); color: var(--highlight-color); }
    .btn-default:hover, .btn-default:focus { background: var(--neo-yellow); color: #000; }
    .btn.disabled, .btn[disabled] { opacity: .55; box-shadow: none; transform: none; }

    /* Tables / labels / alerts */
    .table > thead > tr > th, .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td { border-color: var(--neo-ink) !important; border-top-width: 2px; color: var(--color); font-weight: 600; vertical-align: middle; }
    .table > thead > tr > th { color: #000; background: var(--neo-yellow); font-weight: 700; text-transform: uppercase; font-size: 12px; letter-spacing: .05em; border-bottom: var(--neo-border) !important; }
    .table-hover > tbody > tr:hover { background: var(--secondary-hover); }
    .table-striped > tbody > tr:nth-of-type(odd) { background: transparent; }
    .table-striped > tbody > tr:nth-of-type(even) { background: rgba(0, 0, 0, .035); }
    .darkmode .table-striped > tbody > tr:nth-of-type(even) { background: rgba(255, 255, 255, .04); }
    .box-body.table-responsive, .table-responsive { border: 0; }
    .label { border: 2px solid var(--neo-ink); border-radius: var(--neo-radius-sm); padding: .35em .7em; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; color: #000; box-shadow: 2px 2px 0 0 var(--neo-ink); }
    .label-default { background: var(--secondary-hover); color: var(--highlight-color); }
    .label-primary { background: var(--primary); color: var(--on-primary); }
    .label-success { background: var(--neo-mint); }
    .label-danger { background: var(--danger); }
    .label-warning { background: var(--neo-yellow); }
    .label-info { background: var(--neo-blue); }
    .bg-green, .bg-light-blue, .bg-aqua, .bg-red, .bg-yellow, .bg-purple { color: #000 !important; }
    .alert { border: var(--neo-border); border-radius: var(--neo-radius); box-shadow: var(--neo-shadow-sm); font-weight: 600; color: #000; }
    .alert-success { background: var(--neo-mint); }
    .alert-danger, .alert-error { background: var(--danger); }
    .alert-warning { background: var(--neo-yellow); }
    .alert-info { background: var(--neo-blue); }
    .alert a { color: #000; text-decoration: underline; }
    .callout { border-left-width: 10px; }
    .pagination > li > a, .pagination > li > span { background: var(--secondary); color: var(--highlight-color); border: 2px solid var(--neo-ink); border-radius: var(--neo-radius-sm); margin: 0 4px; font-weight: 700; box-shadow: 3px 3px 0 0 var(--neo-ink); }
    .pagination > li > a:hover { background: var(--neo-yellow); color: #000; }
    .pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover { background: var(--primary); color: var(--on-primary); border-color: var(--neo-ink); }
    .dropdown-menu { background: var(--secondary); border: var(--neo-border); border-radius: var(--neo-radius-sm); box-shadow: var(--neo-shadow-sm); }
    .dropdown-menu > li > a { color: var(--color); font-weight: 700; }
    .dropdown-menu > li > a:hover { background: var(--neo-yellow); color: #000; }
    .progress { background: var(--input); border: 2px solid var(--neo-ink); box-shadow: none; border-radius: var(--neo-radius-sm); height: 20px; }
    .progress-bar { border-radius: 0; background: var(--primary); }
    .progress-bar-success { background: var(--neo-mint); } .progress-bar-danger { background: var(--danger); } .progress-bar-warning { background: var(--neo-yellow); }
    code, pre { background: var(--neo-yellow); color: #000; border: 2px solid var(--neo-ink); border-radius: var(--neo-radius-sm); font-family: 'Space Mono', 'IBM Plex Mono', monospace; font-weight: 700; }
    pre { background: var(--dark); color: #f5f1e6; }
    hr { border-top: 3px solid var(--neo-ink); }
    .tooltip-inner { background: var(--neo-ink); color: var(--background-color); border-radius: 0; font-weight: 700; }
    .sweet-alert { border: var(--neo-border); border-radius: var(--neo-radius); background: var(--secondary); box-shadow: var(--neo-shadow); }
    .sweet-alert h2, .sweet-alert p { color: var(--color); font-weight: 700; }
    .sweet-alert button { border-radius: var(--neo-radius-sm) !important; border: var(--neo-border) !important; box-shadow: var(--neo-shadow-btn) !important; color: #000 !important; font-weight: 700 !important; text-transform: uppercase; }
    .sweet-alert button.confirm { background-color: var(--neo-yellow) !important; }
    .sweet-alert button.cancel { background-color: var(--secondary-hover) !important; }
    .sweet-overlay { background: rgba(0, 0, 0, .55); }
    ::selection { background: var(--neo-yellow); color: #000; }
    ::-webkit-scrollbar { width: 14px; height: 14px; background: var(--background-color); }
    ::-webkit-scrollbar-thumb { background: var(--primary); border: 3px solid var(--neo-ink); }


    /* Theme settings grid: flex wrap, equal gutters, one column on phones */
    .neo-fields { display: flex; flex-wrap: wrap; align-items: flex-start; }
    .neo-fields:before, .neo-fields:after { display: none; content: none; }
    .neo-fields > [class*="col-"] { float: none; flex: 0 0 100%; width: 100%; max-width: 100%; margin-bottom: 14px; }
    .neo-fields > .form-group { margin-bottom: 14px; }
    .neo-fields > .col-md-12 { margin-bottom: 4px; }
    .neo-fields input[type=color].form-control { width: 100%; }
    @media (min-width: 768px) {
        .neo-fields > .col-sm-6 { flex-basis: 50%; width: 50%; max-width: 50%; }
        .neo-fields > .col-md-4, .neo-fields > .col-md-6 { flex-basis: 50%; width: 50%; max-width: 50%; }
        .neo-fields > .col-md-12 { flex-basis: 100%; width: 100%; max-width: 100%; }
    }
    @media (min-width: 992px) {
        .neo-fields > .col-md-4 { flex-basis: 33.3333%; width: 33.3333%; max-width: 33.3333%; }
        .neo-fields > .col-md-5 { flex-basis: 41.6667%; width: 41.6667%; max-width: 41.6667%; }
        .neo-fields > .col-md-6 { flex-basis: 50%; width: 50%; max-width: 50%; }
        .neo-fields > .col-md-7 { flex-basis: 58.3333%; width: 58.3333%; max-width: 58.3333%; }
        .neo-fields > .col-md-8 { flex-basis: 66.6667%; width: 66.6667%; max-width: 66.6667%; }
        .neo-fields > .col-md-12 { flex-basis: 100%; width: 100%; max-width: 100%; }
    }
    .neo-sample { display: block; padding: 12px 16px; border: var(--neo-border); border-radius: var(--neo-radius-sm); box-shadow: var(--neo-shadow-btn); font-weight: 700; text-transform: uppercase; letter-spacing: .04em; text-align: center; color: #000; }
    .box-body .text-muted { margin-top: 6px; }
    .box-body > .row + .row { margin-top: 8px; }
    .box-body h4 { margin: 4px 0 10px; text-transform: uppercase; font-size: 14px; }
    .box-footer:after { content: ''; display: table; clear: both; }
    .table-responsive { overflow-x: auto; }
    @media (max-width: 767px) { .neo-presets { grid-template-columns: 1fr 1fr; gap: 14px; } .neo-tiles { grid-template-columns: 1fr; } .neo-toggle { flex-wrap: wrap; } }

    /* Logo preview used on the theme settings page */
    .neo-logo-preview { display: inline-flex; align-items: center; gap: 12px; padding: 12px 18px; border: var(--neo-border); border-radius: var(--neo-radius); background: var(--neo-yellow); box-shadow: var(--neo-shadow-sm); }
    .neo-logo-preview img { width: 44px; height: 44px; object-fit: contain; border: 2px solid #000; background: #fff; box-shadow: 3px 3px 0 0 #000; }
    .neo-logo-preview strong { color: #000; font-size: 16px; text-transform: uppercase; letter-spacing: .02em; }
    .neo-logo-preview.shape-square img { border-radius: 0; }
    .neo-logo-preview.shape-rounded img { border-radius: 10px; }
    .neo-logo-preview.shape-circle img { border-radius: 50%; }
    .neo-swatch { display: inline-block; width: 18px; height: 18px; border: 2px solid var(--neo-ink); vertical-align: -3px; margin-right: 6px; }

    /* Quick presets */
    .neo-presets { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 18px; }
    .neo-preset { display: flex; flex-direction: column; gap: 8px; padding: 14px; margin: 0; background: var(--secondary-hover); border: var(--neo-border); border-radius: var(--neo-radius); box-shadow: var(--neo-shadow-sm); }
    .neo-preset strong { color: var(--highlight-color); text-transform: uppercase; letter-spacing: .04em; }
    .neo-preset small { color: var(--color); font-weight: 600; min-height: 32px; }
    .neo-preset-swatches { display: flex; }
    .neo-preset-swatches span { flex: 1; height: 26px; border: 2px solid var(--neo-ink); margin-left: -2px; }
    .neo-preset-swatches span:first-child { margin-left: 0; }

    /* Layout tiles + toggle cards (Elements Manager) */
    .neo-tiles { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .neo-tile { position: relative; margin: 0; cursor: pointer; text-transform: none; }
    .neo-tile input { position: absolute; opacity: 0; }
    .neo-tile-face { display: flex; flex-direction: column; gap: 6px; padding: 14px; background: var(--secondary); border: var(--neo-border); border-radius: var(--neo-radius); box-shadow: var(--neo-shadow-sm); transition: transform .08s ease, box-shadow .08s ease; }
    .neo-tile-face b { color: var(--highlight-color); text-transform: uppercase; }
    .neo-tile-face small { color: var(--color); font-weight: 600; }
    .neo-tile:hover .neo-tile-face { transform: translate(-2px, -2px); }
    .neo-tile input:checked + .neo-tile-face { background: var(--neo-yellow); box-shadow: 0 0 0 0 var(--neo-ink); transform: translate(3px, 3px); }
    .neo-tile input:checked + .neo-tile-face b, .neo-tile input:checked + .neo-tile-face small { color: #000; }
    .neo-ill { display: grid; gap: 5px; height: 54px; }
    .neo-ill i { display: block; background: var(--primary); border: 2px solid var(--neo-ink); }
    .neo-ill-table { grid-template-rows: repeat(3, 1fr); }
    .neo-ill-cards { grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr; }
    .neo-toggles { display: grid; gap: 16px; }
    .neo-toggle { position: relative; display: flex; align-items: center; gap: 14px; margin: 0; padding: 12px 14px; background: var(--secondary); border: var(--neo-border); border-radius: var(--neo-radius); box-shadow: var(--neo-shadow-sm); cursor: pointer; text-transform: none; }
    .neo-toggle input[type=checkbox] { position: absolute; opacity: 0; }
    .neo-toggle-icon { display: flex; flex: 0 0 40px; height: 40px; align-items: center; justify-content: center; background: var(--neo-yellow); color: #000; border: 2px solid var(--neo-ink); font-size: 18px; }
    .neo-toggle-text { flex: 1; display: flex; flex-direction: column; }
    .neo-toggle-text b { color: var(--highlight-color); text-transform: uppercase; }
    .neo-toggle-text small { color: var(--color); font-weight: 600; }
    .neo-toggle-switch { position: relative; flex: 0 0 56px; height: 28px; background: var(--input); border: 3px solid var(--neo-ink); }
    .neo-toggle-switch::after { content: ''; position: absolute; top: 2px; left: 2px; width: 18px; height: 18px; background: var(--neo-ink); transition: left .08s ease; }
    .neo-toggle input:checked ~ .neo-toggle-switch { background: var(--neo-mint); }
    .neo-toggle input:checked ~ .neo-toggle-switch::after { left: 28px; }
    .neo-toggle input:focus-visible ~ .neo-toggle-switch { outline: 3px dashed var(--neo-ink); outline-offset: 3px; }
</style>
<script>
    // Same colour mode as the client area (toggled with the moon button there).
    document.addEventListener('DOMContentLoaded', function () {
        try { if (localStorage.getItem('modes') === 'darkMode') document.body.classList.add('darkmode'); } catch (e) {}
    });
</script>
