@section('theme::nav')
    @php
        $neoTabs = [
            'theme' => ['admin.theme', 'fa-image', 'General & Logo'],
            'color' => ['admin.theme.color', 'fa-paint-brush', 'Color Settings'],
            'meta' => ['admin.theme.meta', 'fa-tag', 'Meta Settings'],
            'button' => ['admin.theme.button', 'fa-hand-pointer-o', 'Buttons & Input'],
            'element' => ['admin.theme.element', 'fa-th-large', 'Elements Manager'],
            'alert' => ['admin.theme.alert', 'fa-bell', 'Alert Manager'],
            'social' => ['admin.theme.social', 'fa-share-alt', 'Social Manager'],
            'contact' => ['admin.theme.contact', 'fa-phone', 'Contact Settings'],
            'protection' => ['admin.theme.protection', 'fa-shield', 'Protection & Alert Toast'],
        ];
    @endphp
    <div class="row">
        <div class="col-xs-12">
            <div class="nav-tabs-custom nav-tabs-floating">
                <ul class="nav nav-tabs">
                    @foreach ($neoTabs as $tabKey => $tab)
                        <li @if($activeTab === $tabKey)class="active"@endif><a href="{{ route($tab[0]) }}"><i class="fa {{ $tab[1] }}"></i> {{ $tab[2] }}</a></li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
@endsection
