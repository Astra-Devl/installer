@php
    $neoPresets = \Pterodactyl\Services\Theme\ThemePresets::all();
    $neoCss = fn ($value) => \Pterodactyl\Services\Theme\ThemeSettings::css($value);
@endphp
<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><i class="fa fa-magic"></i> Quick Presets</h3>
    </div>
    <div class="box-body">
        <p class="text-muted" style="margin-bottom:16px;">
            One click swaps the colours, corner radius, border width and shadow size. Logo, names, links, protection and the
            element toggles stay exactly as they are. Fine-tune the result afterwards in <strong>Color Settings</strong>.
        </p>
        <div class="neo-presets">
            @foreach ($neoPresets as $presetKey => $preset)
                <form action="{{ route('admin.theme.preset.update') }}" method="POST" class="neo-preset"
                      onsubmit="return confirm('Replace the current colours with the {{ $preset['name'] }} preset?');">
                    {!! csrf_field() !!}
                    <input type="hidden" name="preset" value="{{ $presetKey }}">
                    <div class="neo-preset-swatches">
                        @foreach (\Pterodactyl\Services\Theme\ThemePresets::swatches($presetKey) as $swatch)
                            <span style="background: {{ $neoCss($swatch) }};"></span>
                        @endforeach
                    </div>
                    <strong>{{ $preset['name'] }}</strong>
                    <small>{{ $preset['note'] }}</small>
                    <button type="submit" class="btn btn-xs btn-primary">Apply</button>
                </form>
            @endforeach
        </div>
    </div>
</div>
