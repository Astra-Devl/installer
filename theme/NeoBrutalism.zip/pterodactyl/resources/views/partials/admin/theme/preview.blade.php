{{-- Live preview of the palette. It follows the colour / number inputs of the page while you type, nothing is saved until you press Save. --}}
@php
    $pvTheme = \Pterodactyl\Services\Theme\ThemeSettings::get();
    $pvCss = fn ($value) => \Pterodactyl\Services\Theme\ThemeSettings::css($value);

    $pvLight = [
        'bg' => $pvTheme->background, 'surface' => $pvTheme->secondary, 'surface2' => $pvTheme->secondaryhover,
        'input' => $pvTheme->input, 'primary' => $pvTheme->primary, 'primary-h' => $pvTheme->primaryhover,
        'text' => $pvTheme->textbutton, 'danger' => $pvTheme->dangerbutton,
        'ink-text' => $pvTheme->highlightcolor, 'text-color' => $pvTheme->color,
    ];
    $pvDark = [
        'bg' => $pvTheme->lbackground, 'surface' => $pvTheme->lsecondary, 'surface2' => $pvTheme->lsecondaryhover,
        'input' => $pvTheme->linput, 'primary' => $pvTheme->lprimary, 'primary-h' => $pvTheme->lprimaryhover,
        'text' => $pvTheme->ltextbutton, 'danger' => $pvTheme->ldangerbutton,
        'ink-text' => $pvTheme->lhighlightcolor, 'text-color' => $pvTheme->lcolor,
    ];

    $pvStyle = '';
    foreach ($pvLight as $pvKey => $pvValue) {
        $pvStyle .= '--pv-' . $pvKey . ':' . $pvCss($pvValue) . ';';
    }
    foreach ($pvDark as $pvKey => $pvValue) {
        $pvStyle .= '--pv-d-' . $pvKey . ':' . $pvCss($pvValue) . ';';
    }
    $pvStyle .= '--pv-r:' . (int) $pvTheme->borderradius . 'px;';
    $pvStyle .= '--pv-bw:' . max(1, min(6, (int) $pvTheme->borderwidth)) . 'px;';
    $pvStyle .= '--pv-so:' . max(0, min(14, (int) $pvTheme->shadowsize)) . 'px;';
@endphp
<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><i class="fa fa-eye"></i> Live Preview</h3>
        <div class="box-tools pull-right">
            <button type="button" class="btn btn-xs btn-default" data-pv-mode="light">Cream paper</button>
            <button type="button" class="btn btn-xs btn-default" data-pv-mode="dark">Night paper</button>
        </div>
    </div>
    <div class="box-body" style="padding:0;">
        <div class="neo-pv" id="neo-pv" style="{{ $pvStyle }}">
            <div class="pv-top">
                <span class="pv-logo">N</span>
                <b>My Panel</b>
                <span class="pv-spacer"></span>
                <span class="pv-chip">Dashboard</span>
                <span class="pv-chip pv-on">Servers</span>
                <span class="pv-chip">Account</span>
            </div>
            <div class="pv-grid">
                <div class="pv-card">
                    <div class="pv-stripe"></div>
                    <div class="pv-body">
                        <div class="pv-row"><b>survival-smp</b><span class="pv-pill">Online</span></div>
                        <div class="pv-label">CPU <em>42 %</em></div>
                        <div class="pv-meter"><i style="width:42%"></i></div>
                        <div class="pv-label">Memory <em>1.8 GiB</em></div>
                        <div class="pv-meter pv-m2"><i style="width:68%"></i></div>
                        <span class="pv-btn pv-primary">Manage Server</span>
                    </div>
                </div>
                <div class="pv-card">
                    <div class="pv-head">Console</div>
                    <div class="pv-term">container@pterodactyl~ Server marked as running...</div>
                    <div class="pv-body">
                        <span class="pv-field">Type a command</span>
                        <div class="pv-btns">
                            <span class="pv-btn pv-primary">Start</span>
                            <span class="pv-btn pv-text">Restart</span>
                            <span class="pv-btn pv-danger">Stop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .neo-pv { --a-bg: var(--pv-bg); --a-surface: var(--pv-surface); --a-surface2: var(--pv-surface2); --a-input: var(--pv-input); --a-primary: var(--pv-primary); --a-primary-h: var(--pv-primary-h); --a-text: var(--pv-text); --a-danger: var(--pv-danger); --a-ink-text: var(--pv-ink-text); --a-text-color: var(--pv-text-color); --a-ink: #000; --a-on-primary: #fff;
        padding: 22px; background: var(--a-bg); color: var(--a-text-color); font-family: 'Space Grotesk', sans-serif; font-weight: 600; transition: background .15s ease; }
    .neo-pv.pv-dark { --a-bg: var(--pv-d-bg); --a-surface: var(--pv-d-surface); --a-surface2: var(--pv-d-surface2); --a-input: var(--pv-d-input); --a-primary: var(--pv-d-primary); --a-primary-h: var(--pv-d-primary-h); --a-text: var(--pv-d-text); --a-danger: var(--pv-d-danger); --a-ink-text: var(--pv-d-ink-text); --a-text-color: var(--pv-d-text-color); --a-ink: #f5f1e6; --a-on-primary: #000; }
    .neo-pv * { box-sizing: border-box; }
    .neo-pv .pv-top { display: flex; align-items: center; gap: 10px; padding: 10px 14px; margin-bottom: 20px; background: var(--a-surface); border: var(--pv-bw) solid var(--a-ink); border-radius: var(--pv-r); box-shadow: var(--pv-so) var(--pv-so) 0 0 var(--a-ink); color: var(--a-ink-text); }
    .neo-pv .pv-logo { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; background: #ffd93d; color: #000; border: 2px solid var(--a-ink); font-weight: 700; }
    .neo-pv .pv-spacer { flex: 1; }
    .neo-pv .pv-chip { padding: 3px 10px; background: var(--a-surface); color: var(--a-ink-text); border: 2px solid var(--a-ink); border-radius: calc(var(--pv-r) * .6); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; }
    .neo-pv .pv-chip.pv-on { background: var(--a-primary); color: var(--a-on-primary); }
    .neo-pv .pv-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 22px; }
    .neo-pv .pv-card { background: var(--a-surface); border: var(--pv-bw) solid var(--a-ink); border-radius: var(--pv-r); box-shadow: var(--pv-so) var(--pv-so) 0 0 var(--a-ink); overflow: hidden; }
    .neo-pv .pv-stripe { height: 12px; background: #3ddc97; border-bottom: var(--pv-bw) solid var(--a-ink); }
    .neo-pv .pv-head { padding: 7px 14px; background: #ffd93d; color: #000; border-bottom: var(--pv-bw) solid var(--a-ink); font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; }
    .neo-pv .pv-body { display: flex; flex-direction: column; gap: 10px; padding: 14px; }
    .neo-pv .pv-row { display: flex; justify-content: space-between; align-items: center; color: var(--a-ink-text); font-size: 16px; }
    .neo-pv .pv-pill { padding: 1px 9px; background: #3ddc97; color: #000; border: 2px solid var(--a-ink); border-radius: calc(var(--pv-r) * .6); font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; }
    .neo-pv .pv-label { display: flex; justify-content: space-between; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .07em; }
    .neo-pv .pv-label em { font-style: normal; color: var(--a-ink-text); }
    .neo-pv .pv-meter { height: 14px; background: var(--a-input); border: 2px solid var(--a-ink); border-radius: calc(var(--pv-r) * .6); overflow: hidden; }
    .neo-pv .pv-meter > i { display: block; height: 100%; background: #ffd93d; border-right: 2px solid var(--a-ink); }
    .neo-pv .pv-meter.pv-m2 > i { background: #ff6bb5; }
    .neo-pv .pv-term { padding: 12px 14px; background: #0d0d0d; color: #d0d0d0; font-family: 'Space Mono', monospace; font-size: 11px; border-bottom: var(--pv-bw) solid var(--a-ink); }
    .neo-pv .pv-field { padding: 8px 12px; background: var(--a-input); color: var(--a-text-color); border: var(--pv-bw) solid var(--a-ink); border-radius: calc(var(--pv-r) * .6); font-size: 12px; font-family: 'Space Mono', monospace; }
    .neo-pv .pv-btns { display: flex; gap: 10px; flex-wrap: wrap; }
    .neo-pv .pv-btn { display: inline-block; padding: 7px 14px; border: var(--pv-bw) solid var(--a-ink); border-radius: calc(var(--pv-r) * .6); box-shadow: calc(var(--pv-so) * .66) calc(var(--pv-so) * .66) 0 0 var(--a-ink); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; text-align: center; color: #000; }
    .neo-pv .pv-btn.pv-primary { background: var(--a-primary); color: var(--a-on-primary); }
    .neo-pv .pv-btn.pv-text { background: var(--a-text); }
    .neo-pv .pv-btn.pv-danger { background: var(--a-danger); }
</style>
<script>
    (function () {
        var root = document.getElementById('neo-pv');
        if (!root) { return; }

        var light = { background: 'bg', secondary: 'surface', secondaryhover: 'surface2', input: 'input', primary: 'primary', primaryhover: 'primary-h', textbutton: 'text', dangerbutton: 'danger', highlightcolor: 'ink-text', color: 'text-color' };
        var dark = { lbackground: 'bg', lsecondary: 'surface', lsecondaryhover: 'surface2', linput: 'input', lprimary: 'primary', lprimaryhover: 'primary-h', ltextbutton: 'text', ldangerbutton: 'danger', lhighlightcolor: 'ink-text', lcolor: 'text-color' };
        var numbers = { borderradius: ['--pv-r', 0, 32], borderwidth: ['--pv-bw', 1, 6], shadowsize: ['--pv-so', 0, 14] };
        var hex = /^#[0-9a-f]{6}$/i;

        function clamp(value, min, max) {
            var n = parseInt(value, 10);
            if (isNaN(n)) { return min; }
            return Math.max(min, Math.min(max, n));
        }

        function apply(el) {
            var name = el && el.name;
            if (!name) { return; }

            if (Object.prototype.hasOwnProperty.call(light, name) && hex.test(el.value)) {
                root.style.setProperty('--pv-' + light[name], el.value);
            } else if (Object.prototype.hasOwnProperty.call(dark, name) && hex.test(el.value)) {
                root.style.setProperty('--pv-d-' + dark[name], el.value);
            } else if (Object.prototype.hasOwnProperty.call(numbers, name)) {
                var rule = numbers[name];
                root.style.setProperty(rule[0], clamp(el.value, rule[1], rule[2]) + 'px');
            }
        }

        document.addEventListener('input', function (event) { apply(event.target); });
        document.addEventListener('change', function (event) { apply(event.target); });

        var buttons = document.querySelectorAll('[data-pv-mode]');
        Array.prototype.forEach.call(buttons, function (button) {
            button.addEventListener('click', function () {
                root.classList.toggle('pv-dark', button.getAttribute('data-pv-mode') === 'dark');
            });
        });

        // Start in the same mode as the panel itself.
        try { if (localStorage.getItem('modes') === 'darkMode') { root.classList.add('pv-dark'); } } catch (e) {}
    })();
</script>
