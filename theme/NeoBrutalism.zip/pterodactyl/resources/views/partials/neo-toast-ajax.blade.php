{{-- Needs jQuery + sweetalert. Turns a refused scripted call (X-Neo-Blocked) into the red floating toast. --}}
<script>
    (function ($) {
        if (!$ || !window.NeoToast) return;

        var lastBlocked = null;

        $.ajaxPrefilter(function (options, original, jqXHR) {
            jqXHR.fail(function (xhr) {
                if (xhr.getResponseHeader && xhr.getResponseHeader('X-Neo-Blocked')) {
                    var data = xhr.responseJSON || {};
                    lastBlocked = data.error || null;
                    window.NeoToast.show(data.error || 'Akses ditolak.', data.toast || {});
                }
            });
        });

        // The panel pages answer a failed call with swal({ text: jqXHR.responseJSON.error }); keep that
        // pop-up away for refused calls, the red toast already told the story.
        var originalSwal = window.swal;
        if (typeof originalSwal === 'function') {
            window.swal = function (opts) {
                if (lastBlocked && opts && typeof opts === 'object' && opts.text === lastBlocked) {
                    lastBlocked = null;
                    return;
                }
                return originalSwal.apply(this, arguments);
            };
            for (var k in originalSwal) { if (Object.prototype.hasOwnProperty.call(originalSwal, k)) window.swal[k] = originalSwal[k]; }
        }
    })(window.jQuery);
</script>
