{{--
    Floating NeoBrutalism notification (red by default). Used by the protection middleware instead of a
    403 / 500 page. The colours, position and duration come from Admin > Theme > Protection.
    JS API:  NeoToast.show('message', { title, color, textColor, position, duration })
--}}
@php($neoToastCfg = \Pterodactyl\Services\Theme\ThemeSettings::toast())
<style>
    #neo-toast-root { position: fixed; z-index: 100000; display: flex; flex-direction: column; gap: 14px; width: min(420px, calc(100vw - 28px)); pointer-events: none; }
    #neo-toast-root.top-right { top: 18px; right: 18px; align-items: flex-end; }
    #neo-toast-root.top-left { top: 18px; left: 18px; align-items: flex-start; }
    #neo-toast-root.top-center { top: 18px; left: 50%; transform: translateX(-50%); align-items: center; }
    #neo-toast-root.bottom-right { bottom: 18px; right: 18px; align-items: flex-end; flex-direction: column-reverse; }
    #neo-toast-root.bottom-left { bottom: 18px; left: 18px; align-items: flex-start; flex-direction: column-reverse; }
    #neo-toast-root.bottom-center { bottom: 18px; left: 50%; transform: translateX(-50%); align-items: center; flex-direction: column-reverse; }

    .neo-toast { pointer-events: auto; position: relative; display: flex; align-items: stretch; width: 100%; overflow: hidden; box-sizing: border-box;
        background: var(--neo-toast-bg, #ff3b30); color: var(--neo-toast-fg, #fff);
        border: var(--neo-bw, 3px) solid var(--neo-ink, #000); border-radius: var(--neo-radius, 4px);
        box-shadow: calc(var(--neo-so, 6px) + 2px) calc(var(--neo-so, 6px) + 2px) 0 0 var(--neo-ink, #000);
        font-family: 'Space Grotesk', 'Segoe UI', system-ui, sans-serif; animation: neo-toast-in .38s cubic-bezier(.2, 1.4, .4, 1) both, neo-toast-shake .45s .38s ease both; }
    .neo-toast.is-leaving { animation: neo-toast-out .22s ease forwards; }
    .neo-toast__icon { flex: 0 0 52px; display: flex; align-items: center; justify-content: center; background: var(--neo-ink, #000); color: var(--neo-toast-bg, #ff3b30); font-size: 30px; font-weight: 800; line-height: 1; }
    .neo-toast__icon svg { width: 28px; height: 28px; display: block; }
    .neo-toast__body { flex: 1 1 auto; padding: 12px 14px 15px; min-width: 0; }
    .neo-toast__title { margin: 0 0 3px; font-size: 13px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; color: inherit; }
    .neo-toast__msg { margin: 0; font-size: 14px; font-weight: 600; line-height: 1.35; color: inherit; word-wrap: break-word; }
    .neo-toast__close { flex: 0 0 auto; align-self: flex-start; margin: 8px 8px 0 0; width: 26px; height: 26px; padding: 0; cursor: pointer; font: 800 15px/1 'Space Grotesk', sans-serif;
        background: var(--neo-ink, #000); color: var(--neo-toast-bg, #ff3b30); border: 2px solid var(--neo-ink, #000); border-radius: 0; }
    .neo-toast__close:hover { background: var(--neo-toast-fg, #fff); color: var(--neo-ink, #000); }
    .neo-toast__bar { position: absolute; left: 0; bottom: 0; height: 6px; width: 100%; background: var(--neo-ink, #000); transform-origin: left center; }
    @keyframes neo-toast-in { from { opacity: 0; transform: translateY(-26px) scale(.92) rotate(-1.5deg); } to { opacity: 1; transform: none; } }
    @keyframes neo-toast-out { to { opacity: 0; transform: translateX(26px) scale(.96); } }
    @keyframes neo-toast-shake { 0%, 100% { translate: 0 0; } 20% { translate: -6px 0; } 40% { translate: 6px 0; } 60% { translate: -4px 0; } 80% { translate: 3px 0; } }
    @keyframes neo-toast-bar { from { transform: scaleX(1); } to { transform: scaleX(0); } }
    @media (prefers-reduced-motion: reduce) { .neo-toast { animation: none !important; } .neo-toast__bar { animation: none !important; } }
</style>
<script>
    (function () {
        var defaults = {!! json_encode($neoToastCfg) !!};
        var ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="square"><path d="M12 3 2.5 20h19L12 3z"/><path d="M12 10v5M12 17.6v.1"/></svg>';

        function root(position) {
            var el = document.getElementById('neo-toast-root');
            if (!el) {
                el = document.createElement('div');
                el.id = 'neo-toast-root';
                el.setAttribute('aria-live', 'assertive');
                document.body.appendChild(el);
            }
            el.className = position;
            return el;
        }

        function esc(text) {
            var d = document.createElement('div');
            d.textContent = text == null ? '' : String(text);
            return d.innerHTML;
        }

        function show(message, options) {
            var o = {};
            Object.keys(defaults).forEach(function (k) { o[k] = defaults[k]; });
            Object.keys(options || {}).forEach(function (k) { if (options[k] !== undefined && options[k] !== null && options[k] !== '') o[k] = options[k]; });

            var toast = document.createElement('div');
            toast.className = 'neo-toast';
            toast.setAttribute('role', 'alert');
            toast.style.setProperty('--neo-toast-bg', o.color);
            toast.style.setProperty('--neo-toast-fg', o.textColor);
            toast.innerHTML = '<div class="neo-toast__icon">' + ICON + '</div>' +
                '<div class="neo-toast__body"><p class="neo-toast__title">' + esc(o.title) + '</p><p class="neo-toast__msg">' + esc(message) + '</p></div>' +
                '<button type="button" class="neo-toast__close" aria-label="Close">&times;</button>';

            var duration = parseInt(o.duration, 10) || 0;
            var timer = null;
            if (duration > 0) {
                var bar = document.createElement('div');
                bar.className = 'neo-toast__bar';
                bar.style.animation = 'neo-toast-bar ' + duration + 's linear forwards';
                toast.appendChild(bar);
            }

            function close() {
                if (timer) { clearTimeout(timer); timer = null; }
                if (!toast.parentNode) return;
                toast.classList.add('is-leaving');
                setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 230);
            }

            toast.querySelector('.neo-toast__close').addEventListener('click', close);
            if (duration > 0) {
                timer = setTimeout(close, duration * 1000);
                toast.addEventListener('mouseenter', function () { if (timer) { clearTimeout(timer); timer = null; } var b = toast.querySelector('.neo-toast__bar'); if (b) b.style.animationPlayState = 'paused'; });
                toast.addEventListener('mouseleave', function () { var b = toast.querySelector('.neo-toast__bar'); if (b) b.style.animationPlayState = 'running'; if (!timer) timer = setTimeout(close, 1800); });
            }

            root(o.position).appendChild(toast);
            return { close: close };
        }

        window.NeoToast = { show: show, defaults: defaults };

        @if (session()->has('neo_toast'))
            var flashed = {!! json_encode(session('neo_toast')) !!};
            var run = function () { show(flashed.message); };
            if (document.body) { run(); } else { document.addEventListener('DOMContentLoaded', run); }
        @endif
    })();
</script>
