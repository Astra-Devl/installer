@php
    $NeoTheme = \Pterodactyl\Services\Theme\ThemeSettings::class;
    $t = $NeoTheme::get();
    $c = fn ($value) => $NeoTheme::css($value);
    $bg = trim((string) $t->backgroundimage);
    $toast = $NeoTheme::toast();
    $logoRadius = ['square' => '0', 'rounded' => '12px', 'circle' => '50%'][$t->logoshape ?? 'square'] ?? '0';
@endphp
<style>
    :root {
        --highlight-color: {{ $c($t->highlightcolor) }};
        --light-color: {{ $c($t->lightcolor) }};
        --color: {{ $c($t->color) }};
        --sub-color: {{ $c($t->subcolor) }};
        --color-4: {{ $c($t->color4) }};
        --color-5: {{ $c($t->color5) }};
        --color-6: {{ $c($t->color6) }};
        --dark: {{ $c($t->dark) }};
        --background-color: {{ $c($t->background) }};
        --input: {{ $c($t->input) }};
        --primary: {{ $c($t->primary) }};
        --secondary: {{ $c($t->secondary) }};
        --primary-hover: {{ $c($t->primaryhover) }};
        --secondary-hover: {{ $c($t->secondaryhover) }};
        --danger: {{ $c($t->dangerbutton) }};
        --danger-hover: {{ $c($t->dangerbuttonhover) }};
        --text: {{ $c($t->textbutton) }};
        --text-hover: {{ $c($t->textbuttonhover) }};
        --black: #000000;
        --white: #ffffff;
        --borderradius: {{ (int) $t->borderradius }}px;

        /* Text that sits on top of the coloured buttons */
        --on-primary: #ffffff;
        --on-danger: #000000;
        --on-text: #000000;

        /* NeoBrutalism tokens (default mode): thick ink borders and hard, un-blurred shadows */
        --neo-ink: #000000;
        --neo-bw: {{ max(1, min(6, (int) $t->borderwidth)) }}px;
        --neo-so: {{ max(0, min(14, (int) $t->shadowsize)) }}px;
        --neo-border: var(--neo-bw) solid var(--neo-ink);
        --neo-radius: var(--borderradius);
        --neo-radius-sm: calc(var(--borderradius) * 0.6);
        --neo-shadow: var(--neo-so) var(--neo-so) 0 0 var(--neo-ink);
        --neo-shadow-sm: calc(var(--neo-so) * 0.6) calc(var(--neo-so) * 0.6) 0 0 var(--neo-ink);
        --neo-shadow-btn: calc(var(--neo-so) * 0.66) calc(var(--neo-so) * 0.66) 0 0 var(--neo-ink);
        --neo-inset: inset 3px 3px 0 0 rgba(0, 0, 0, .14);
        --neo-dot: rgba(0, 0, 0, .13);
        --neo-logo-radius: {{ $logoRadius }};
        --neo-yellow: #ffd93d;
        --neo-pink: #ff6bb5;
        --neo-mint: #3ddc97;
        --neo-blue: #4d96ff;
        --neo-orange: #ff9f1c;

        /* Floating warning notification (Admin > Theme > Protection) */
        --neo-toast-bg: {{ $toast['color'] }};
        --neo-toast-fg: {{ $toast['textColor'] }};

        --sidegraph: {{ empty($t->sidegraph) ? 'none' : 'block' }};
        --subnavigation: {{ empty($t->subnavigation) ? 'none' : 'block' }};
        --infoelement: {{ empty($t->infoelement) ? 'none' : 'block' }};
        --graphcard: {{ empty($t->graphcard) ? 'none' : 'block' }};

        --website: {{ in_array($t->website, ['none', ''], true) ? 'none' : 'flex' }};
        --status: {{ in_array($t->status, ['none', ''], true) ? 'none' : 'flex' }};
        --billing: {{ in_array($t->billing, ['none', ''], true) ? 'none' : 'flex' }};
        --discord: {{ in_array($t->discord, ['none', ''], true) ? 'none' : 'flex' }};
        --knowledgebase: {{ in_array($t->knowledgebase, ['none', ''], true) ? 'none' : 'flex' }};
    }

    /* Mode toggled with the moon button: night paper, light ink */
    .darkmode {
        --highlight-color: {{ $c($t->lhighlightcolor) }};
        --light-color: {{ $c($t->llightcolor) }};
        --color: {{ $c($t->lcolor) }};
        --sub-color: {{ $c($t->lsubcolor) }};
        --color-4: {{ $c($t->lcolor4) }};
        --color-5: {{ $c($t->lcolor5) }};
        --color-6: {{ $c($t->lcolor6) }};
        --dark: {{ $c($t->ldark) }};
        --background-color: {{ $c($t->lbackground) }};
        --input: {{ $c($t->linput) }};
        --primary: {{ $c($t->lprimary) }};
        --secondary: {{ $c($t->lsecondary) }};
        --primary-hover: {{ $c($t->lprimaryhover) }};
        --secondary-hover: {{ $c($t->lsecondaryhover) }};
        --danger: {{ $c($t->ldangerbutton) }};
        --danger-hover: {{ $c($t->ldangerbuttonhover) }};
        --text: {{ $c($t->ltextbutton) }};
        --text-hover: {{ $c($t->ltextbuttonhover) }};
        --black: #ffffff;
        --white: #ffffff;

        --on-primary: #000000;
        --on-danger: #000000;
        --on-text: #000000;

        --neo-ink: #f5f1e6;
        --neo-inset: inset 3px 3px 0 0 rgba(255, 255, 255, .12);
        --neo-dot: rgba(255, 255, 255, .09);
    }

    body {
        background-color: var(--background-color);
        @if ($bg !== '')
        background-image: url("{{ $NeoTheme::url($bg) }}");
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        @else
        background-image: radial-gradient(var(--neo-dot) 1.6px, transparent 1.6px);
        background-size: 22px 22px;
        background-attachment: fixed;
        @endif
    }
</style>
