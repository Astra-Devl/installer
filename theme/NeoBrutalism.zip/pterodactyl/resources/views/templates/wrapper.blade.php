@php
    $NeoTheme = \Pterodactyl\Services\Theme\ThemeSettings::class;
    $neo = $NeoTheme::get();
    $neoName = $NeoTheme::siteName();
    $neoLogo = $NeoTheme::logo();
@endphp
<!DOCTYPE html>
<html>
    <head>
        <title>{{ $neoName }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">

            <meta property="og:type" content="website" />
            <meta property="og:image" content="{{ $neoLogo }}" />
            <meta property="og:description" content="{{ $neo->discription }}" />
            <meta property="twitter:title" content="{{ $neo->title }}" />
            <meta name="theme-color" content="{{ $NeoTheme::css($neo->metacolor) }}">

            <link rel="icon" href="{{ $neoLogo }}">
            <link rel="shortcut icon" href="{{ $neoLogo }}">
            <link rel="apple-touch-icon" href="{{ $neoLogo }}">
            <link rel="manifest" href="/favicons/manifest.json">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        @show

        @include('partials.theme-variables')

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        {{-- Public theme settings (logo, brand name, contact buttons). Available on the login page too. --}}
        <script>
            window.ThemeConfiguration = {{ \Illuminate\Support\Js::from($NeoTheme::publicConfig()) }};
        </script>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Space+Mono:wght@400;700&family=IBM+Plex+Mono&display=swap" rel="stylesheet">

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @include('partials.neo-toast')
        <script>
            // Apply the saved colour mode before the first paint to avoid a flash.
            try { if (localStorage.getItem('modes') === 'darkMode') document.body.classList.add('darkmode'); } catch (e) {}
        </script>
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        {{-- Safety net: if the app fails to draw anything, show why instead of an empty background. --}}
        <script>
            (function () {
                var errors = [];
                window.addEventListener('error', function (e) {
                    errors.push((e.message || 'Error') + (e.filename ? ' (' + String(e.filename).split('/').pop() + ':' + e.lineno + ')' : ''));
                });
                window.addEventListener('unhandledrejection', function (e) {
                    errors.push('Promise: ' + ((e.reason && e.reason.message) || e.reason));
                });
                window.addEventListener('load', function () {
                    setTimeout(function () {
                        var root = document.getElementById('app');
                        if (!root || root.children.length > 0) return;
                        var box = document.createElement('div');
                        box.style.cssText = 'position:fixed;z-index:99999;left:50%;top:50%;transform:translate(-50%,-50%);width:min(520px,calc(100vw - 28px));padding:18px;background:#fff;color:#000;border:3px solid #000;box-shadow:8px 8px 0 #000;font:600 14px/1.4 "Space Grotesk",system-ui,sans-serif';
                        var h = document.createElement('div');
                        h.style.cssText = 'font-weight:800;text-transform:uppercase;margin-bottom:8px';
                        h.textContent = 'Dashboard gagal ditampilkan';
                        var pre = document.createElement('pre');
                        pre.style.cssText = 'white-space:pre-wrap;word-break:break-word;max-height:180px;overflow:auto;margin:8px 0;padding:8px;background:#ffd93d;border:2px solid #000;font:12px/1.4 monospace';
                        pre.textContent = errors.length ? errors.slice(0, 5).join('\n') : 'Tidak ada error JavaScript tercatat. Cek apakah main.js termuat (tab Network).';
                        var btn = document.createElement('button');
                        btn.type = 'button';
                        btn.style.cssText = 'padding:8px 14px;background:#6c4dff;color:#fff;border:3px solid #000;box-shadow:3px 3px 0 #000;font:800 13px sans-serif;text-transform:uppercase;cursor:pointer';
                        btn.textContent = 'Reset tampilan & muat ulang';
                        btn.onclick = function () {
                            try { localStorage.removeItem('collapse'); localStorage.removeItem('modes'); } catch (e) {}
                            location.reload();
                        };
                        box.appendChild(h); box.appendChild(pre); box.appendChild(btn);
                        document.body.appendChild(box);
                    }, 2500);
                });
            })();
        </script>
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
