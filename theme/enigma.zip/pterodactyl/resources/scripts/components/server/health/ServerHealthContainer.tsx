import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCheckCircle,
    faClock,
    faExclamationTriangle,
    faHdd,
    faHeartbeat,
    faInfoCircle,
    faMemory,
    faMicrochip,
    faNetworkWired,
    faPlug,
    faPowerOff,
    faServer,
    faTimesCircle,
    faTools,
} from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import getServerResourceUsage from '@/api/server/getServerResourceUsage';
import { bytesToString, mbToBytes } from '@/lib/formatters';

type Level = 'ok' | 'warn' | 'crit' | 'info';

interface RawStats {
    memory_bytes?: number;
    cpu_absolute?: number;
    disk_bytes?: number;
    uptime?: number;
    network?: { rx_bytes?: number; tx_bytes?: number };
}

interface Latest {
    cpu: number;
    memory: number;
    disk: number;
    rx: number;
    tx: number;
    rxRate: number;
    txRate: number;
    uptime: number;
    hasData: boolean;
}

interface Point {
    cpu: number;
    memory: number;
    disk: number;
    net: number;
}

interface Check {
    key: string;
    icon: IconDefinition;
    label: string;
    level: Level;
    detail: string;
}

const MAX_POINTS = 60;
const WARN_AT = 0.8;
const CRIT_AT = 0.9;

const EMPTY: Latest = { cpu: 0, memory: 0, disk: 0, rx: 0, tx: 0, rxRate: 0, txRate: 0, uptime: 0, hasData: false };

const levelIcon: Record<Level, IconDefinition> = {
    ok: faCheckCircle,
    warn: faExclamationTriangle,
    crit: faTimesCircle,
    info: faInfoCircle,
};

const ratioOf = (value: number, limit: number): number | null => (limit > 0 ? value / limit : null);

const levelOf = (ratio: number | null): Level =>
    ratio === null ? 'info' : ratio >= CRIT_AT ? 'crit' : ratio >= WARN_AT ? 'warn' : 'ok';

const percent = (ratio: number | null): string => (ratio === null ? 'n/a' : `${(ratio * 100).toFixed(1)}%`);

const formatUptime = (ms: number): string => {
    const total = Math.max(0, Math.floor(ms / 1000));
    const d = Math.floor(total / 86400);
    const h = Math.floor((total % 86400) / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;

    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    return `${m}m ${s}s`;
};

const Sparkline = ({ values, max }: { values: number[]; max?: number }) => {
    if (values.length < 2) {
        return <svg className={'healthSpark'} viewBox={'0 0 100 30'} preserveAspectRatio={'none'} />;
    }

    const top = Math.max(max && max > 0 ? max : 0, ...values, 1);
    const points = values
        .map((v, i) => `${((i / (values.length - 1)) * 100).toFixed(2)},${(29 - (v / top) * 28).toFixed(2)}`)
        .join(' ');

    return (
        <svg className={'healthSpark'} viewBox={'0 0 100 30'} preserveAspectRatio={'none'}>
            <polyline points={points} />
        </svg>
    );
};

const MetricCard = ({
    icon,
    title,
    value,
    limit,
    ratio,
    values,
    max,
}: {
    icon: IconDefinition;
    title: string;
    value: string;
    limit: string;
    ratio: number | null;
    values: number[];
    max?: number;
}) => (
    <div className={'healthCard'}>
        <h3>
            <FontAwesomeIcon icon={icon} />
            {title}
        </h3>
        <p className={'healthValue'}>
            {value}
            <small>/ {limit}</small>
        </p>
        <div className={`healthBar healthLevel-${levelOf(ratio)}`}>
            <div style={{ width: `${Math.min(100, (ratio ?? 0) * 100)}%` }} />
        </div>
        <Sparkline values={values} max={max} />
    </div>
);

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const serverStatus = ServerContext.useStoreState((state) => state.server.data!.status);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);
    const power = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);

    const [latest, setLatest] = useState<Latest>(EMPTY);
    const [history, setHistory] = useState<Point[]>([]);
    const prevNet = useRef<{ t: number; rx: number; tx: number } | null>(null);

    // Minta statistik langsung begitu websocket tersambung.
    useEffect(() => {
        if (!connected || !instance) return;

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let raw: RawStats;
        try {
            raw = JSON.parse(data);
        } catch (e) {
            return;
        }

        const now = Date.now();
        const rx = raw.network?.rx_bytes ?? 0;
        const tx = raw.network?.tx_bytes ?? 0;

        let rxRate = 0;
        let txRate = 0;
        const prev = prevNet.current;
        if (prev && now > prev.t) {
            const seconds = (now - prev.t) / 1000;
            // Counter bisa reset saat server restart, jadi jangan pernah negatif.
            rxRate = Math.max(0, (rx - prev.rx) / seconds);
            txRate = Math.max(0, (tx - prev.tx) / seconds);
        }
        prevNet.current = { t: now, rx, tx };

        const next: Latest = {
            cpu: raw.cpu_absolute ?? 0,
            memory: raw.memory_bytes ?? 0,
            disk: raw.disk_bytes ?? 0,
            rx,
            tx,
            rxRate,
            txRate,
            uptime: raw.uptime ?? 0,
            hasData: true,
        };

        setLatest(next);
        setHistory((h) =>
            [...h, { cpu: next.cpu, memory: next.memory, disk: next.disk, net: rxRate + txRate }].slice(-MAX_POINTS)
        );
    });

    // Cadangan: kalau websocket belum/tidak tersambung, ambil data lewat REST.
    useEffect(() => {
        if (connected) return;

        let cancelled = false;
        const load = () =>
            getServerResourceUsage(uuid)
                .then((d) => {
                    if (cancelled) return;
                    setLatest((l) => ({
                        ...l,
                        cpu: d.cpuUsagePercent,
                        memory: d.memoryUsageInBytes,
                        disk: d.diskUsageInBytes,
                        hasData: true,
                    }));
                })
                .catch((error) => console.error(error));

        load();
        const timer = setInterval(load, 15000);

        return () => {
            cancelled = true;
            clearInterval(timer);
        };
    }, [connected, uuid]);

    const memoryLimit = limits.memory > 0 ? mbToBytes(limits.memory) : 0;
    const diskLimit = limits.disk > 0 ? mbToBytes(limits.disk) : 0;

    const cpuRatio = ratioOf(latest.cpu, limits.cpu);
    const memoryRatio = ratioOf(latest.memory, memoryLimit);
    const diskRatio = ratioOf(latest.disk, diskLimit);

    const isOffline = power === 'offline';

    const checks = useMemo<Check[]>(() => {
        const list: Check[] = [];

        list.push({
            key: 'connection',
            icon: faPlug,
            label: 'Live connection',
            level: connected ? 'ok' : 'warn',
            detail: connected ? 'Connected' : 'Reconnecting, showing last known data',
        });

        list.push({
            key: 'power',
            icon: faPowerOff,
            label: 'Power state',
            level: power === null ? 'info' : power === 'running' ? 'ok' : power === 'offline' ? 'info' : 'warn',
            detail: power === null ? 'Connecting' : power.charAt(0).toUpperCase() + power.slice(1),
        });

        list.push({
            key: 'node',
            icon: faTools,
            label: 'Node',
            level: isNodeUnderMaintenance ? 'crit' : 'ok',
            detail: isNodeUnderMaintenance ? 'Under maintenance' : 'Operational',
        });

        const stateLevel: Level =
            serverStatus === 'suspended' || serverStatus === 'install_failed' || serverStatus === 'reinstall_failed'
                ? 'crit'
                : serverStatus === 'installing' || serverStatus === 'restoring_backup' || isTransferring
                ? 'warn'
                : 'ok';
        list.push({
            key: 'state',
            icon: faServer,
            label: 'Server state',
            level: stateLevel,
            detail: isTransferring
                ? 'Transferring'
                : serverStatus
                ? serverStatus.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase())
                : 'Ready',
        });

        const usage: Array<[string, string, IconDefinition, number | null, boolean]> = [
            ['cpu', 'CPU usage', faMicrochip, cpuRatio, true],
            ['memory', 'Memory usage', faMemory, memoryRatio, true],
            ['disk', 'Disk usage', faHdd, diskRatio, false],
        ];
        usage.forEach(([key, label, icon, ratio, needsPower]) => {
            // CPU dan RAM selalu 0 saat offline, jadi tidak dinilai.
            const skipped = !latest.hasData || (needsPower && isOffline);
            list.push({
                key,
                icon,
                label,
                level: skipped ? 'info' : levelOf(ratio),
                detail: !latest.hasData ? 'Waiting for data' : skipped ? 'Offline' : percent(ratio),
            });
        });

        return list;
    }, [
        connected,
        power,
        isNodeUnderMaintenance,
        serverStatus,
        isTransferring,
        cpuRatio,
        memoryRatio,
        diskRatio,
        latest.hasData,
        isOffline,
    ]);

    const overall: Level = checks.some((c) => c.level === 'crit')
        ? 'crit'
        : checks.some((c) => c.level === 'warn')
        ? 'warn'
        : 'ok';

    // Skor 100 berkurang saat penggunaan resource melewati 70% dari limit (maks. 33 poin per resource).
    const score = useMemo<number | null>(() => {
        if (!latest.hasData || isOffline) return null;

        const penalty = (ratio: number | null) =>
            ratio === null ? 0 : Math.min(1, Math.max(0, (ratio - 0.7) / 0.3)) * 33.3;
        let value = 100 - penalty(cpuRatio) - penalty(memoryRatio) - penalty(diskRatio);
        if (isNodeUnderMaintenance) value = Math.min(value, 40);

        return Math.max(0, Math.round(value));
    }, [latest.hasData, isOffline, cpuRatio, memoryRatio, diskRatio, isNodeUnderMaintenance]);

    const label = !latest.hasData
        ? 'Waiting for data'
        : isOffline && overall === 'ok'
        ? 'Offline'
        : overall === 'crit'
        ? 'Critical'
        : overall === 'warn'
        ? 'Needs attention'
        : 'Healthy';

    const problems = checks.filter((c) => c.level === 'crit' || c.level === 'warn');
    const summary = !latest.hasData
        ? 'Collecting the first statistics...'
        : problems.length > 0
        ? problems.map((c) => `${c.label}: ${c.detail}`).join(' · ')
        : isOffline
        ? 'The server is offline. Start it to see live health.'
        : 'All checks passed.';

    const ringLevel: Level = score === null ? 'info' : overall;
    const circumference = 2 * Math.PI * 52;
    const offset = circumference * (1 - (score ?? 0) / 100);

    return (
        <ServerContentBlock title={'Server Health'}>
            <div className={'healthTop'}>
                <div className={'healthCard healthScoreCard'}>
                    <div className={`healthRing healthLevel-${ringLevel}`}>
                        <svg viewBox={'0 0 120 120'}>
                            <circle className={'healthRingTrack'} cx={60} cy={60} r={52} />
                            <circle
                                className={'healthRingValueStroke'}
                                cx={60}
                                cy={60}
                                r={52}
                                strokeDasharray={circumference}
                                strokeDashoffset={offset}
                            />
                        </svg>
                        <div className={'healthRingValue'}>
                            <strong>{score === null ? '--' : score}</strong>
                            <span>Health score</span>
                        </div>
                    </div>
                    <p className={'healthLabel'}>
                        <FontAwesomeIcon icon={faHeartbeat} className={'mr-2'} />
                        {label}
                    </p>
                    <p className={'healthSummary'}>{summary}</p>
                </div>
                <div className={'healthCard healthChecks'}>
                    <h3>
                        <FontAwesomeIcon icon={faHeartbeat} />
                        Health checks
                    </h3>
                    <ul>
                        {checks.map((check) => (
                            <li key={check.key} className={`healthCheck healthLevel-${check.level}`}>
                                <div>
                                    <FontAwesomeIcon icon={levelIcon[check.level]} />
                                    <span>{check.label}</span>
                                </div>
                                <small>{check.detail}</small>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
            <div className={'healthGrid'}>
                <MetricCard
                    icon={faMicrochip}
                    title={'CPU'}
                    value={isOffline ? 'Offline' : `${latest.cpu.toFixed(2)}%`}
                    limit={limits.cpu > 0 ? `${limits.cpu}%` : 'Unlimited'}
                    ratio={isOffline ? null : cpuRatio}
                    values={history.map((p) => p.cpu)}
                    max={limits.cpu}
                />
                <MetricCard
                    icon={faMemory}
                    title={'Memory'}
                    value={isOffline ? 'Offline' : bytesToString(latest.memory)}
                    limit={memoryLimit > 0 ? bytesToString(memoryLimit) : 'Unlimited'}
                    ratio={isOffline ? null : memoryRatio}
                    values={history.map((p) => p.memory)}
                    max={memoryLimit}
                />
                <MetricCard
                    icon={faHdd}
                    title={'Disk'}
                    value={bytesToString(latest.disk)}
                    limit={diskLimit > 0 ? bytesToString(diskLimit) : 'Unlimited'}
                    ratio={diskRatio}
                    values={history.map((p) => p.disk)}
                    max={diskLimit}
                />
                <div className={'healthCard'}>
                    <h3>
                        <FontAwesomeIcon icon={faNetworkWired} />
                        Network
                    </h3>
                    <p className={'healthValue'}>
                        {isOffline ? 'Offline' : `${bytesToString(latest.rxRate)}/s`}
                        <small>in</small>
                    </p>
                    <p className={'healthMuted'}>
                        {isOffline ? '' : `Out ${bytesToString(latest.txRate)}/s · `}
                        Total in {bytesToString(latest.rx)} · out {bytesToString(latest.tx)}
                    </p>
                    <Sparkline values={history.map((p) => p.net)} />
                </div>
                <div className={'healthCard'}>
                    <h3>
                        <FontAwesomeIcon icon={faClock} />
                        Uptime
                    </h3>
                    <p className={'healthValue'}>{isOffline || !latest.uptime ? '--' : formatUptime(latest.uptime)}</p>
                    <p className={'healthMuted'}>
                        {isOffline ? 'Server is offline' : 'Since the last start of this server'}
                    </p>
                </div>
            </div>
        </ServerContentBlock>
    );
};
