#!/usr/bin/env node
// Patch idempoten untuk file inti Pterodactyl. File inti TIDAK ditimpa, hanya disisipi baris
// yang dibutuhkan tema, supaya tetap cocok dengan versi panel yang kamu pakai.
import fs from 'node:fs';
import path from 'node:path';

const panel = path.resolve(process.argv[2] || '.');
let failed = 0;

const patch = (rel, label, fn) => {
    const file = path.join(panel, rel);
    if (!fs.existsSync(file)) {
        console.error(`  [GAGAL] ${rel} tidak ditemukan`);
        failed++;
        return;
    }
    const before = fs.readFileSync(file, 'utf8');
    const after = fn(before);
    if (after === null) {
        console.error(`  [GAGAL] ${label}: pola tidak ditemukan di ${rel} (patch manual, lihat README)`);
        failed++;
    } else if (after === before) {
        console.log(`  [SKIP ] ${label}: sudah terpasang`);
    } else {
        fs.writeFileSync(file, after);
        console.log(`  [OK   ] ${label}`);
    }
};

// 1) routes.ts: tambah halaman Server Health setelah route Console.
patch('resources/scripts/routers/routes.ts', 'route Server Health', (s) => {
    if (s.includes('ServerHealthContainer')) return s;
    const consoleRoute = /(component:\s*ServerConsole,\s*\n\s*exact:\s*true,\s*\n\s*\},\n)/;
    if (!consoleRoute.test(s)) return null;
    const imports = [...s.matchAll(/^import .*;$/gm)];
    if (!imports.length) return null;
    const last = imports[imports.length - 1];
    const importLine = "\nimport ServerHealthContainer from '@/components/server/health/ServerHealthContainer';";
    let out = s.slice(0, last.index + last[0].length) + importLine + s.slice(last.index + last[0].length);
    out = out.replace(
        consoleRoute,
        `$1        {\n            path: '/health',\n            permission: null,\n            name: 'Health',\n            component: ServerHealthContainer,\n            exact: true,\n        },\n`
    );
    return out;
});

// 2) getServer.ts: tambah nestId (dipakai ikon Minecraft di ServerRouter).
patch('resources/scripts/api/server/getServer.ts', 'nestId di getServer.ts', (s) => {
    if (s.includes('nestId')) return s;
    if (!/internalId: number \| string;/.test(s) || !/internalId: data\.internal_id,/.test(s)) return null;
    return s
        .replace(/(internalId: number \| string;\n)/, '$1    nestId: number | string;\n')
        .replace(/(internalId: data\.internal_id,\n)/, '$1    nestId: data.nest_id,\n');
});

// 3) ServerTransformer.php: kirim nest_id ke frontend.
patch('app/Transformers/Api/Client/ServerTransformer.php', 'nest_id di ServerTransformer', (s) => {
    if (s.includes("'nest_id'")) return s;
    if (!/'internal_id' => \$server->id,\n/.test(s)) return null;
    return s.replace(/('internal_id' => \$server->id,\n)(\s*)/, "$1$2'nest_id' => \$server->nest_id,\n$2");
});

// 4) tailwind.config.js: palet gray Enigma (CSS variable).
const GRAY = `const gray = {
    50: 'hsl(216, 33%, 97%)',
    100: 'hsl(214, 15%, 91%)',
    200: '#eee',
    300: '#eee',
    400: '#777',
    500: '#eee',
    600: 'var(--700)',
    700: 'var(--700)',
    800: 'var(--800)',
    900: 'var(--900)',
};`;
patch('tailwind.config.js', 'palet gray Enigma', (s) => {
    if (s.includes("'var(--700)'")) return s;
    const blocks = [...s.matchAll(/^const gray = \{[\s\S]*?^\};/gm)];
    if (!blocks.length) return null;
    const b = blocks[blocks.length - 1];
    return s.slice(0, b.index) + GRAY + s.slice(b.index + b[0].length);
});

process.exit(failed ? 1 : 0);
