#!/usr/bin/env node
// Cek semua import '@/...' dan '@feature/...' di panel: apakah file tujuannya ada?
// Menangkap error umum "Module not found" setelah panel di-upgrade.
import fs from 'node:fs';
import path from 'node:path';

const panel = path.resolve(process.argv[2] || '.');
const root = path.join(panel, 'resources/scripts');
const exts = ['', '.ts', '.tsx', '.js', '.jsx', '.css', '/index.ts', '/index.tsx', '/index.js'];
const aliases = { '@/': root + '/', '@feature/': path.join(root, 'components/server/features') + '/' };

const walk = (d) =>
    fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => {
        const p = path.join(d, e.name);
        return e.isDirectory() ? walk(p) : /\.(tsx?|jsx?)$/.test(e.name) ? [p] : [];
    });

let missing = 0;
for (const file of walk(root)) {
    const src = fs.readFileSync(file, 'utf8');
    for (const m of src.matchAll(/(?:from|import)\s+['"]((?:@\/|@feature\/)[^'"]+)['"]/g)) {
        const spec = m[1];
        const alias = Object.keys(aliases).find((a) => spec.startsWith(a));
        const base = aliases[alias] + spec.slice(alias.length);
        if (!exts.some((e) => fs.existsSync(base + e) && fs.statSync(base + e).isFile())) {
            console.error(`  [HILANG] ${path.relative(panel, file)} -> ${spec}`);
            missing++;
        }
    }
}
console.log(missing ? `\n${missing} import tidak ditemukan.` : '  Semua import ter-resolve.');
process.exit(missing ? 1 : 0);
