# GlassBrutal — Tema Pterodactyl (Glassmorphism × Neo Brutalism)

Tema tanpa build ulang frontend. Semua pengaturan lewat **Admin > Settings > Theme** (`/admin/theme`).

## Pasang
```bash
unzip glassbrutal-theme.zip && cd glassbrutal-theme
sudo bash install.sh install        # PANEL_DIR=/var/www/pterodactyl (default)
```
Buka `/admin/theme` untuk mengatur tema.

## Yang bisa diatur di admin
- Nama panel, logo (URL atau upload), font
- Warna: primary, secondary, tertiary, success, danger, ink, dasar background + preset (Sunrise, Mint, Bubblegum, Midnight, Mono)
- Mode light / dark (kaca terang / kaca gelap)
- Background: mesh, warna polos, gradasi, atau gambar (URL / upload) + overlay & blur
- Kekuatan efek: opacity & blur glass, tebal border, offset shadow, radius sudut
- Aktif/nonaktif per area: login, dashboard user, admin

## Perintah
```bash
sudo bash install.sh install      # pasang / update
sudo bash install.sh uninstall    # hapus, file asli dikembalikan (YES=1 lewati konfirmasi)
sudo bash install.sh reset        # reset pengaturan ke default
```

## File yang diubah (di-backup otomatis ke storage/glassbrutal-backup)
`resources/views/templates/wrapper.blade.php`, `layouts/admin.blade.php`,
`partials/admin/settings/nav.blade.php`, `routes/admin.php`.

## Catatan
- Pewarnaan dashboard user bersifat heuristik (JS membaca warna elemen). Jika ada elemen
  yang kurang pas di versi panelmu, laporkan elemennya agar selektornya bisa disesuaikan.
- Font Awesome & Google Fonts dimuat dari CDN. Jika pernah memasang tema Neo Brutalism lama
  dari `protect-pterodactyl.sh`, include lamanya otomatis dibersihkan saat install.
- Jika muncul `Class ... not found`: `cd /var/www/pterodactyl && composer dump-autoload`.
