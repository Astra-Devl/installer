<?php

namespace Pterodactyl\Helpers;

class GlassBrutal
{
    public const FONTS = ['Space Grotesk', 'Archivo', 'Poppins', 'Outfit', 'Inter', 'JetBrains Mono'];

    public static function path(): string
    {
        return storage_path('glassbrutal/theme.json');
    }

    public static function defaults(): array
    {
        return [
            'brand' => 'Pterodactyl',
            'logo' => '',
            'mode' => 'light',
            'font' => 'Space Grotesk',
            'c_primary' => '#FFD60A',
            'c_secondary' => '#FF6B9D',
            'c_tertiary' => '#4D96FF',
            'c_success' => '#5BE584',
            'c_danger' => '#FF5E5B',
            'c_ink' => '#111111',
            'c_bg' => '#FFF4D6',
            'bg_type' => 'mesh',
            'bg_color2' => '#FFB4D2',
            'bg_angle' => 135,
            'bg_image' => '',
            'bg_overlay' => 25,
            'bg_blur' => 0,
            'glass' => 55,
            'blur' => 16,
            'border' => 3,
            'shadow' => 6,
            'radius' => 0,
            'login' => true,
            'app' => true,
            'admin' => true,
            'v' => '1',
        ];
    }

    public static function load(): array
    {
        $raw = null;
        $p = self::path();
        if (is_file($p)) {
            $raw = json_decode((string) @file_get_contents($p), true);
        }

        return self::sanitize(is_array($raw) ? $raw : []);
    }

    public static function sanitize(array $in): array
    {
        $d = self::defaults();
        $o = [];

        $brand = trim(strip_tags((string) ($in['brand'] ?? '')));
        $o['brand'] = $brand !== '' ? mb_substr($brand, 0, 40) : $d['brand'];
        $o['logo'] = self::url($in['logo'] ?? '');
        $o['mode'] = (($in['mode'] ?? '') === 'dark') ? 'dark' : 'light';
        $o['font'] = in_array($in['font'] ?? '', self::FONTS, true) ? $in['font'] : $d['font'];

        foreach (['c_primary', 'c_secondary', 'c_tertiary', 'c_success', 'c_danger', 'c_ink', 'c_bg', 'bg_color2'] as $k) {
            $o[$k] = self::color($in[$k] ?? null, $d[$k]);
        }

        $o['bg_type'] = in_array($in['bg_type'] ?? '', ['mesh', 'solid', 'gradient', 'image'], true) ? $in['bg_type'] : 'mesh';
        $o['bg_image'] = self::url($in['bg_image'] ?? '');
        $o['bg_angle'] = self::num($in['bg_angle'] ?? null, 0, 360, $d['bg_angle']);
        $o['bg_overlay'] = self::num($in['bg_overlay'] ?? null, 0, 80, $d['bg_overlay']);
        $o['bg_blur'] = self::num($in['bg_blur'] ?? null, 0, 30, $d['bg_blur']);
        $o['glass'] = self::num($in['glass'] ?? null, 10, 95, $d['glass']);
        $o['blur'] = self::num($in['blur'] ?? null, 0, 40, $d['blur']);
        $o['border'] = self::num($in['border'] ?? null, 0, 8, $d['border']);
        $o['shadow'] = self::num($in['shadow'] ?? null, 0, 14, $d['shadow']);
        $o['radius'] = self::num($in['radius'] ?? null, 0, 28, $d['radius']);

        foreach (['login', 'app', 'admin'] as $k) {
            $o[$k] = array_key_exists($k, $in) ? filter_var($in[$k], FILTER_VALIDATE_BOOLEAN) : true;
        }

        $v = preg_replace('/\D/', '', (string) ($in['v'] ?? '1'));
        $o['v'] = $v !== '' ? $v : '1';

        return $o;
    }

    public static function save(array $in): array
    {
        $d = self::sanitize($in);
        $d['v'] = (string) time();
        $dir = dirname(self::path());
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        file_put_contents(
            self::path(),
            json_encode($d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL,
            LOCK_EX
        );

        return $d;
    }

    public static function reset(): void
    {
        $cur = self::load();
        self::deleteUpload($cur['logo']);
        self::deleteUpload($cur['bg_image']);
        @unlink(self::path());
    }

    public static function uploadDir(): string
    {
        return public_path('glassbrutal/uploads');
    }

    /** Simpan gambar upload, kembalikan URL relatif. */
    public static function storeUpload($file, string $kind): string
    {
        $dir = self::uploadDir();
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $ext = strtolower((string) $file->guessExtension());
        if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'gif'], true)) {
            $ext = 'png';
        }
        $name = $kind . '-' . time() . '-' . substr(md5(uniqid('', true)), 0, 6) . '.' . $ext;
        $file->move($dir, $name);

        return '/glassbrutal/uploads/' . $name;
    }

    public static function deleteUpload(?string $url): void
    {
        if (!$url || strpos($url, '/glassbrutal/uploads/') !== 0) {
            return;
        }
        $f = self::uploadDir() . '/' . basename($url);
        if (is_file($f)) {
            @unlink($f);
        }
    }

    public static function fontUrl(array $t): string
    {
        return 'https://fonts.googleapis.com/css2?family=' . str_replace(' ', '+', $t['font']) . ':wght@500;700&display=swap';
    }

    /** CSS variabel untuk :root (semua nilai sudah tervalidasi). */
    public static function css(array $t): string
    {
        $dark = $t['mode'] === 'dark';
        $rgb = function (string $h): string {
            $h = ltrim($h, '#');

            return hexdec(substr($h, 0, 2)) . ',' . hexdec(substr($h, 2, 2)) . ',' . hexdec(substr($h, 4, 2));
        };

        $line = $dark ? '#F4F4F5' : $t['c_ink'];
        $shc = $dark ? $t['c_primary'] : $t['c_ink'];
        $surface = $dark ? '22,22,30' : '255,255,255';
        $text = $dark ? '#F4F4F5' : $t['c_ink'];
        $bgrgb = $rgb($t['c_bg']);

        $bg = null;
        if ($t['bg_type'] === 'solid') {
            $bg = 'linear-gradient(' . $t['c_bg'] . ',' . $t['c_bg'] . ')';
        } elseif ($t['bg_type'] === 'gradient') {
            $bg = 'linear-gradient(' . $t['bg_angle'] . 'deg,' . $t['c_bg'] . ',' . $t['bg_color2'] . ')';
        } elseif ($t['bg_type'] === 'image' && $t['bg_image'] !== '') {
            $o = number_format($t['bg_overlay'] / 100, 2, '.', '');
            $bg = 'linear-gradient(rgba(' . $bgrgb . ',' . $o . '),rgba(' . $bgrgb . ',' . $o . ')),url("' . $t['bg_image'] . '")';
        }
        if ($bg === null) {
            $bg = 'radial-gradient(circle at 10% 15%,rgba(' . $rgb($t['c_secondary']) . ',.60) 0,transparent 36%),'
                . 'radial-gradient(circle at 90% 10%,rgba(' . $rgb($t['c_tertiary']) . ',.55) 0,transparent 34%),'
                . 'radial-gradient(circle at 75% 90%,rgba(' . $rgb($t['c_primary']) . ',.70) 0,transparent 40%),'
                . 'radial-gradient(circle at 15% 90%,rgba(' . $rgb($t['c_success']) . ',.45) 0,transparent 32%),'
                . 'linear-gradient(' . $t['c_bg'] . ',' . $t['c_bg'] . ')';
        }
        $bgblur = ($t['bg_type'] === 'image') ? $t['bg_blur'] : 0;

        $v = [
            '--gb-primary' => $t['c_primary'],
            '--gb-secondary' => $t['c_secondary'],
            '--gb-tertiary' => $t['c_tertiary'],
            '--gb-success' => $t['c_success'],
            '--gb-danger' => $t['c_danger'],
            '--gb-ink' => $t['c_ink'],
            '--gb-bg' => $t['c_bg'],
            '--gb-primary-rgb' => $rgb($t['c_primary']),
            '--gb-secondary-rgb' => $rgb($t['c_secondary']),
            '--gb-line' => $line,
            '--gb-line-rgb' => $rgb($line),
            '--gb-shc' => $shc,
            '--gb-surface' => $surface,
            '--gb-text' => $text,
            '--gb-bw' => $t['border'] . 'px',
            '--gb-sh' => $t['shadow'] . 'px',
            '--gb-r' => $t['radius'] . 'px',
            '--gb-blur' => $t['blur'] . 'px',
            '--gb-glass' => number_format($t['glass'] / 100, 2, '.', ''),
            '--gb-bgimg' => $bg,
            '--gb-bgblur' => $bgblur . 'px',
            '--gb-font' => '"' . $t['font'] . '",system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif',
        ];

        $out = ':root{';
        foreach ($v as $k => $val) {
            $out .= $k . ':' . $val . ';';
        }

        return $out . '}';
    }

    private static function num($v, int $min, int $max, int $def): int
    {
        if (!is_numeric($v)) {
            return $def;
        }

        return max($min, min($max, (int) round((float) $v)));
    }

    private static function color($v, string $def): string
    {
        return (is_string($v) && preg_match('/^#[0-9a-fA-F]{6}$/', $v)) ? strtoupper($v) : $def;
    }

    private static function url($v): string
    {
        $v = trim((string) $v);
        if ($v === '') {
            return '';
        }

        return preg_match('#^(https?://|/)[^\s"\'()<>\\\\]{1,500}$#', $v) ? $v : '';
    }
}
