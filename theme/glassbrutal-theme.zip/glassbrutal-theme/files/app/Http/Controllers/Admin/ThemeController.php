<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Helpers\GlassBrutal;
use Pterodactyl\Http\Controllers\Controller;

class ThemeController extends Controller
{
    /** @var \Prologue\Alerts\AlertsMessageBag */
    protected $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index(): View
    {
        return view('admin.theme', [
            't' => GlassBrutal::load(),
            'fonts' => GlassBrutal::FONTS,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        if ($request->input('reset')) {
            GlassBrutal::reset();
            $this->alert->success('Theme dikembalikan ke pengaturan default.')->flash();

            return redirect()->route('admin.theme');
        }

        $request->validate([
            'brand' => 'required|string|max:40',
            'logo_file' => 'nullable|image|mimes:png,jpg,jpeg,webp,gif|max:4096',
            'bg_file' => 'nullable|image|mimes:png,jpg,jpeg,webp,gif|max:8192',
        ]);

        $cur = GlassBrutal::load();
        $in = $request->only([
            'brand', 'mode', 'font',
            'c_primary', 'c_secondary', 'c_tertiary', 'c_success', 'c_danger', 'c_ink', 'c_bg',
            'bg_type', 'bg_color2', 'bg_angle', 'bg_overlay', 'bg_blur',
            'glass', 'blur', 'border', 'shadow', 'radius',
        ]);
        foreach (['login', 'app', 'admin'] as $k) {
            $in[$k] = $request->boolean($k);
        }

        // Logo
        $logo = trim((string) $request->input('logo', ''));
        if ($request->boolean('logo_remove')) {
            GlassBrutal::deleteUpload($cur['logo']);
            $logo = '';
        } elseif ($request->hasFile('logo_file')) {
            GlassBrutal::deleteUpload($cur['logo']);
            $logo = GlassBrutal::storeUpload($request->file('logo_file'), 'logo');
        } elseif ($logo !== $cur['logo']) {
            GlassBrutal::deleteUpload($cur['logo']);
        }
        $in['logo'] = $logo;

        // Background
        $bg = trim((string) $request->input('bg_image', ''));
        if ($request->boolean('bg_remove')) {
            GlassBrutal::deleteUpload($cur['bg_image']);
            $bg = '';
        } elseif ($request->hasFile('bg_file')) {
            GlassBrutal::deleteUpload($cur['bg_image']);
            $bg = GlassBrutal::storeUpload($request->file('bg_file'), 'bg');
            $in['bg_type'] = 'image';
        } elseif ($bg !== $cur['bg_image']) {
            GlassBrutal::deleteUpload($cur['bg_image']);
        }
        $in['bg_image'] = $bg;

        GlassBrutal::save($in);
        $this->alert->success('Theme berhasil disimpan.')->flash();

        return redirect()->route('admin.theme');
    }
}
