/* GlassBrutal — admin: nama & logo di header, link menu Theme */
(function () {
  'use strict';
  var C = window.__GB || { brand: 'Pterodactyl', logo: '' };

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function brand() {
    var logo = document.querySelector('.main-header .logo');
    if (!logo) { return; }
    var img = C.logo ? '<img src="' + esc(C.logo) + '" alt="">' : '<i class="fa fa-cube"></i>';
    logo.innerHTML = '<span class="gb-logo">' + img + '<span class="gb-name">' + esc(C.brand || 'Pterodactyl') + '</span></span>';
  }

  function link() {
    var menu = document.querySelector('.sidebar-menu');
    if (!menu || menu.querySelector('a[href$="/admin/theme"]')) { return; }
    var a = menu.querySelector('a[href$="/admin/settings"]');
    var li = a && a.closest('li');
    if (!li) { return; }
    var n = document.createElement('li');
    if (location.pathname.indexOf('/admin/theme') === 0) { n.className = 'active'; }
    n.innerHTML = '<a href="/admin/theme"><i class="fa fa-paint-brush"></i> <span>Theme</span></a>';
    li.parentNode.insertBefore(n, li.nextSibling);
  }

  brand();
  link();
})();
