/* GlassBrutal — header + sidebar baru, ikon Font Awesome, pewarnaan isi halaman (tanpa build ulang frontend) */
(function () {
  'use strict';
  if (window.__gbTheme) { return; }
  window.__gbTheme = true;

  var doc = document.documentElement;
  var CFG = window.__GB || { brand: 'Pterodactyl', logo: '' };
  var isAuth = doc.classList.contains('gb-auth');
  var isApp = doc.classList.contains('gb-app');
  if (!isAuth && !isApp) { return; }

  var NAVRE = /^\/(?:admin|account(?:\/(?:api|ssh|activity))?|server\/[^\/#?]+(?:\/(?:files|databases|schedules|users|backups|network|startup|settings|activity))?)?\/?$/;
  var SRVRE = /^\/server\/([^\/#?]+)(?:\/([a-z]+))?\/?$/;
  var ICONS = {
    '': 'terminal', files: 'folder-open', databases: 'database', schedules: 'clock', users: 'users',
    backups: 'box-archive', network: 'network-wired', startup: 'play', settings: 'gear', activity: 'list-check'
  };
  var DEFAULT_SERVER = [
    ['', 'Console'], ['files', 'Files'], ['databases', 'Databases'], ['schedules', 'Schedules'], ['users', 'Users'],
    ['backups', 'Backups'], ['network', 'Network'], ['startup', 'Startup'], ['settings', 'Settings'], ['activity', 'Activity']
  ];

  /* ---------- util ---------- */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function brandHtml() {
    var img = CFG.logo ? '<img src="' + esc(CFG.logo) + '" alt="">' : '<i class="fa-solid fa-dragon"></i>';
    return img + '<span class="gb-name">' + esc(CFG.brand || 'Pterodactyl') + '</span>';
  }
  function parse(c) {
    var m = /rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,\/]\s*([\d.]+)(%?))?\s*\)/.exec(c || '');
    if (!m) { return null; }
    var a = m[4] === undefined ? 1 : parseFloat(m[4]);
    if (m[5] === '%') { a /= 100; }
    return { r: +m[1], g: +m[2], b: +m[3], a: a };
  }
  function hsl(c) {
    var r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    var l = (mx + mn) / 2, h = 0, s = 0, d = mx - mn;
    if (d) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) { h = (g - b) / d + (g < b ? 6 : 0); }
      else if (mx === g) { h = (b - r) / d + 2; }
      else { h = (r - g) / d + 4; }
      h *= 60;
    }
    return { h: h, s: s, l: l };
  }
  function hueName(h) {
    if (h < 18 || h >= 340) { return 'danger'; }
    if (h < 48) { return 'secondary'; }
    if (h < 75) { return 'primary'; }
    if (h < 170) { return 'success'; }
    if (h < 262) { return 'tertiary'; }
    return 'secondary';
  }

  /* ---------- halaman login ---------- */
  function buildAuth() {
    if (!document.body || document.getElementById('gb-authbrand')) { return; }
    var h = document.createElement('div');
    h.id = 'gb-authbrand';
    h.innerHTML = '<a class="gb-logo" href="/">' + brandHtml() + '</a>';
    document.body.appendChild(h);
  }
  if (isAuth) {
    if (document.body) { buildAuth(); } else { document.addEventListener('DOMContentLoaded', buildAuth); }
    return;
  }

  /* ---------- dashboard: navigasi ---------- */
  var serverLinks = {};
  var hidden = [];
  var lastNav = '';

  function serverId() {
    var m = location.pathname.match(/^\/server\/([^\/]+)/);
    return m ? m[1] : null;
  }
  function go(href) {
    history.pushState({}, '', href);
    window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
  }
  function logout() {
    var m = document.cookie.match(/(?:^|; )XSRF-TOKEN=([^;]+)/);
    var done = function () { location.href = '/auth/login'; };
    fetch('/auth/logout', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json', 'X-XSRF-TOKEN': m ? decodeURIComponent(m[1]) : '' }
    }).then(done, done);
  }

  function ensureShell() {
    if (!document.body || document.getElementById('gb-header')) { return; }
    var U = window.PterodactylUser || {};
    var header = document.createElement('div');
    header.id = 'gb-header';
    header.innerHTML =
      '<button type="button" class="gb-act" data-gb="toggle" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>' +
      '<a class="gb-logo gb-spa" href="/">' + brandHtml() + '</a><span class="gb-sp"></span>' +
      (U.root_admin ? '<a class="gb-act" href="/admin"><i class="fa-solid fa-shield-halved"></i><span>Admin</span></a>' : '') +
      '<a class="gb-act gb-spa" href="/account"><i class="fa-solid fa-user"></i><span>Akun</span></a>' +
      '<button type="button" class="gb-act gb-out" data-gb="logout"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></button>';
    var side = document.createElement('div');
    side.id = 'gb-sidebar';
    side.innerHTML = '<nav id="gb-nav"></nav>' +
      (U.username ? '<div class="gb-user"><i class="fa-solid fa-circle-user"></i><b>' + esc(U.username) + '</b></div>' : '');
    var ov = document.createElement('div');
    ov.id = 'gb-overlay';
    ov.setAttribute('data-gb', 'close');
    document.body.appendChild(header);
    document.body.appendChild(side);
    document.body.appendChild(ov);
    doc.classList.add('gb-shell');
    try { if (localStorage.getItem('gb-collapsed') === '1') { doc.classList.add('gb-collapsed'); } } catch (e) { /* abaikan */ }
  }

  function renderNav() {
    var nav = document.getElementById('gb-nav');
    if (!nav) { return; }
    var path = location.pathname.replace(/\/+$/, '') || '/';
    var id = serverId();
    var html = '';
    function item(href, icon, label) {
      var active = path === href || (href !== '/' && path.indexOf(href + '/') === 0 && !(id && href === '/server/' + id));
      return '<a class="gb-spa' + (active ? ' gb-active' : '') + '" href="' + esc(href) + '"><i class="fa-solid fa-' + icon + '"></i><span>' + esc(label) + '</span></a>';
    }
    if (id) {
      html += '<span class="gb-label">SERVER</span>';
      var list = serverLinks[id];
      if (!list || !list.length) {
        list = DEFAULT_SERVER.map(function (s) { return { href: '/server/' + id + (s[0] ? '/' + s[0] : ''), key: s[0], label: s[1] }; });
      }
      list.forEach(function (l) { html += item(l.href, ICONS[l.key] || 'circle', l.label); });
      html += '<span class="gb-label">MENU</span>' + item('/', 'house', 'Dashboard');
    } else {
      html += '<span class="gb-label">MENU</span>' +
        item('/', 'house', 'Dashboard') + item('/account', 'user', 'Akun') +
        item('/account/api', 'key', 'API Credentials') + item('/account/ssh', 'terminal', 'SSH Keys') +
        item('/account/activity', 'list-check', 'Activity');
    }
    if (html !== lastNav) { nav.innerHTML = html; lastNav = html; }
  }

  /* cari & sembunyikan bar navigasi bawaan (navbar atas, subnav server, tab akun) */
  function bars() {
    var anchors = [].slice.call(document.querySelectorAll('#app a[href]')).filter(function (a) {
      if (a.closest('.gb-hide')) { return false; }
      if (!NAVRE.test(a.getAttribute('href'))) { return false; }
      var r = a.getBoundingClientRect();
      return r.height > 0 && r.height < 80 && r.top < 160;
    });
    var found = [];
    anchors.forEach(function (a) {
      var p = a.parentElement, best = null;
      while (p && p.id !== 'app' && p !== document.body) {
        if (p.getBoundingClientRect().height > 100) { break; }
        var n = 0;
        anchors.forEach(function (b) { if (p.contains(b)) { n++; } });
        if (n >= 3) { best = p; }
        p = p.parentElement;
      }
      if (best && found.indexOf(best) < 0) { found.push(best); }
    });
    var sid = serverId();
    found.forEach(function (bar) {
      if (sid) {
        var list = [], seen = {};
        [].forEach.call(bar.querySelectorAll('a[href]'), function (a) {
          var href = a.getAttribute('href'), m = SRVRE.exec(href);
          if (!m || m[1] !== sid || seen[href]) { return; }
          seen[href] = 1;
          var key = m[2] || '';
          var label = (a.textContent || '').trim() || (key ? key.charAt(0).toUpperCase() + key.slice(1) : 'Console');
          list.push({ href: href, key: key, label: label });
        });
        if (list.length > 1) { serverLinks[sid] = list; }
      }
      bar.classList.add('gb-hide');
      if (hidden.indexOf(bar) < 0) { hidden.push(bar); }
    });
    hidden = hidden.filter(function (el) {
      if (!el.isConnected) { return false; }
      if (!el.classList.contains('gb-hide')) { el.classList.add('gb-hide'); }
      return true;
    });
  }

  /* ---------- pewarnaan isi halaman ---------- */
  var SKIP = /^(SCRIPT|STYLE|LINK|META|IMG|INPUT|SELECT|TEXTAREA|OPTION|BR|HR|CANVAS|VIDEO|IFRAME|TITLE)$/;
  function tag(e) {
    if (e.nodeType !== 1 || e instanceof SVGElement) { return; }
    if (SKIP.test(e.tagName) || e.classList.contains('gb-t')) { return; }
    if (e.closest('#gb-header,#gb-sidebar,#gb-authbrand,#gb-overlay,.xterm')) { return; }
    var cs = getComputedStyle(e), bg = parse(cs.backgroundColor);
    if (!bg || bg.a < 0.35) { return; }
    var r = e.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) { return; }
    var cls = '';
    var fixedFull = cs.position === 'fixed' && r.width >= innerWidth * 0.9 && r.height >= innerHeight * 0.9;
    if (!fixedFull) {
      var h = hsl(bg);
      var app = document.getElementById('app');
      var pw = app ? app.getBoundingClientRect().width : innerWidth;
      if (h.s > 0.28 && h.l > 0.18 && h.l < 0.9) {
        cls = (r.height < 14 ? 'gb-fill gb-f-' : 'gb-c gb-c-') + hueName(h.h);
      } else if (r.width >= pw - 24 && r.height > 260) {
        cls = 'gb-s0';
      } else if (e.id === 'terminal' || e.querySelector('.xterm')) {
        cls = 'gb-dark';
      } else {
        var p = e.parentElement;
        if (!p || !p.closest('.gb-s1,.gb-s2,.gb-s3')) { cls = 'gb-s1'; }
        else if (p.closest('.gb-s2,.gb-s3')) { cls = 'gb-s3'; }
        else { cls = 'gb-s2'; }
      }
    }
    e.classList.add('gb-t');
    if (cls) { cls.split(' ').forEach(function (c) { e.classList.add(c); }); }
  }
  function tagDeep(n) {
    tag(n);
    if (n.querySelectorAll) { [].forEach.call(n.querySelectorAll('*'), tag); }
  }

  /* ---------- antrean mutasi ---------- */
  var queue = [], scheduled = false;
  function schedule() {
    if (scheduled) { return; }
    scheduled = true;
    requestAnimationFrame(flush);
  }
  function flush() {
    scheduled = false;
    ensureShell();
    bars();
    renderNav();
    var q = queue;
    queue = [];
    q.forEach(function (it) { if (it.n.isConnected) { if (it.deep) { tagDeep(it.n); } else { tag(it.n); } } });
  }
  function addQ(n, deep) { if (n.nodeType === 1) { queue.push({ n: n, deep: deep }); } }

  var mo = new MutationObserver(function (ms) {
    ms.forEach(function (m) {
      if (m.type === 'attributes') { addQ(m.target, false); }
      else { [].forEach.call(m.addedNodes, function (n) { addQ(n, true); }); }
    });
    schedule();
  });

  /* ---------- event ---------- */
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest && ev.target.closest('[data-gb],a.gb-spa');
    if (!t) { return; }
    var k = t.getAttribute('data-gb');
    if (k === 'toggle') {
      if (innerWidth <= 960) { doc.classList.toggle('gb-open'); }
      else {
        var c = doc.classList.toggle('gb-collapsed');
        try { localStorage.setItem('gb-collapsed', c ? '1' : '0'); } catch (e) { /* abaikan */ }
      }
    } else if (k === 'close') {
      doc.classList.remove('gb-open');
    } else if (k === 'logout') {
      ev.preventDefault();
      logout();
    } else if (t.tagName === 'A') {
      if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.button) { return; }
      ev.preventDefault();
      doc.classList.remove('gb-open');
      go(t.getAttribute('href'));
    }
  });
  ['pushState', 'replaceState'].forEach(function (m) {
    var orig = history[m];
    history[m] = function () {
      var r = orig.apply(this, arguments);
      window.dispatchEvent(new Event('gb-nav'));
      return r;
    };
  });
  window.addEventListener('gb-nav', schedule);
  window.addEventListener('popstate', schedule);

  function start() {
    ensureShell();
    mo.observe(doc, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    [].forEach.call(document.querySelectorAll('#app *,#modal-mount *'), tag);
    bars();
    renderNav();
  }
  if (document.body) { start(); } else { document.addEventListener('DOMContentLoaded', start); }
})();
