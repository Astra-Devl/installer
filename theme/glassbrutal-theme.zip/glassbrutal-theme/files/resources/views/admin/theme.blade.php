@extends('layouts.admin')

@section('title')
    Theme
@endsection

@section('content-header')
    <h1>Theme<small>Warna, logo, nama, dan background panel.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @includeIf('partials.admin.settings.nav', ['activeTab' => 'theme'])
    @php
        $colors = [
            'c_primary' => 'Primary (aksen utama, header)',
            'c_secondary' => 'Secondary (menu aktif, hover)',
            'c_tertiary' => 'Tertiary (tombol info)',
            'c_success' => 'Success (tombol simpan)',
            'c_danger' => 'Danger (tombol hapus)',
            'c_ink' => 'Ink (teks & garis, mode light)',
            'c_bg' => 'Warna dasar background',
        ];
        $ranges = [
            ['glass', 'Opacity glass (%)', 10, 95],
            ['blur', 'Blur glass (px)', 0, 40],
            ['border', 'Tebal border (px)', 0, 8],
            ['shadow', 'Offset shadow (px)', 0, 14],
            ['radius', 'Radius sudut (px)', 0, 28],
        ];
    @endphp
    <style>
        .gb-row{display:flex;align-items:center;gap:10px;margin-bottom:10px}
        .gb-row > label{flex:0 0 190px;margin:0;font-weight:600}
        .gb-row input[type=color]{width:46px;height:34px;padding:2px;cursor:pointer}
        .gb-row input[type=range]{flex:1}
        .gb-row .gb-out{width:48px;text-align:right;font-family:monospace}
        .gb-presets{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}
        .gbp{position:relative;border:3px solid #111;overflow:hidden;min-height:330px;font-family:var(--g-font,sans-serif);color:var(--g-text);background:#eee}
        .gbp-head{display:flex;align-items:center;gap:8px;padding:10px 12px;background:var(--g-primary);border-bottom:var(--g-bw) solid var(--g-line);color:var(--g-ink)}
        .gbp-logo{display:flex;align-items:center;gap:8px;padding:4px 10px;background:rgba(var(--g-surf),.92);color:var(--g-text);border:var(--g-bw) solid var(--g-line);box-shadow:var(--g-sh) var(--g-sh) 0 var(--g-shc);border-radius:var(--g-r);font-weight:700}
        .gbp-logo img{max-height:22px;width:auto}
        .gbp-body{display:flex;gap:12px;padding:12px}
        .gbp-side{flex:0 0 96px;display:flex;flex-direction:column;gap:8px}
        .gbp-side span{padding:6px 8px;font-size:11px;font-weight:700;background:rgba(var(--g-surf),var(--g-glass));-webkit-backdrop-filter:blur(var(--g-blur));backdrop-filter:blur(var(--g-blur));border:var(--g-bw) solid var(--g-line);box-shadow:3px 3px 0 var(--g-shc);border-radius:var(--g-r)}
        .gbp-side span.on{background:var(--g-secondary);color:var(--g-ink)}
        .gbp-card{flex:1;padding:12px;background:rgba(var(--g-surf),var(--g-glass));-webkit-backdrop-filter:blur(var(--g-blur)) saturate(1.5);backdrop-filter:blur(var(--g-blur)) saturate(1.5);border:var(--g-bw) solid var(--g-line);box-shadow:var(--g-sh) var(--g-sh) 0 var(--g-shc);border-radius:var(--g-r)}
        .gbp-card h4{margin:0 0 6px;font-weight:700}
        .gbp-card p{margin:0 0 10px;font-size:12px}
        .gbp-btn{display:inline-block;margin:0 6px 6px 0;padding:5px 10px;font-size:11px;font-weight:700;color:var(--g-ink);border:var(--g-bw) solid var(--g-line);box-shadow:3px 3px 0 var(--g-shc);border-radius:var(--g-r)}
        .gbp-input{display:block;width:100%;margin-top:4px;padding:6px 8px;font-size:12px;background:rgba(var(--g-surf),.85);color:var(--g-text);border:var(--g-bw) solid var(--g-line);border-radius:var(--g-r)}
    </style>

    <form action="{{ route('admin.theme') }}" method="POST" enctype="multipart/form-data" id="gb-form">
        {!! csrf_field() !!}
        <div class="row">
            <div class="col-md-7">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title">Identitas</h3></div>
                    <div class="box-body">
                        <div class="gb-row"><label for="gb-brand">Nama panel</label>
                            <input type="text" id="gb-brand" name="brand" class="form-control" maxlength="40" value="{{ old('brand', $t['brand']) }}" required></div>
                        <div class="gb-row"><label for="gb-logo">URL logo</label>
                            <input type="text" id="gb-logo" name="logo" class="form-control" placeholder="https://... atau /path/logo.png" value="{{ $t['logo'] }}"></div>
                        <div class="gb-row"><label for="gb-logo-file">Upload logo</label>
                            <input type="file" id="gb-logo-file" name="logo_file" accept="image/png,image/jpeg,image/webp,image/gif"></div>
                        <div class="gb-row"><label></label>
                            <label style="flex:1;font-weight:400"><input type="checkbox" name="logo_remove" value="1"> Hapus logo (pakai ikon bawaan)</label></div>
                        <div class="gb-row"><label for="gb-font">Font</label>
                            <select id="gb-font" name="font" class="form-control">
                                @foreach ($fonts as $f)
                                    <option value="{{ $f }}" @if ($t['font'] === $f) selected @endif>{{ $f }}</option>
                                @endforeach
                            </select></div>
                    </div>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title">Warna panel</h3></div>
                    <div class="box-body">
                        <div class="gb-presets">
                            <button type="button" class="btn btn-default btn-sm" data-preset="sunrise">Sunrise</button>
                            <button type="button" class="btn btn-default btn-sm" data-preset="mint">Mint</button>
                            <button type="button" class="btn btn-default btn-sm" data-preset="bubble">Bubblegum</button>
                            <button type="button" class="btn btn-default btn-sm" data-preset="midnight">Midnight (dark)</button>
                            <button type="button" class="btn btn-default btn-sm" data-preset="mono">Mono</button>
                        </div>
                        <div class="gb-row"><label for="gb-mode">Mode</label>
                            <select id="gb-mode" name="mode" class="form-control">
                                <option value="light" @if ($t['mode'] === 'light') selected @endif>Light (kaca terang)</option>
                                <option value="dark" @if ($t['mode'] === 'dark') selected @endif>Dark (kaca gelap)</option>
                            </select></div>
                        @foreach ($colors as $key => $label)
                            <div class="gb-row"><label for="gb-{{ $key }}">{{ $label }}</label>
                                <input type="color" id="gb-{{ $key }}" name="{{ $key }}" value="{{ strtolower($t[$key]) }}">
                                <code class="gb-hex" data-for="{{ $key }}">{{ $t[$key] }}</code></div>
                        @endforeach
                    </div>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title">Background</h3></div>
                    <div class="box-body">
                        <div class="gb-row"><label for="gb-bgtype">Tipe</label>
                            <select id="gb-bgtype" name="bg_type" class="form-control">
                                <option value="mesh" @if ($t['bg_type'] === 'mesh') selected @endif>Mesh (gradasi dari warna panel)</option>
                                <option value="solid" @if ($t['bg_type'] === 'solid') selected @endif>Warna polos</option>
                                <option value="gradient" @if ($t['bg_type'] === 'gradient') selected @endif>Gradasi 2 warna</option>
                                <option value="image" @if ($t['bg_type'] === 'image') selected @endif>Gambar</option>
                            </select></div>
                        <div class="gb-row"><label for="gb-bgc2">Warna gradasi ke-2</label>
                            <input type="color" id="gb-bgc2" name="bg_color2" value="{{ strtolower($t['bg_color2']) }}">
                            <code class="gb-hex" data-for="bg_color2">{{ $t['bg_color2'] }}</code></div>
                        <div class="gb-row"><label for="gb-angle">Sudut gradasi</label>
                            <input type="range" id="gb-angle" name="bg_angle" min="0" max="360" value="{{ $t['bg_angle'] }}"><span class="gb-out"></span></div>
                        <div class="gb-row"><label for="gb-bgimg">URL gambar</label>
                            <input type="text" id="gb-bgimg" name="bg_image" class="form-control" placeholder="https://... atau /path/bg.jpg" value="{{ $t['bg_image'] }}"></div>
                        <div class="gb-row"><label for="gb-bgfile">Upload gambar</label>
                            <input type="file" id="gb-bgfile" name="bg_file" accept="image/png,image/jpeg,image/webp,image/gif"></div>
                        <div class="gb-row"><label></label>
                            <label style="flex:1;font-weight:400"><input type="checkbox" name="bg_remove" value="1"> Hapus gambar background</label></div>
                        <div class="gb-row"><label for="gb-overlay">Overlay gambar (%)</label>
                            <input type="range" id="gb-overlay" name="bg_overlay" min="0" max="80" value="{{ $t['bg_overlay'] }}"><span class="gb-out"></span></div>
                        <div class="gb-row"><label for="gb-bgblur">Blur gambar (px)</label>
                            <input type="range" id="gb-bgblur" name="bg_blur" min="0" max="30" value="{{ $t['bg_blur'] }}"><span class="gb-out"></span></div>
                    </div>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title">Glass × Neo Brutalism</h3></div>
                    <div class="box-body">
                        @foreach ($ranges as $r)
                            <div class="gb-row"><label for="gb-{{ $r[0] }}">{{ $r[1] }}</label>
                                <input type="range" id="gb-{{ $r[0] }}" name="{{ $r[0] }}" min="{{ $r[2] }}" max="{{ $r[3] }}" value="{{ $t[$r[0]] }}"><span class="gb-out"></span></div>
                        @endforeach
                    </div>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title">Area yang diberi tema</h3></div>
                    <div class="box-body">
                        <div class="checkbox"><label><input type="checkbox" name="login" value="1" @if ($t['login']) checked @endif> Halaman login</label></div>
                        <div class="checkbox"><label><input type="checkbox" name="app" value="1" @if ($t['app']) checked @endif> Dashboard user &amp; server</label></div>
                        <div class="checkbox"><label><input type="checkbox" name="admin" value="1" @if ($t['admin']) checked @endif> Admin panel</label></div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-success btn-sm pull-right">Simpan theme</button>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="box box-info" style="position:sticky;top:60px">
                    <div class="box-header with-border"><h3 class="box-title">Preview langsung</h3></div>
                    <div class="box-body">
                        <div class="gbp" id="gb-preview">
                            <div class="gbp-head">
                                <span class="gbp-logo"><img id="gbp-img" alt="" style="display:none"><i class="fa fa-cube" id="gbp-ico"></i><span id="gbp-name">{{ $t['brand'] }}</span></span>
                            </div>
                            <div class="gbp-body">
                                <div class="gbp-side"><span class="on">Dashboard</span><span>Server</span><span>Akun</span></div>
                                <div class="gbp-card">
                                    <h4>My Server</h4>
                                    <p>Kartu kaca dengan border tebal dan shadow keras.</p>
                                    <span class="gbp-btn" style="background:var(--g-success)">Simpan</span><span class="gbp-btn" style="background:var(--g-tertiary)">Info</span><span class="gbp-btn" style="background:var(--g-danger)">Hapus</span>
                                    <span class="gbp-input">Cari server...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <form action="{{ route('admin.theme') }}" method="POST" onsubmit="return confirm('Kembalikan theme ke default? Logo & gambar upload akan dihapus.');">
        {!! csrf_field() !!}
        <input type="hidden" name="reset" value="1">
        <button type="submit" class="btn btn-danger btn-sm">Reset ke default</button>
    </form>
@endsection

@section('footer-scripts')
    @parent
    <script>
        (function () {
            var f = document.getElementById('gb-form'), p = document.getElementById('gb-preview');
            var PRESETS = {
                sunrise: {mode: 'light', c_primary: '#FFD60A', c_secondary: '#FF6B9D', c_tertiary: '#4D96FF', c_success: '#5BE584', c_danger: '#FF5E5B', c_ink: '#111111', c_bg: '#FFF4D6', bg_color2: '#FFB4D2'},
                mint: {mode: 'light', c_primary: '#3DF5C0', c_secondary: '#FFB703', c_tertiary: '#3A86FF', c_success: '#8AFF80', c_danger: '#FF4D6D', c_ink: '#0B1F1A', c_bg: '#E3FFF5', bg_color2: '#B8F2FF'},
                bubble: {mode: 'light', c_primary: '#FF8FD0', c_secondary: '#B79CFF', c_tertiary: '#6CD4FF', c_success: '#9DFFB0', c_danger: '#FF5E7E', c_ink: '#1B0F26', c_bg: '#FFE8F6', bg_color2: '#E5DAFF'},
                midnight: {mode: 'dark', c_primary: '#B6FF3B', c_secondary: '#FF5CAA', c_tertiary: '#59B6FF', c_success: '#3DFFA0', c_danger: '#FF5E5B', c_ink: '#0D0D12', c_bg: '#14141F', bg_color2: '#2A1B4D'},
                mono: {mode: 'light', c_primary: '#EDEDED', c_secondary: '#BDBDBD', c_tertiary: '#9A9A9A', c_success: '#D4D4D4', c_danger: '#7A7A7A', c_ink: '#111111', c_bg: '#F2F2F2', bg_color2: '#D9D9D9'}
            };
            function g(n) { var e = f.elements[n]; return e ? e.value : ''; }
            function rgb(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)].join(','); }
            var fileUrl = {logo: '', bg: ''};
            function setv(k, v) { p.style.setProperty(k, v); }
            function paint() {
                var dark = g('mode') === 'dark', ink = g('c_ink');
                setv('--g-primary', g('c_primary')); setv('--g-secondary', g('c_secondary')); setv('--g-tertiary', g('c_tertiary'));
                setv('--g-success', g('c_success')); setv('--g-danger', g('c_danger')); setv('--g-ink', ink);
                setv('--g-line', dark ? '#F4F4F5' : ink); setv('--g-shc', dark ? g('c_primary') : ink);
                setv('--g-surf', dark ? '22,22,30' : '255,255,255'); setv('--g-text', dark ? '#F4F4F5' : ink);
                setv('--g-bw', g('border') + 'px'); setv('--g-sh', g('shadow') + 'px'); setv('--g-r', g('radius') + 'px');
                setv('--g-blur', g('blur') + 'px'); setv('--g-glass', (g('glass') / 100).toFixed(2));
                setv('--g-font', '"' + g('font') + '",system-ui,sans-serif');
                var bgc = g('c_bg'), t = g('bg_type'), bg, img = fileUrl.bg || g('bg_image');
                if (t === 'solid') { bg = bgc; }
                else if (t === 'gradient') { bg = 'linear-gradient(' + g('bg_angle') + 'deg,' + bgc + ',' + g('bg_color2') + ')'; }
                else if (t === 'image' && img) {
                    var o = (g('bg_overlay') / 100).toFixed(2), c = 'rgba(' + rgb(bgc) + ',' + o + ')';
                    bg = 'linear-gradient(' + c + ',' + c + '),url("' + img.replace(/"/g, '') + '") center/cover';
                } else {
                    bg = 'radial-gradient(circle at 10% 15%,rgba(' + rgb(g('c_secondary')) + ',.6) 0,transparent 36%),radial-gradient(circle at 90% 10%,rgba(' + rgb(g('c_tertiary')) + ',.55) 0,transparent 34%),radial-gradient(circle at 75% 90%,rgba(' + rgb(g('c_primary')) + ',.7) 0,transparent 40%),radial-gradient(circle at 15% 90%,rgba(' + rgb(g('c_success')) + ',.45) 0,transparent 32%),' + bgc;
                }
                p.style.background = bg;
                document.getElementById('gbp-name').textContent = g('brand') || 'Pterodactyl';
                var li = fileUrl.logo || g('logo'), im = document.getElementById('gbp-img'), ic = document.getElementById('gbp-ico');
                if (li && !f.elements.logo_remove.checked) { im.src = li; im.style.display = ''; ic.style.display = 'none'; }
                else { im.style.display = 'none'; ic.style.display = ''; }
                [].forEach.call(f.querySelectorAll('.gb-hex'), function (c) { c.textContent = g(c.getAttribute('data-for')).toUpperCase(); });
                [].forEach.call(f.querySelectorAll('input[type=range]'), function (r) { var o = r.parentNode.querySelector('.gb-out'); if (o) { o.textContent = r.value; } });
            }
            f.addEventListener('input', paint);
            f.addEventListener('change', paint);
            function pick(name, key) {
                f.elements[name].addEventListener('change', function () {
                    var file = this.files && this.files[0];
                    fileUrl[key] = file ? URL.createObjectURL(file) : '';
                    if (key === 'bg' && file) { f.elements.bg_type.value = 'image'; }
                    paint();
                });
            }
            pick('logo_file', 'logo'); pick('bg_file', 'bg');
            [].forEach.call(document.querySelectorAll('[data-preset]'), function (b) {
                b.addEventListener('click', function () {
                    var d = PRESETS[b.getAttribute('data-preset')];
                    Object.keys(d).forEach(function (k) { f.elements[k].value = d[k]; });
                    paint();
                });
            });
            paint();
        })();
    </script>
@endsection
