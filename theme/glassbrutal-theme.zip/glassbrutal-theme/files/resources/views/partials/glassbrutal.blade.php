@php
    $__t = \Pterodactyl\Helpers\GlassBrutal::load();
    $__admin = ($area ?? 'user') === 'admin';
    $__v = $__t['v'];
    $__font = \Pterodactyl\Helpers\GlassBrutal::fontUrl($__t);
    $__js = json_encode([
        'brand' => $__t['brand'],
        'logo' => $__t['logo'],
        'mode' => $__t['mode'],
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
@endphp
@if ($__admin)
    @if ($__t['admin'])
        <link rel="stylesheet" href="{{ $__font }}">
        <style id="gb-vars">{!! \Pterodactyl\Helpers\GlassBrutal::css($__t) !!}</style>
        <link rel="stylesheet" href="/glassbrutal/base.css?v={{ $__v }}">
        <link rel="stylesheet" href="/glassbrutal/admin.css?v={{ $__v }}">
        <script>document.documentElement.classList.add('gb-on', 'gb-admin'); window.__GB = {!! $__js !!};</script>
        <script src="/glassbrutal/admin.js?v={{ $__v }}" defer></script>
    @endif
@elseif ($__t['login'] || $__t['app'])
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="{{ $__font }}">
    <style id="gb-vars">{!! \Pterodactyl\Helpers\GlassBrutal::css($__t) !!}</style>
    <link rel="stylesheet" href="/glassbrutal/base.css?v={{ $__v }}">
    <link rel="stylesheet" href="/glassbrutal/login.css?v={{ $__v }}">
    <link rel="stylesheet" href="/glassbrutal/app.css?v={{ $__v }}">
    <script>
        (function () {
            var c = document.documentElement.classList, a = location.pathname.indexOf('/auth') === 0;
            var L = {{ $__t['login'] ? 'true' : 'false' }}, P = {{ $__t['app'] ? 'true' : 'false' }};
            if (a) { if (L) { c.add('gb-on', 'gb-auth'); } } else if (P) { c.add('gb-on', 'gb-app'); }
            window.__GB = {!! $__js !!};
        })();
    </script>
    <script src="/glassbrutal/theme.js?v={{ $__v }}" defer></script>
@endif
