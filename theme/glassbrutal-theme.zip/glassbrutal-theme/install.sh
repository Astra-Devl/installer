#!/usr/bin/env bash
# =============================================================================
#  GlassBrutal — tema Pterodactyl (Glassmorphism x Neo Brutalism)
#  Pemakaian:
#     sudo bash install.sh              -> menu
#     sudo bash install.sh install      -> pasang / update tema
#     sudo bash install.sh uninstall    -> hapus tema, kembalikan file asli
#     sudo bash install.sh reset        -> reset pengaturan tema ke default
#  Env opsional: PANEL_DIR=/var/www/pterodactyl  YES=1 (lewati konfirmasi)
#                KEEP_SETTINGS=1 (uninstall tanpa menghapus theme.json & upload)
#  Pengaturan tema (nama, logo, warna, background) ada di: Admin > Settings > Theme
# =============================================================================
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
ACTION="${1:-menu}"
BK="$PANEL_DIR/storage/glassbrutal-backup"
CFG_DIR="$PANEL_DIR/storage/glassbrutal"
PUB_DIR="$PANEL_DIR/public/glassbrutal"

V_WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
V_CORE="$PANEL_DIR/resources/views/templates/base/core.blade.php"
V_ADMIN="$PANEL_DIR/resources/views/layouts/admin.blade.php"
V_NAV="$PANEL_DIR/resources/views/partials/admin/settings/nav.blade.php"
ROUTES="$PANEL_DIR/routes/admin.php"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_ylw=$'\e[33m'; c_off=$'\e[0m'
info() { echo "${c_grn}[+]${c_off} $*"; }
warn() { echo "${c_ylw}[!]${c_off} $*"; }
die()  { echo "${c_red}[x]${c_off} $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Jalankan sebagai root (sudo bash $0)"
[[ -f "$PANEL_DIR/artisan" ]] || die "Panel tidak ditemukan di $PANEL_DIR (set PANEL_DIR=...)"
command -v php >/dev/null || die "php tidak ditemukan"
command -v perl >/dev/null || die "perl tidak ditemukan"

OWNER="$(stat -c %U "$PANEL_DIR/artisan")"

# ----------------------------------------------------------------- helpers ---
rel_of() { echo "${1#"$PANEL_DIR"/}"; }

backup() {
  local f="$1" rel; rel="$(rel_of "$f")"
  if [[ -f "$f" && ! -e "$BK/original/$rel" ]]; then
    mkdir -p "$BK/original/$(dirname "$rel")"
    cp -p "$f" "$BK/original/$rel"
  fi
}

in_created() { grep -qxF "$(rel_of "$1")" "$BK/created.list" 2>/dev/null; }

mark_created() {
  local rel; rel="$(rel_of "$1")"
  [[ -e "$BK/original/$rel" ]] && return 0
  in_created "$1" || echo "$rel" >> "$BK/created.list"
}

# write_file <path>  (isi dari stdin)
write_file() {
  local f="$1"
  mkdir -p "$(dirname "$f")" "$BK"
  if [[ -f "$f" ]]; then
    in_created "$f" || backup "$f"
  else
    mark_created "$f"
  fi
  cat > "$f"
}

as_owner() {
  if command -v runuser >/dev/null; then
    (cd "$PANEL_DIR" && runuser -u "$OWNER" -- "$@")
  else
    (cd "$PANEL_DIR" && sudo -u "$OWNER" "$@")
  fi
}

post_steps() {
  chown -R "$OWNER:$OWNER" "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache" 2>/dev/null || true
  [[ -d "$PUB_DIR" ]] && chown -R "$OWNER:$OWNER" "$PUB_DIR" 2>/dev/null || true
  as_owner php artisan route:clear >/dev/null 2>&1 || warn "route:clear gagal"
  as_owner php artisan view:clear  >/dev/null 2>&1 || warn "view:clear gagal"
  as_owner php artisan cache:clear >/dev/null 2>&1 || true
  as_owner php artisan queue:restart >/dev/null 2>&1 || true
  for u in $(systemctl list-units --type=service --no-legend 2>/dev/null | awk '{print $1}' | grep -E '^php[0-9.]*-fpm\.service$' || true); do
    systemctl reload "$u" >/dev/null 2>&1 || true
  done
}

# -------------------------------------------------------------- patch view ---
inject_include() { # file area
  local f="$1" area="$2" tag
  [[ -f "$f" ]] || { warn "Tidak ditemukan: $(rel_of "$f")"; return 1; }
  grep -q 'partials.glassbrutal' "$f" && return 0
  backup "$f"
  for tag in '</head\s*>' '</body\s*>'; do
    AREA="$area" TAG="$tag" perl -0pi -e 'my $i = q{@includeIf("partials.glassbrutal", ["area" => "} . $ENV{AREA} . q{"])}; s/($ENV{TAG})/$i\n$1/i' "$f"
    if grep -q 'partials.glassbrutal' "$f"; then
      info "Patch tema: $(rel_of "$f")"
      return 0
    fi
  done
  printf '\n@includeIf("partials.glassbrutal", ["area" => "%s"])\n' "$area" >> "$f"
  warn "Tag </head> dan </body> tidak ada di $(rel_of "$f"); include ditambahkan di akhir file."
}

# bersihkan sisa tema Neo Brutalism lama (protect-pterodactyl.sh) agar tidak bentrok
strip_old_theme() {
  local f
  for f in "$V_WRAPPER" "$V_CORE" "$V_ADMIN"; do
    [[ -f "$f" ]] || continue
    if grep -q 'partials.protect-theme' "$f"; then
      backup "$f"
      perl -0pi -e 's/[ \t]*\@includeIf\("partials\.protect-theme"[^\n]*\n?//g' "$f"
      warn "Include tema lama dihapus dari $(rel_of "$f")"
    fi
  done
}

patch_routes() {
  [[ -f "$ROUTES" ]] || { warn "routes/admin.php tidak ditemukan"; return 0; }
  grep -q 'GlassBrutal admin theme' "$ROUTES" && return 0
  backup "$ROUTES"
  cat >> "$ROUTES" <<'PHP'

// ---- GlassBrutal admin theme (dipasang oleh install.sh) ----
Route::group(['prefix' => 'theme'], function () {
    Route::get('/', [\Pterodactyl\Http\Controllers\Admin\ThemeController::class, 'index'])->name('admin.theme');
    Route::post('/', [\Pterodactyl\Http\Controllers\Admin\ThemeController::class, 'update']);
});
PHP
  if ! php -l "$ROUTES" >/dev/null 2>&1; then
    cp -p "$BK/original/$(rel_of "$ROUTES")" "$ROUTES"
    die "Patch routes/admin.php menghasilkan error sintaks; dikembalikan."
  fi
  info "Patch route: admin.theme"
}

patch_admin_sidebar() {
  [[ -f "$V_ADMIN" ]] || return 0
  grep -q 'admin.theme' "$V_ADMIN" && return 0
  backup "$V_ADMIN"
  local LI
  LI="$(cat <<'EOF'
<li class="{{ \Illuminate\Support\Str::startsWith(Route::currentRouteName() ?? '', 'admin.theme') ? 'active' : '' }}">
    <a href="{{ route('admin.theme') }}"><i class="fa fa-paint-brush"></i> <span>Theme</span></a>
</li>
EOF
)"
  LI="$LI" perl -0pi -e 's|(<li[^>]*>\s*<a\s+href="\{\{\s*route\(\x27admin\.settings\x27\)\s*\}\}"[^>]*>.*?</li>)|$1\n$ENV{LI}|s' "$V_ADMIN"
  if grep -q 'admin.theme' "$V_ADMIN"; then
    info "Menu sidebar admin: Theme"
  else
    warn "Menu sidebar tidak bisa dipasang otomatis (akan disisipkan lewat JS / buka /admin/theme)."
  fi
}

patch_settings_nav() {
  [[ -f "$V_NAV" ]] || return 0
  grep -q 'admin.theme' "$V_NAV" && return 0
  backup "$V_NAV"
  local LI
  LI="$(cat <<'EOF'
<li @if (($activeTab ?? '') === 'theme') class="active" @endif><a href="{{ route('admin.theme') }}"><i class="fa fa-paint-brush"></i> Theme</a></li>
EOF
)"
  LI="$LI" perl -0pi -e 's|</ul>|$ENV{LI}\n</ul>|' "$V_NAV"
  grep -q 'admin.theme' "$V_NAV" && info "Tab Theme di Admin > Settings"
}

# ------------------------------------------------------------------ aksi ---
restore_original() {
  [[ -d "$BK" ]] || die "Backup tidak ditemukan, tidak ada yang bisa dikembalikan."
  if [[ -d "$BK/original" ]]; then
    (cd "$BK/original" && find . -type f) | while read -r rel; do
      cp -p "$BK/original/$rel" "$PANEL_DIR/$rel"
    done
  fi
  if [[ -f "$BK/created.list" ]]; then
    while read -r rel; do
      rm -f "$PANEL_DIR/$rel"
      rmdir -p --ignore-fail-on-non-empty "$(dirname "$PANEL_DIR/$rel")" 2>/dev/null || true
    done < "$BK/created.list"
  fi
  rm -rf "$PUB_DIR" "$BK"
  if [[ "${KEEP_SETTINGS:-0}" != "1" ]]; then rm -rf "$CFG_DIR"; fi
  post_steps
}

install_theme() {
  [[ -d "$SRC/files" ]] || die "Folder files/ tidak ditemukan di $SRC (ekstrak zip dulu)."
  mkdir -p "$BK"
  strip_old_theme
  while IFS= read -r -d '' src; do
    local rel="${src#"$SRC/files/"}"
    write_file "$PANEL_DIR/$rel" < "$src"
  done < <(find "$SRC/files" -type f -print0)
  mkdir -p "$PUB_DIR/uploads" "$CFG_DIR"

  inject_include "$( [[ -f "$V_WRAPPER" ]] && echo "$V_WRAPPER" || echo "$V_CORE" )" user || true
  inject_include "$V_ADMIN" admin || true
  patch_routes
  patch_admin_sidebar
  patch_settings_nav
  post_steps
  info "Selesai. Buka: Admin > Settings > Theme  (atau /admin/theme)"
  warn "Jika muncul error 'Class ... not found', jalankan: cd $PANEL_DIR && composer dump-autoload"
}

uninstall_theme() {
  [[ -d "$BK" ]] || die "Tema belum terpasang (backup tidak ditemukan)."
  if [[ "${YES:-0}" != "1" ]]; then
    local a=""
    read -r -p "Hapus tema dan kembalikan file asli? [y/N]: " a || true
    [[ "${a,,}" == "y" || "${a,,}" == "yes" ]] || die "Uninstall dibatalkan."
  fi
  restore_original
  info "Tema dihapus, file asli dikembalikan."
}

reset_theme() {
  rm -f "$CFG_DIR/theme.json"
  rm -rf "$PUB_DIR/uploads" && mkdir -p "$PUB_DIR/uploads"
  post_steps
  info "Pengaturan tema direset ke default."
}

menu() {
  echo "=== GlassBrutal Theme ==="
  echo " 1) Install / update tema"
  echo " 2) Uninstall tema"
  echo " 3) Reset pengaturan ke default"
  echo " 0) Keluar"
  local c=""
  read -r -p "Pilih: " c || true
  case "$c" in
    1) install_theme ;;
    2) uninstall_theme ;;
    3) reset_theme ;;
    *) exit 0 ;;
  esac
}

case "$ACTION" in
  menu) menu ;;
  install) install_theme ;;
  uninstall) uninstall_theme ;;
  reset) reset_theme ;;
  *) die "Aksi tidak dikenal: $ACTION (install | uninstall | reset)" ;;
esac
