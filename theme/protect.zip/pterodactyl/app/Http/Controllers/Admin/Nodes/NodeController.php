<?php

namespace Pterodactyl\Http\Controllers\Admin\Nodes;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\Node;
use Spatie\QueryBuilder\QueryBuilder;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;

class NodeController extends Controller
{
    private function authorizeAdminUtama(): void
    {
        $user = auth()->user();

        if ((int) $user->id !== 1) {
            throw new DisplayException('Akses ditolak. Hanya Admin ID 1 yang dapat mengakses halaman ini. [Protected by @astracodex]');
        }
    }

    public function index(Request $request): View
    {
        $this->authorizeAdminUtama();

        $nodes = QueryBuilder::for(
            Node::query()->with('location')->withCount('servers')
        )
            ->allowedFilters(['uuid', 'name'])
            ->allowedSorts(['id'])
            ->paginate(25);

        return view('admin.nodes.index', ['nodes' => $nodes]);
    }
}