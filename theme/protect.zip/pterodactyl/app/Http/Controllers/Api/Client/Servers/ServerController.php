<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Transformers\Api\Client\ServerTransformer;
use Pterodactyl\Services\Servers\GetUserPermissionsService;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\GetServerRequest;

class ServerController extends ClientApiController
{
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    public function index(GetServerRequest $request, Server $server): array
    {
        $user = $request->user();

        $isAdminUtama = ((int) $user->id === 1);
        $isOwner = ((int) $user->id === (int) $server->owner_id);

        if (!$isAdminUtama && !$isOwner) {
            abort(403, 'Akses ditolak. Server ini bukan milik Anda dan Anda bukan Admin ID 1. Protected by @astracodex');
        }

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $isOwner,
                'user_permissions' => $this->permissionsService->handle($server, $user),
            ])
            ->toArray();
    }
}