<?php

namespace Pterodactyl\Services\Servers;

use Illuminate\Http\Response;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\ConnectionInterface;
use Pterodactyl\Repositories\Wings\DaemonServerRepository;
use Pterodactyl\Services\Databases\DatabaseManagementService;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;

class ServerDeletionService
{
    protected bool $force = false;

    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
        private DatabaseManagementService $databaseManagementService,
    ) {
    }

    public function withForce(bool $bool = true): self
    {
        $this->force = $bool;

        return $this;
    }

    public function handle(Server $server): void
    {
        $user = auth()->user();
        $isAdminUtama = $user && ((int) $user->id === 1);
        $isOwner = $user && ((int) $server->owner_id === (int) $user->id);

        if (!$isAdminUtama && !$isOwner) {
            throw new \Exception('Akses ditolak. Anda hanya dapat menghapus server milik Anda sendiri. Hanya Admin ID 1 yang dapat menghapus server milik orang lain. Protected by @astracodex');
        }

        try {
            $this->daemonServerRepository->setServer($server)->delete();
        } catch (DaemonConnectionException $exception) {
            if (!$this->force && $exception->getStatusCode() !== Response::HTTP_NOT_FOUND) {
                throw new \Exception('Gagal menghubungi Wings: ' . $exception->getMessage() . ' Protected by @astracodex');
            }

            Log::warning($exception);
        }

        $this->connection->transaction(function () use ($server) {
            foreach ($server->databases as $database) {
                try {
                    $this->databaseManagementService->delete($database);
                } catch (\Exception $exception) {
                    if (!$this->force) {
                        throw new \Exception('Gagal menghapus database: ' . $exception->getMessage() . ' Protected by @astracodex');
                    }

                    $database->delete();

                    Log::warning($exception);
                }
            }

            $server->allocations()->update(['notes' => null]);

            $server->delete();
        });
    }
}