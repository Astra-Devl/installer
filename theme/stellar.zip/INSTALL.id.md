# Stellar Theme — kompatibel Pterodactyl Panel v1.15.2 (Node.js 22+)

Tema ini sudah di-merge (3-way) dari basis aslinya (v1.11.x) ke panel resmi **v1.15.2**
(rilis stabil terbaru, https://github.com/pterodactyl/panel). `pterodactyl/` di sini adalah overlay:
salin ke root panel (menimpa file yang sama).

## Perubahan penting
- Semua perubahan upstream v1.11.11 → v1.15.2 ikut masuk (Hytale OAuth feature, `skip_scripts`/Reinstall,
  identifier server baru, status "Under Maintenance", keamanan, dll).
- `react-feather` ditambahkan ke `package.json` (sebelumnya TIDAK terdaftar → build webpack gagal "Module not found").
- Status "Under Maintenance" ditambahkan ke `ServerRow` & `ServerCard` (dulu spinner tanpa akhir).
- Migration tema diubah jadi anonymous class (gaya Laravel 12) + import `DB` yang hilang.
- Tailwind/CSS variable, font, dan GlobalStylesheet mengikuti versi terbaru.

## Pemasangan (panel baru / upgrade)
```bash
cd /var/www/pterodactyl
php artisan down
# 1. upgrade panel resmi dulu ke v1.15.2 (ikuti docs upgrade), lalu:
cp -r /path/ke/stellar-v1.15.2/pterodactyl/* .      # overlay tema
# 2. Node.js 22+ (mis. via nvm/nodesource), Yarn:
node -v   # harus >= 22
npm i -g yarn
yarn install
yarn build:production
# 3. database
composer install --no-dev --optimize-autoloader
php artisan migrate --seed --force
php artisan view:clear && php artisan config:clear && php artisan cache:clear
chown -R www-data:www-data /var/www/pterodactyl/*
php artisan up
```
Admin → menu **Theme** untuk mengatur warna/logo.

## Catatan
- `wrapper.blade.php` membaca tabel `theme`; pastikan `php artisan migrate` sudah dijalankan, kalau tidak halaman 500.
- `yarn.lock` akan diperbarui otomatis saat `yarn install` (karena ada `react-feather`); commit file itu.
- Panel 2.0 (beta) adalah rewrite total dan TIDAK kompatibel dengan tema ini.

## Perubahan v2 (sidebar & daftar server)
- Mobile: tombol menu (☰) membuka sidebar drawer dari kiri + backdrop; tutup via tombol X, klik backdrop, Esc, atau pindah halaman.
- Daftar server (mode Cards): satu panel menyatu, tiap server menampilkan status (Stopped/Starting/Online/Stopping), CPU, RAM, Disk.
- Perbaikan: daftar server tidak lagi spinner selamanya jika setting theme gagal dibaca; footer pagination tidak lagi masuk ke dalam tabel.
