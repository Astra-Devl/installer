<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ButtonController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        $theme = DB::table('theme')->first();

        return view('admin.theme.button', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        DB::table('theme')->update([
            'textbutton' => $request->input('textbutton', ''),
            'textbuttonhover' => $request->input('textbuttonhover', ''),
            'dangerbutton' => $request->input('dangerbutton', ''),
            'dangerbuttonhover' => $request->input('dangerbuttonhover', ''),
            'ltextbutton' => $request->input('ltextbutton', ''),
            'ltextbuttonhover' => $request->input('ltextbuttonhover', ''),
            'ldangerbutton' => $request->input('ldangerbutton', ''),
            'ldangerbuttonhover' => $request->input('ldangerbuttonhover', ''),
            'primary' => $request->input('primary', ''),
            'primaryhover' => $request->input('primaryhover', ''),
            'lprimary' => $request->input('lprimary', ''),
            'lprimaryhover' => $request->input('lprimaryhover', ''),
            'borderradius' => $request->input('borderradius', ''),
            'input' => $request->input('input', ''),
            'linput' => $request->input('linput', ''),
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
