<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ColorController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        $theme = DB::table('theme')->first();

        return view('admin.theme.color', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        DB::table('theme')->update([
            'highlightcolor' => $request->input('highlightcolor', ''),
            'lightcolor' => $request->input('lightcolor', ''),
            'color' => $request->input('color', ''),
            'subcolor' => $request->input('subcolor', ''),
            'color4' => $request->input('color4', ''),
            'color5' => $request->input('color5', ''),
            'color6' => $request->input('color6', ''),
            'dark' => $request->input('dark', ''),
            'primary' => $request->input('primary', ''),
            'primaryhover' => $request->input('primaryhover', ''),
            'secondary' => $request->input('secondary', ''),
            'secondaryhover' => $request->input('secondaryhover', ''),
            'background' => $request->input('background', ''),
            'lhighlightcolor' => $request->input('lhighlightcolor', ''),
            'llightcolor' => $request->input('llightcolor', ''),
            'lcolor' => $request->input('lcolor', ''),
            'lsubcolor' => $request->input('lsubcolor', ''),
            'lcolor4' => $request->input('lcolor4', ''),
            'lcolor5' => $request->input('lcolor5', ''),
            'lcolor6' => $request->input('lcolor6', ''),
            'ldark' => $request->input('ldark', ''),
            'lprimary' => $request->input('lprimary', ''),
            'lprimaryhover' => $request->input('lprimaryhover', ''),
            'lsecondary' => $request->input('lsecondary', ''),
            'lsecondaryhover' => $request->input('lsecondaryhover', ''),
            'lbackground' => $request->input('lbackground', ''),
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
