<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ElementController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        $theme = DB::table('theme')->first();

        return view('admin.theme.element', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        DB::table('theme')->update([
            'subnavigation' => $request->boolean('subnavigation') ? 1 : 0,
            'graphcard' => $request->boolean('graphcard') ? 1 : 0,
            'sidegraph' => $request->boolean('sidegraph') ? 1 : 0,
            'infoelement' => $request->boolean('infoelement') ? 1 : 0,
            'newserverlist' => $request->input('newserverlist', ''),
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
