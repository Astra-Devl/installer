<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class SocialController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        $theme = DB::table('theme')->first();

        return view('admin.theme.social', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        DB::table('theme')->update([
            'website' => $request->input('website', ''),
            'discord' => $request->input('discord', ''),
            'status' => $request->input('status', ''),
            'knowledgebase' => $request->input('knowledgebase', ''),
            'billing' => $request->input('billing', ''),
            'updated_at' => now(),
        ]);

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
