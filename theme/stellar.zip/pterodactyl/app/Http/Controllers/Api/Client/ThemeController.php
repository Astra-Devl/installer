<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Support\Facades\DB;

/**
 * Endpoint tema untuk frontend: GET /api/client/theme
 *
 * Dipisah dari ClientController bawaan supaya file inti panel tidak perlu
 * ditimpa dan tidak bentrok saat panel di-update.
 */
class ThemeController extends ClientApiController
{
    public function index(): array
    {
        return [
            'success' => true,
            'data' => DB::table('theme')->first(),
        ];
    }
}
