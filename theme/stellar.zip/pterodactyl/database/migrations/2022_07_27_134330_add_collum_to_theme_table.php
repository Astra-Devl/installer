<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** kolom => [tipe, default] */
    private array $columns = [
        'metacolor' => ['string', '#3B6CDE'],
        'infoelement' => ['boolean', 1],
        'newserverlist' => ['string', 'table'],
        'sidegraph' => ['boolean', 1],
        'dangerbutton' => ['string', '#DC2626'],
        'textbutton' => ['string', '#4E5C7E'],
        'dangerbuttonhover' => ['string', '#ff4040'],
        'textbuttonhover' => ['string', '#60709A'],
        'ldangerbutton' => ['string', '#FF4747'],
        'ltextbutton' => ['string', '#E0EFFF'],
        'ldangerbuttonhover' => ['string', '#FF5C5C'],
        'ltextbuttonhover' => ['string', '#EBF4FF'],
        'longlogo' => ['string', '/favicons/favicon-32x32.png'],
        'borderradius' => ['string', '7'],
        'typealert' => ['string', 'disabled'],
        'alertdescription' => ['string', 'none'],
        'discord' => ['string', 'none'],
        'website' => ['string', 'none'],
        'billing' => ['string', 'none'],
        'knowledgebase' => ['string', 'none'],
        'status' => ['string', 'none'],
    ];

    public function up(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            foreach ($this->columns as $name => [$type, $default]) {
                if (!Schema::hasColumn('theme', $name)) {
                    $table->{$type}($name)->default($default);
                }
            }
        });
    }

    public function down(): void
    {
        Schema::table('theme', function (Blueprint $table) {
            $drop = array_filter(array_keys($this->columns), fn ($c) => Schema::hasColumn('theme', $c));
            if ($drop) {
                $table->dropColumn(array_values($drop));
            }
        });
    }
};
