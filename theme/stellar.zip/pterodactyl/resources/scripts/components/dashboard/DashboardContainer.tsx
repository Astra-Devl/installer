import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import ServerCard, { ServerListPanel } from '@/components/dashboard/ServerCard';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import Switch from '@/components/elements/Switch';
import tw from 'twin.macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import styled from 'styled-components/macro';
import getTheme from '@/api/getThemeData';
import * as Lang from '@/lang';

// Tabel terlalu lebar untuk layar kecil, jadi di HP daftar server selalu tampil sebagai kotak per server.
const useIsDesktop = () => {
    const query = '(min-width: 979px)';
    const [matches, setMatches] = useState(() => window.matchMedia(query).matches);

    useEffect(() => {
        const media = window.matchMedia(query);
        const onChange = () => setMatches(media.matches);
        media.addEventListener('change', onChange);

        return () => media.removeEventListener('change', onChange);
    }, []);

    return matches;
};

const TableDiv = styled.div`
    overflow-x:auto;
`;

const Table = styled.table`
    background-color:var(--secondary);
    width:100%;
    border-radius:20px;

    & th{
        ${tw`text-neutral-400`};
        text-align:left;
        font-weight:normal;
        padding:2.5em 1.5em .8em;
        white-space:nowrap;
    }
    & td{
        padding:.5em 1.5em;
        white-space:nowrap;
    }
    & tbody > tr:last-of-type > td{
        padding:.5em 1.5em 2.5em;
    }
    & td > span{
        ${tw`text-neutral-400`};
        font-size:.7em;
    }
    & td:first-of-type{
        ${tw`text-neutral-400`};
    }
`;

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');
    const isDesktop = useIsDesktop();
    const [themeData, setThemeData] = useState<string | undefined>();

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);
    
    useEffect(() => {
        // Bila pengaturan tema tidak bisa dibaca (atau nilainya tidak dikenal), pakai tampilan "cards"
        // supaya daftar server tidak berhenti di spinner selamanya.
        getTheme()
            .then((data) => setThemeData(data.newserverlist === 'table' ? 'table' : 'cards'))
            .catch(() => setThemeData('cards'));
    }, []);

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>
            {rootAdmin && (
                <div css={tw`pr-4 mb-2 flex justify-end items-center`}>
                    <p css={tw`uppercase text-xs text-neutral-300 mr-2`}>
                        {showOnlyAdmin ? `${Lang.showing_others_servers}` : `${Lang.showing_your_servers}` }
                    </p>
                    <Switch
                        name={'show_all_servers'}
                        defaultChecked={showOnlyAdmin}
                        onChange={() => setShowOnlyAdmin((s) => !s)}
                    />
                </div>
            )}
            {!servers || !themeData ? (
                <Spinner centered size={'large'} />
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) => {
                        if (items.length < 1) {
                            return (
                                <p css={tw`text-center text-sm text-neutral-400`}>
                                    {showOnlyAdmin
                                        ? `${Lang.there_are_no_other_servers_to_display}`
                                        : `${Lang.there_are_no_servers_associated_with_your_account}`}
                                </p>
                            );
                        }

                        return themeData === 'table' && isDesktop ? (
                            <TableDiv>
                                <Table>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>{Lang.Name}</th>
                                            <th>{Lang.Allocation}</th>
                                            <th>CPU</th>
                                            <th>Ram</th>
                                            <th>Disk</th>
                                            <th>{Lang.Status}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {items.map((server) => (
                                            <ServerRow key={server.uuid} server={server} />
                                        ))}
                                    </tbody>
                                </Table>
                            </TableDiv>
                        ) : (
                            <ServerListPanel>
                                {items.map((server) => (
                                    <ServerCard key={server.uuid} server={server} />
                                ))}
                            </ServerListPanel>
                        );
                    }}
                </Pagination>
            )}
        </PageContentBlock>
    );
};
