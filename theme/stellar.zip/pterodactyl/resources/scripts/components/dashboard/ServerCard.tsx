import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import CopyOnClick from '@/components/elements/CopyOnClick';
import styled from 'styled-components/macro';
import { Installing, Suspended } from '@/lang';

// Dipakai juga oleh DashboardContainer sebagai pembungkus satu panel yang menyatu.
// Setiap server hanya satu "baris" di dalam panel ini, dipisahkan garis tipis.
export const ServerListPanel = styled.div`
    background-color: var(--secondary);
    border-radius: 20px;
    overflow: hidden;
`;

type Tone = 'online' | 'stopped' | 'busy' | 'error' | 'muted';

const TONES: Record<Tone, string> = {
    online: '#7F9B8B',
    stopped: '#9B7F82',
    busy: '#9B947F',
    error: '#c0565e',
    muted: '#7c8a99',
};

const Row = styled.div`
    ${tw`text-neutral-50`};
    padding: 22px 25px;

    & + & {
        border-top: 1px solid #484961;
    }

    & .meta span {
        ${tw`text-neutral-300`};
    }

    & .manage {
        background-color: var(--primary);
        padding: 10px 18px;
        display: block;
        border-radius: var(--borderradius);
        text-align: center;
        color: white;
        white-space: nowrap;

        &:hover {
            background-color: var(--primary-hover);
        }
    }
`;

const StatusBadge = styled.div<{ $tone: Tone }>`
    display: inline-flex;
    align-items: center;
    flex-shrink: 0;
    gap: 7px;
    font-size: 0.8rem;
    color: ${({ $tone }) => TONES[$tone]};

    &::before {
        content: '';
        width: 8px;
        height: 8px;
        border-radius: 100%;
        background-color: ${({ $tone }) => TONES[$tone]};
    }
`;

const Bar = styled.div<{ $percent: number; $alarm: boolean }>`
    height: 4px;
    margin-top: 6px;
    border-radius: 4px;
    background-color: var(--input);
    overflow: hidden;

    &::after {
        content: '';
        display: block;
        height: 100%;
        width: ${({ $percent }) => Math.min(100, Math.max(0, $percent))}%;
        border-radius: 4px;
        background-color: ${({ $alarm }) => ($alarm ? '#c0565e' : 'var(--primary)')};
        transition: width 0.4s;
    }
`;

const Stat = ({
    label,
    value,
    limit,
    percent,
    alarm,
}: {
    label: string;
    value: string;
    limit: string;
    percent: number;
    alarm: boolean;
}) => (
    <div css={tw`min-w-0`}>
        <div css={tw`flex justify-between text-xs`}>
            <span css={tw`text-neutral-300`}>{label}</span>
        </div>
        <div css={tw`text-sm mt-1 truncate`}>
            <b>{value}</b> <span css={tw`text-neutral-300 text-xs`}>/ {limit}</span>
        </div>
        <Bar $percent={percent} $alarm={alarm} />
    </div>
);

// Menentukan label + warna status server yang ditampilkan di sebelah nama.
const getStatus = (server: Server, stats: ServerStats | null, isSuspended: boolean): { label: string; tone: Tone } => {
    if (isSuspended) {
        return server.status === 'suspended'
            ? { label: `${Suspended}`, tone: 'error' }
            : { label: 'Connection Error', tone: 'error' };
    }
    if (server.isNodeUnderMaintenance) return { label: 'Under Maintenance', tone: 'busy' };
    if (server.isTransferring) return { label: 'Transferring', tone: 'busy' };
    if (server.status === 'installing') return { label: `${Installing}`, tone: 'busy' };
    if (server.status === 'restoring_backup') return { label: 'Restoring Backup', tone: 'busy' };
    if (server.status) return { label: 'Unavailable', tone: 'muted' };

    switch (stats?.status) {
        case 'running':
            return { label: 'Online', tone: 'online' };
        case 'offline':
            return { label: 'Stopped', tone: 'stopped' };
        case 'starting':
            return { label: 'Starting', tone: 'busy' };
        case 'stopping':
            return { label: 'Stopping', tone: 'busy' };
        default:
            return { label: 'Connecting', tone: 'muted' };
    }
};

const percentOf = (current: number, limitMb: number) =>
    limitMb > 0 ? (current / (limitMb * 1024 * 1024)) * 100 : 0;

type Timer = ReturnType<typeof setInterval>;

export default ({ server }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Jangan membuang request HTTP bila tidak ada yang bisa ditampilkan.
        if (isSuspended || server.isNodeUnderMaintenance) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended, server.isNodeUnderMaintenance]);

    const status = getStatus(server, stats, isSuspended);

    const cpuLimit = server.limits.cpu !== 0 ? `${server.limits.cpu} %` : 'Unlimited';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : 'Unlimited';
    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : 'Unlimited';

    const cpuPercent = stats && server.limits.cpu > 0 ? (stats.cpuUsagePercent / server.limits.cpu) * 100 : 0;
    const memPercent = stats ? percentOf(stats.memoryUsageInBytes, server.limits.memory) : 0;
    const diskPercent = stats ? percentOf(stats.diskUsageInBytes, server.limits.disk) : 0;

    return (
        <Row>
            <div css={tw`flex items-center justify-between gap-4`}>
                <b css={tw`text-lg truncate`}>{server.name}</b>
                <StatusBadge $tone={status.tone}>{status.label}</StatusBadge>
            </div>

            <div className={'meta'} css={tw`mt-1 text-sm`}>
                <span>IP: </span>
                {server.allocations
                    .filter((alloc) => alloc.isDefault)
                    .map((allocation) => (
                        <React.Fragment key={allocation.ip + allocation.port.toString()}>
                            <CopyOnClick text={`${allocation.alias || ip(allocation.ip)}:${allocation.port}`}>
                                <b>
                                    {allocation.alias || ip(allocation.ip)}:{allocation.port}
                                </b>
                            </CopyOnClick>
                        </React.Fragment>
                    ))}
            </div>

            <div css={tw`grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4`}>
                <Stat
                    label={'CPU'}
                    value={stats ? `${stats.cpuUsagePercent.toFixed(2)} %` : '—'}
                    limit={cpuLimit}
                    percent={cpuPercent}
                    alarm={cpuPercent >= 90}
                />
                <Stat
                    label={'RAM'}
                    value={stats ? bytesToString(stats.memoryUsageInBytes) : '—'}
                    limit={memoryLimit}
                    percent={memPercent}
                    alarm={memPercent >= 90}
                />
                <Stat
                    label={'Disk'}
                    value={stats ? bytesToString(stats.diskUsageInBytes) : '—'}
                    limit={diskLimit}
                    percent={diskPercent}
                    alarm={diskPercent >= 90}
                />
            </div>

            <Link to={`/server/${server.id}`} className={'manage'} css={tw`mt-4`}>
                Manage Server
            </Link>
        </Row>
    );
};
