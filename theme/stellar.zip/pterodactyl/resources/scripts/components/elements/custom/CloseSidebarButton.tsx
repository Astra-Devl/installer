import * as React from 'react';
import * as Icon from 'react-feather';
import { closeSidebar } from '@/components/elements/custom/sidebar';

// Tombol tutup di dalam drawer sidebar (mobile). Gaya mengikuti aturan "button" pada NavigationBar.
export default () => (
    <button type={'button'} onClick={closeSidebar} aria-label={'Close menu'}>
        <div className='icon'>
            <Icon.X size={20} />
        </div>
    </button>
);
