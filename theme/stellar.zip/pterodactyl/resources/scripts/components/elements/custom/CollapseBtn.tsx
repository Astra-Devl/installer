import * as React from 'react';
import { useLayoutEffect } from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';

const HideShowIcon = styled.div`
    & > *{
        transition:transform .3s;
    }
    .collapse & > * {
        transform:rotate(180deg);
    }
`

const readCollapsed = (): boolean => {
    try {
        return localStorage.getItem('collapse') === 'true';
    } catch (e) {
        return false;
    }
};

const writeCollapsed = (value: boolean) => {
    try {
        localStorage.setItem('collapse', value ? 'true' : 'null');
    } catch (e) {
        // storage can be unavailable (private mode), the toggle still works for this page view.
    }
};

// Desktop only: collapses the sidebar down to icons. On mobile the sidebar is
// opened with the menu button (see MobileMenuButton).
export default () => {
    useLayoutEffect(() => {
        document.body.classList.toggle('collapse', readCollapsed());
    }, []);

    const collapseBtn = () => {
        const next = !document.body.classList.contains('collapse');
        writeCollapsed(next);
        document.body.classList.toggle('collapse', next);
    };

    return (
        <button onClick={collapseBtn} aria-label={'Toggle sidebar'}>
            <div className='icon'>
                <HideShowIcon>
                    <Icon.ArrowLeft size={20}/>
                </HideShowIcon>
            </div>
        </button>
    );
};
