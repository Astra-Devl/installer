import * as React from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import { toggleSidebar } from '@/components/elements/custom/sidebar';

const Button = styled.button`
    display: flex;
    align-items: center;
    justify-content: center;
    width: 38px;
    height: 38px;
    margin: 4px 0;
    border-radius: var(--borderradius);
    background-color: var(--secondary);
    color: var(--color);
    cursor: pointer;
    transition: background-color 0.15s;

    &:hover {
        background-color: var(--secondary-hover);
    }
`;

// Tombol pembuka sidebar. Hanya ditampilkan di layar kecil (diatur oleh wrapper-nya).
export default () => (
    <Button type={'button'} onClick={toggleSidebar} aria-label={'Open menu'}>
        <Icon.Menu size={20} />
    </Button>
);
