import * as React from 'react';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import styled, { createGlobalStyle } from 'styled-components/macro';
import tw from 'twin.macro';
import { closeSidebar } from '@/components/elements/custom/sidebar';

const Nav = styled.div`
width:323px;
background-color:var(--secondary);
border-right:1px solid #484961;
height:100vh;
height:100dvh;
position:sticky;
top:0;
transition:width 0.3s;

#logo{
    width:100%;
    display:flex;
    align-items:center;
    justify-content:space-between;
}
#logo > a{
    padding:0 !important;
    width:100%;
    justify-content:center;
}
#logo .closeBtn{
    display:none;
}
#logo span{
    padding-left:5px;
}
#logo img{
    max-width: 40px !important;
    border-radius: 5px !important;
}

@media only screen and (min-width:979px){
.collapse &{
    width:60px;

    #logo img{
        display:block;
    }

    & a {
        & .icon{
            margin-right:0;
        }
        & > span{
            transition:display 0.3s;
            display:none;
        }
    }
    .subTitle{
        transition:display 0.3s;
        display:none;
    }
    .logOut{
        flex-direction:column;
        justify-content:center;
    }
}
& > div:last-of-type{
    padding-left:0px !important;
    padding-right:0px !important;
}
}

& > div:last-of-type{
    margin-left:8px;
    padding-left:6px;
    padding-right:6px;
    overflow-y:auto;
    display:flex;
    flex-direction:column;
    height:100vh;
    height:100dvh;
}

& #logo {
    text-align:center;
    padding:23px 0px;

    & > a {
        ${tw`text-2xl font-header no-underline text-neutral-200 hover:text-neutral-100 transition-colors duration-150`};
    }
}

& a, & button, & .navigation-link {
    ${tw`no-underline text-neutral-300 cursor-pointer transition-all duration-150`};
    padding:6px .5em 6px;
    display:flex;
    align-items:center;
    border-radius:var(--borderradius);
    
    &:active, &.active {
        background-color:var(--secondary-hover);
        color:var(--white);
        
        .icon{
            color:var(--white);
        }
    }

    .icon{
        padding-left:1px;
        width:35px;
        height:35px;
        font-size:.6em;
        display:flex;
        align-items:center;
        justify-content:center;
        margin-right:10px;
        border-radius:100%;
    }
}
.logOut{
    ${tw`text-neutral-500`};
    padding-bottom:.5em;
    border-top:1px solid #484961;
    display:flex;
    justify-content:space-between;
    padding-top:10px;
    
    .icon{
        margin-right:0px;
    }
}
.media{
    margin-top:auto;
    padding-bottom:4px;
    padding-top:25px;
}
.subTitle{
    ${tw`text-neutral-500`};
    margin-top:30px;
    padding: 0 .5em;
    font-size:.8m;
}
.last{
    margin-bottom:5px;
}
@media only screen and (max-width:978.98px){
    /* Sidebar menjadi drawer yang keluar dari kiri layar */
    &{
        position:fixed;
        top:0;
        left:0;
        bottom:0;
        z-index:60;
        width:290px;
        max-width:85vw;
        height:100vh;
        height:100dvh;
        transform:translateX(-100%);
        visibility:hidden;
        transition:transform 0.3s ease, visibility 0s linear 0.3s;
    }
    body.sidebar-open &{
        transform:translateX(0);
        visibility:visible;
        transition:transform 0.3s ease, visibility 0s;
        box-shadow:0 0 40px rgba(0,0,0,.45);
    }
    & > div:last-of-type{
        margin-left:0;
        padding-left:10px;
        padding-right:10px;
        height:100%;
    }
    #logo{
        padding:18px 0;
    }
    #logo .closeBtn{
        display:block;
    }
    #logo > a{
        justify-content:flex-start;
        padding-left:8px !important;
    }
}
`;

const Backdrop = styled.div`
    display:none;

    @media only screen and (max-width:978.98px){
        display:block;
        position:fixed;
        inset:0;
        z-index:55;
        background-color:rgba(0,0,0,.55);
        opacity:0;
        visibility:hidden;
        transition:opacity 0.3s ease, visibility 0s linear 0.3s;

        body.sidebar-open &{
            opacity:1;
            visibility:visible;
            transition:opacity 0.3s ease, visibility 0s;
        }
    }
`;

// Kunci scroll halaman saat drawer terbuka (hanya di layar kecil).
const SidebarScrollLock = createGlobalStyle`
    @media only screen and (max-width:978.98px){
        body.sidebar-open{
            overflow:hidden;
        }
    }
`;

export default ({ children }: { children?: React.ReactNode }) => {
    const location = useLocation();

    // Tutup drawer setiap pindah halaman.
    useEffect(() => {
        closeSidebar();
    }, [location.pathname]);

    useEffect(() => {
        const onKey = (e: KeyboardEvent) => e.key === 'Escape' && closeSidebar();
        const media = window.matchMedia('(min-width: 979px)');
        const onResize = () => media.matches && closeSidebar();

        window.addEventListener('keydown', onKey);
        media.addEventListener('change', onResize);

        return () => {
            closeSidebar();
            window.removeEventListener('keydown', onKey);
            media.removeEventListener('change', onResize);
        };
    }, []);

    return (
        <>
            <SidebarScrollLock />
            <Nav>{children}</Nav>
            <Backdrop onClick={closeSidebar} />
        </>
    );
};

