import * as React from 'react';
import styled from 'styled-components/macro';
import { Stopped, Starting, Stopping, Online } from '@/lang';

export type PowerStatus = 'offline' | 'starting' | 'running' | 'stopping' | null | undefined;
type Tone = 'red' | 'green' | 'yellow' | 'grey';

const COLORS: Record<Tone, string> = {
    red: '#AC2427',
    green: '#14914E',
    yellow: '#E8A317',
    grey: '#7c8a99',
};

const Badge = styled.span<{ $tone: Tone }>`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    font-size: 0.85em;
    font-weight: 600;
    white-space: nowrap;
    color: var(--highlight-color);

    &::before {
        content: '';
        width: 9px;
        height: 9px;
        border-radius: 50%;
        flex-shrink: 0;
        background-color: ${({ $tone }) => COLORS[$tone]};
        box-shadow: 0 0 0 3px ${({ $tone }) => COLORS[$tone]}33;
    }
`;

const fromPower = (status: PowerStatus): { label: string; tone: Tone } => {
    switch (status) {
        case 'offline':
            return { label: Stopped, tone: 'red' };
        case 'running':
            return { label: Online, tone: 'green' };
        case 'starting':
            return { label: Starting, tone: 'yellow' };
        case 'stopping':
            return { label: Stopping, tone: 'yellow' };
        default:
            return { label: '...', tone: 'grey' };
    }
};

/**
 * Shows the power status of a server (Stopped / Starting / Online / Stopping).
 * Pass `label` + `tone` to show a non-power state instead (Suspended, Installing, ...).
 */
export default ({ status, label, tone, className }: { status?: PowerStatus; label?: string; tone?: Tone; className?: string }) => {
    const base = fromPower(status);

    return (
        <Badge className={className} $tone={tone || base.tone}>
            {label || base.label}
        </Badge>
    );
};
