// Kontrol sidebar drawer (mobile). State disimpan sebagai class pada <body>,
// terpisah dari class "collapse" milik sidebar desktop.
const CLASS_NAME = 'sidebar-open';

export const isSidebarOpen = (): boolean => document.body.classList.contains(CLASS_NAME);
export const openSidebar = () => document.body.classList.add(CLASS_NAME);
export const closeSidebar = () => document.body.classList.remove(CLASS_NAME);
export const toggleSidebar = () => (isSidebarOpen() ? closeSidebar() : openSidebar());
