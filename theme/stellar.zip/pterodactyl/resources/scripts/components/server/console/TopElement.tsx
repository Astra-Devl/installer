import React, { useEffect, useMemo, useState } from 'react';
import { ServerContext } from '@/state/server';
import styled from 'styled-components/macro';
import CopyOnClick from '@/components/elements/CopyOnClick';
import StatusBadge from '@/components/elements/custom/StatusBadge';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { faHdd, faMemory, faMicrochip } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import * as Icon from 'react-feather';

// One single box for the server: name + status + address on top, CPU / RAM / Disk below.
const DetailsItem = styled.div`
    position: relative;
    background-color: var(--secondary);
    border-radius: 15px;
    margin-bottom: 15px;
    padding: 20px 25px;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
    }
    .meta {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px 24px;
        margin-top: 6px;
    }
    .meta > div {
        display: flex;
        align-items: center;
        gap: 6px;
    }
`;

// `--graphcard` is set to `none` from Admin > Theme when the resource cards are disabled.
const Resources = styled.div`
    display: var(--graphcard, grid);
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px 24px;
    margin-top: 18px;
    padding-top: 16px;
    border-top: 1px solid #484961;

    @media only screen and (max-width: 979px) {
        grid-template-columns: 1fr;
    }

    .row {
        min-width: 0;
    }
    .head {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        gap: 8px;
        font-size: 0.85em;
    }
    .label {
        color: var(--sub-color);
        white-space: nowrap;
    }
    .value {
        font-weight: 700;
        font-size: 1.05em;
        text-align: right;
    }
    .limit {
        opacity: 0.6;
        font-weight: normal;
        font-size: 0.85em;
    }
    .bar {
        margin-top: 8px;
        height: 6px;
        border-radius: 999px;
        background-color: var(--input);
        overflow: hidden;
    }
    .bar > div {
        height: 100%;
        border-radius: 999px;
        background-color: var(--primary);
        transition: width 0.4s ease;
    }
    .bar > div.alarm {
        background-color: var(--danger);
    }
`;

type Stats = Record<'memory' | 'cpu' | 'disk', number>;

const percent = (used: number, limit: number | null | undefined, unit = 1) =>
    !limit ? 0 : Math.min(100, (used / (limit * unit)) * 100);

const TopElement = () => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0 });

    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    useEffect(() => {
        if (!connected || !instance) return;

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let parsed: any = {};
        try {
            parsed = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: parsed.memory_bytes || 0,
            cpu: parsed.cpu_absolute || 0,
            disk: parsed.disk_bytes || 0,
        });
    });

    const limitText = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    // Unlimited resources have no meaningful percentage, so their bar stays empty.
    const cpuPct = percent(stats.cpu, limits?.cpu);
    const memPct = percent(stats.memory, limits?.memory, 1024 * 1024);
    const diskPct = percent(stats.disk, limits?.disk, 1024 * 1024);

    return (
        <DetailsItem>
            <div className={'header'}>
                <h1 className='text-2xl font-semibold'>{name}</h1>
                <StatusBadge status={status} />
            </div>
            <div className={'meta'}>
                <div>
                    <CopyOnClick text={allocation}>
                        <>
                            <span css={'color:var(--primary);'}><Icon.Globe size={18}/></span>
                            {allocation}
                        </>
                    </CopyOnClick>
                </div>
                <div>
                    <CopyOnClick text={id}>
                        <>
                            <span css={'color:var(--primary);'}><Icon.Hash size={18}/></span>
                            {id}
                        </>
                    </CopyOnClick>
                </div>
                <div>
                    <span css={'color:var(--primary);'}><Icon.Server size={18}/></span>
                    {node}
                </div>
            </div>
            <Resources>
                <div className={'row'}>
                    <div className={'head'}>
                        <span className={'label'}><FontAwesomeIcon icon={faMicrochip} fixedWidth/> CPU</span>
                        <span className={'value'}>
                            {stats.cpu.toFixed(2)}%{' '}
                            <span className={'limit'}>/ {limitText.cpu || <>&infin;</>}</span>
                        </span>
                    </div>
                    <div className={'bar'}><div className={cpuPct >= 90 ? 'alarm' : ''} style={{ width: `${cpuPct}%` }}/></div>
                </div>
                <div className={'row'}>
                    <div className={'head'}>
                        <span className={'label'}><FontAwesomeIcon icon={faMemory} fixedWidth/> RAM</span>
                        <span className={'value'}>
                            {bytesToString(stats.memory)}{' '}
                            <span className={'limit'}>/ {limitText.memory || <>&infin;</>}</span>
                        </span>
                    </div>
                    <div className={'bar'}><div className={memPct >= 90 ? 'alarm' : ''} style={{ width: `${memPct}%` }}/></div>
                </div>
                <div className={'row'}>
                    <div className={'head'}>
                        <span className={'label'}><FontAwesomeIcon icon={faHdd} fixedWidth/> Disk</span>
                        <span className={'value'}>
                            {bytesToString(stats.disk)}{' '}
                            <span className={'limit'}>/ {limitText.disk || <>&infin;</>}</span>
                        </span>
                    </div>
                    <div className={'bar'}><div className={diskPct >= 90 ? 'alarm' : ''} style={{ width: `${diskPct}%` }}/></div>
                </div>
            </Resources>
        </DetailsItem>
    );
};

export default TopElement;
