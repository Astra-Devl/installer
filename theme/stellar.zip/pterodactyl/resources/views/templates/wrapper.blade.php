@php
    // Ambil pengaturan tema. Kalau tabel belum dimigrasi, halaman tetap jalan dengan nilai bawaan.
    try {
        $settings = \Illuminate\Support\Facades\DB::table('theme')->first();
    } catch (\Throwable $e) {
        $settings = null;
    }
    // Nilai yang masuk ke <style> dibersihkan agar tidak bisa menyisipkan CSS/HTML.
    $tv = fn (string $key, string $default = '') => preg_replace(
        '/[^A-Za-z0-9#%(),.:\/_\-+?=&@ ]/', '', (string) (data_get($settings, $key) ?: $default)
    );
    $tm = fn (string $key, string $default = '') => (string) (data_get($settings, $key) ?: $default);
    $flag = fn (string $key) => data_get($settings, $key, 'none') === 'none' ? 'none' : 'flex';
@endphp
<html>
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">

            <meta property="og:type" content="website" />
            <meta property="og:image" content="{{ $tm('logo', '/favicons/favicon-32x32.png') }}"/>
            <meta property="og:description" content="{{ $tm('discription') }}" />
            <meta name="theme-color" content="{{ $tm('metacolor', '#3B6CDE') }}">
            <meta property="twitter:title" content="{{ $tm('title') }}">

            <link rel="icon" type="image/png" href="{{ $tm('logo', '/favicons/favicon-32x32.png') }}" sizes="16x16">
            <style>
                body {
                    @if ($tv('backgroundimage') !== '')
                    background-image: url("{!! $tv('backgroundimage') !!}");
                    @endif
                    background-repeat: no-repeat;
                    background-size: cover;
                    background-position: center;
                    background-attachment: fixed;
                }
                :root {
                    --highlight-color: {!! $tv('highlightcolor', '#f5f6f8') !!};
                    --light-color: {!! $tv('lightcolor', '#ecf0f3') !!};
                    --color: {!! $tv('color', '#D9D9D9') !!};
                    --sub-color: {!! $tv('subcolor', '#c0bfc0') !!};
                    --color-4: {!! $tv('color4', '#7c8a99') !!};
                    --color-5: {!! $tv('color5', '#748291') !!};
                    --color-6: {!! $tv('color6', '#636f7d') !!};
                    --dark: {!! $tv('dark', '#33383d') !!};
                    --background-color: {!! $tv('background', '#1B1C30') !!};
                    --input: {!! $tv('input', '#2A2F41') !!};
                    --primary: {!! $tv('primary', '#3B6CDE') !!};
                    --secondary: {!! $tv('secondary', '#222339') !!};
                    --primary-hover: {!! $tv('primaryhover', '#6493FF') !!};
                    --secondary-hover: {!! $tv('secondaryhover', '#1b1c2e') !!};
                    --danger: {!! $tv('dangerbutton', '#DC2626') !!};
                    --danger-hover: {!! $tv('dangerbuttonhover', '#ff4040') !!};
                    --text: {!! $tv('textbutton', '#4E5C7E') !!};
                    --text-hover: {!! $tv('textbuttonhover', '#60709A') !!};

                    --black: #000000;
                    --white: #fff;

                    --borderradius: {{ (int) data_get($settings, 'borderradius', 7) }}px;

                    @if (empty(data_get($settings, 'sidegraph', 1))) --sidegraph: none; @endif
                    @if (empty(data_get($settings, 'subnavigation', 1))) --subnavigation: none; @endif
                    @if (empty(data_get($settings, 'infoelement', 1))) --infoelement: none; @endif
                    @if (empty(data_get($settings, 'graphcard', 1))) --graphcard: none; @endif

                    --website: {!! $flag('website') !!};
                    --status: {!! $flag('status') !!};
                    --billing: {!! $flag('billing') !!};
                    --discord: {!! $flag('discord') !!};
                    --knowledgebase: {!! $flag('knowledgebase') !!};
                }

                .darkmode {
                    --highlight-color: {!! $tv('lhighlightcolor', '#33383d') !!};
                    --light-color: {!! $tv('llightcolor', '#636f7d') !!};
                    --color: {!! $tv('lcolor', '#748291') !!};
                    --sub-color: {!! $tv('lsubcolor', '#7c8a99') !!};
                    --color-4: {!! $tv('lcolor4', '#7c8a99') !!};
                    --color-5: {!! $tv('lcolor5', '#7c8a99') !!};
                    --color-6: {!! $tv('lcolor6', '#636f7d') !!};
                    --dark: {!! $tv('ldark', '#33383d') !!};
                    --background-color: {!! $tv('lbackground', '#F0F0F0') !!};
                    --input: {!! $tv('linput', '#d9d9d9') !!};
                    --primary: {!! $tv('lprimary', '#3B6CDE') !!};
                    --secondary: {!! $tv('lsecondary', '#ffffff') !!};
                    --primary-hover: {!! $tv('lprimaryhover', '#6493FF') !!};
                    --secondary-hover: {!! $tv('lsecondaryhover', '#e3e3e3') !!};
                    --danger: {!! $tv('ldangerbutton', '#FF4747') !!};
                    --danger-hover: {!! $tv('ldangerbuttonhover', '#FF5C5C') !!};
                    --text: {!! $tv('ltextbutton', '#E0EFFF') !!};
                    --text-hover: {!! $tv('ltextbuttonhover', '#EBF4FF') !!};

                    --black: #fff;
                    --white: #000000;
                }
            </style>

            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <link rel="shortcut icon" href="{{ $tm('logo', '/favicons/favicon-32x32.png') }}">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        {{-- Font IBM Plex Sans sudah dibundel lokal oleh panel sejak v1.12.0, tidak perlu Google Fonts. --}}

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
