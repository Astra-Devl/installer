<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Client\ThemeController;

// Di-include dari routes/api-client.php (prefix /api/client + middleware client API).
Route::get('/theme', [ThemeController::class, 'index'])->name('api:client.theme');
